import xbmc, xbmcgui

def fix_widgets():
        choice = xbmcgui.Dialog().yesno('[B][COLOR orange]TechNEWSology[/COLOR][/B]', '[COLOR white]            Επιθυμείτε την συνέχεια της διαδικασίας?[/COLOR]',
                                        nolabel='[B][COLOR orange]Άκυρο[/COLOR][/B]',yeslabel='[B][COLOR lime]Συνέχεια[/COLOR][/B]')
        if choice == 1:
            xbmc.executebuiltin('RunPlugin(plugin://plugin.program.G.K.N.Wizard/?mode=fullclean)')
            xbmc.sleep(1000)
            if xbmc.getCondVisibility("Window.isVisible(yesnodialog)"):
                xbmc.sleep(200)
                xbmc.executebuiltin('SendClick(11)')
            xbmc.sleep(5000)
            xbmcgui.Dialog().notification('[B][COLOR white]Αναμονή...[/COLOR][/B]', '[B][COLOR white]προς ολοκλήρωση διαδικασίας![/COLOR][/B]', '', sound=False)
            xbmc.sleep(5000)
            xbmc.executebuiltin('RunPlugin(plugin://plugin.program.G.K.N.Wizard/?mode=convertpath)')
            xbmc.sleep(5000)
            xbmc.executebuiltin("ReloadSkin")

fix_widgets()
