import xbmc, xbmcgui

def Horus():
    funcs = (click_1, click_2)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]Horus[/COLOR][/B]',
['[COLOR=orange]Horus[/COLOR]',


  
 '[B][COLOR red]XC MAC M3U[/COLOR][/B]'])


    if call:
        if call < 1:
            return
        func = funcs[call-2]
        return func()
    else:
        func = funcs[call]
        return func()
    return 






def click_1():
    xbmc.executebuiltin('RunAddon("script.module.horus")')
    
def click_2():
    xbmc.executebuiltin('Dialog.Close(all,true)')
    xbmc.executebuiltin('Action(Back)')
    
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.macvod/?action=acemenu&extra&page&plot&thumbnail=C%3a%5cPortableApps%5ckodi%5ckodi%20World%2021%5cKodi%5cportable_data%5caddons%5cplugin.video.macvod%5cicon.png&title=%5bB%5d%5bCOLOR%20orange%5dAcestream%5b%2fCOLOR%5d%5b%2fB%5d&url",return)')




Horus()
