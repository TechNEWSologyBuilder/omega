# -*- coding: utf-8 -*-

import xbmcgui
import xbmcaddon
import xbmc
import re
import requests
import six
from six.moves.urllib_parse import quote_plus
from resources.lib.modules import client
from resources.lib.modules import control
from resources.lib.modules import views
from resources.lib.modules import dom_parser as dom
from resources.lib.modules.control import addDir
ADDON       = xbmcaddon.Addon()
ADDON_DATA  = ADDON.getAddonInfo('profile')
ADDON_PATH  = ADDON.getAddonInfo('path')
DESCRIPTION = ADDON.getAddonInfo('description')
FANART      = ADDON.getAddonInfo('fanart')
ICON        = ADDON.getAddonInfo('icon')
ID          = ADDON.getAddonInfo('id')
NAME        = ADDON.getAddonInfo('name')
VERSION     = ADDON.getAddonInfo('version')
Lang        = control.lang
Dialog      = xbmcgui.Dialog()
vers = VERSION
ART = ADDON_PATH + "/resources/icons/"
icon_GOOJARA = ART + 'goojara.png'
GOOJARA = 'https://goojara.club/'


def Goojara_menu():
    addDir('[B][COLOR orange]2024[/COLOR][/B]', GOOJARA + 'genre/2024-movies/', 172, ART + 'goojara.png', FANART, '')
    addDir('[B][COLOR orange]2023[/COLOR][/B]', GOOJARA + 'genre/2023-movies-trends/', 172, ART + 'goojara.png', FANART, '')
    addDir('[B][COLOR orange]Έτος[/COLOR][/B]', GOOJARA + 'tainies/online/', 174, ART + 'goojara.png', FANART, '')
    addDir('[B][COLOR orange]Κατηγορίες[/COLOR][/B]', GOOJARA + 'movies/', 175, ART + 'goojara.png', FANART, '')
    addDir('[B][COLOR orange]Ταινίες - Σειρές Δράσης[/COLOR][/B]', GOOJARA + 'genre/action/', 172, ART + 'goojara.png', FANART, '')
    addDir('[B][COLOR orange]Ταινίες - Σειρές Τρόμου[/COLOR][/B]', GOOJARA + 'genre/horror/', 172, ART + 'goojara.png', FANART, '')


def menu_year(): #124
    addDir('[B][COLOR orange]2024[/COLOR][/B]', GOOJARA + 'genre/2024-movies/', 172, icon_GOOJARA, FANART, '')
    addDir('[B][COLOR orange]2023[/COLOR][/B]', GOOJARA + 'genre/2023-movies-trends/', 172, icon_GOOJARA, FANART, '')
    addDir('[B][COLOR orange]2022[/COLOR][/B]', GOOJARA + 'genre/2022-movies/', 172, icon_GOOJARA, FANART, '')
    addDir('[B][COLOR orange]2021[/COLOR][/B]', GOOJARA + 'genre/2021-movies/', 172, icon_GOOJARA, FANART, '')
    addDir('[B][COLOR orange]2020[/COLOR][/B]', GOOJARA + 'genre/2020-movies/', 172, icon_GOOJARA, FANART, '')
    addDir('[B][COLOR orange]2017[/COLOR][/B]', GOOJARA + 'genre/2017-movies/', 172, icon_GOOJARA, FANART, '')


def menu_genre(): #125
    addDir('[COLOR orange]Δράσης[/COLOR]', GOOJARA + 'genre/action/', 172, icon_GOOJARA, FANART, '')
    addDir('[COLOR orange]Περιπέτεια[/COLOR]', GOOJARA + 'genre/adventure/', 172, icon_GOOJARA, FANART, '')
    addDir('[COLOR orange]Κινούμενα Σχέδια[/COLOR]', GOOJARA + 'genre/animation/', 172, icon_GOOJARA, FANART, '')
    addDir('[COLOR orange]Βιογραφία[/COLOR]', GOOJARA + 'genre/biography-movies/', 172, icon_GOOJARA, FANART, '')
    addDir('[COLOR orange]Κωμωδία[/COLOR]', GOOJARA + 'genre/comedy/', 172, icon_GOOJARA, FANART, '')
    addDir('[COLOR orange]Αστυνομική[/COLOR]', GOOJARA + 'genre/crime/', 172, icon_GOOJARA, FANART, '')
    addDir('[COLOR orange]Ντοκιμαντέρ[/COLOR]', GOOJARA + 'genre/documentary-movies/', 172, icon_GOOJARA, FANART, '')
    addDir('[COLOR orange]Δράμα[/COLOR]', GOOJARA + 'genre/drama/', 172, icon_GOOJARA, FANART, '')
    addDir('[COLOR orange]Οικογενειακή[/COLOR]', GOOJARA + 'genre/family/', 172, icon_GOOJARA, FANART, '')
    addDir('[COLOR orange]Φαντασίας[/COLOR]', GOOJARA + 'genre/fantasy/', 172, icon_GOOJARA, FANART, '')
    addDir('[COLOR orange]Flixtor Movies[/COLOR]', GOOJARA + 'genre/flixtor-movies/', 172, icon_GOOJARA, FANART, '')
    addDir('[COLOR orange]Fzmovies Movies[/COLOR]', GOOJARA + 'genre/fzmovies-net-download/', 172, icon_GOOJARA, FANART, '')
    addDir('[COLOR orange]Ιστορική[/COLOR]', GOOJARA + 'genre/history/', 172, icon_GOOJARA, FANART, '')
    addDir('[COLOR orange]Τρόμου[/COLOR]', GOOJARA + 'genre/horror/', 172, icon_GOOJARA, FANART, '')
    addDir('[COLOR orange]Lookmovies[/COLOR]', GOOJARA + 'genre/lookmovies-ag/', 172, icon_GOOJARA, FANART, '')
    addDir('[COLOR orange]Μουσική[/COLOR]', GOOJARA + 'genre/music/', 172, icon_GOOJARA, FANART, '')
    addDir('[COLOR orange]Επ. Φαντασίας[/COLOR]', GOOJARA + 'genre/science-fiction/', 172, icon_GOOJARA, FANART, '')
    addDir('[COLOR orange]Θρίλερ[/COLOR]', GOOJARA + 'genre/thriller/', 172, icon_GOOJARA, FANART, '')
    addDir('[COLOR orange]Μυστηρίου[/COLOR]', GOOJARA + 'genre/mystery/', 172, icon_GOOJARA, FANART, '')
    addDir('[COLOR orange]Πολεμική[/COLOR]', GOOJARA + 'genre/war/', 172, icon_GOOJARA, FANART, '')
    addDir('[COLOR orange]Ρομαντική[/COLOR]', GOOJARA + 'genre/romance-movies/', 172, icon_GOOJARA, FANART, '')
    addDir('[COLOR orange]Western[/COLOR]', GOOJARA + 'genre/western-movies/', 172, icon_GOOJARA, FANART, '')



def goojara(url): #172
    hdrs = {'Referer': GOOJARA,
            'User-Agent': client.agent()}
    p = requests.get(url, headers=hdrs).text
    m = re.compile('\s+<a href="(.+?)" class=.+? title="(.+?)">.+?\s+', re.DOTALL).findall(p)

    for url, name in m:

        name = name.replace('Permanent Link to ', '')
        name = clear_Title(name)
        if not ('Pinterest' in name or 'Twitter' in name):
            addDir(name, url, 173, '' , '', '')
    try:
        m = re.compile('<link rel="next" href="(.+?)" />').findall(p)[0]
        addDir('[B][COLOR=lime]Επόμενη σελίδα >>[/COLOR][/B]', m, 172, 'http://i.imgur.com/rKSs0yq.png', FANART, '')
    except BaseException:
        pass
#    views.selectView('movies', 'movie-view')


def get_links(name, url, iconimage, description): #173
    hdrs = {'Referer': GOOJARA,
            'User-Agent': client.agent()}
    p = requests.get(url, headers=hdrs).text
    m = re.compile(' src="(.+?)" width=').findall(p)
    for url in m:
        url = url.replace(' data-litespeed-src=', '').replace('""', '').replace('about:blank', '')
        if 'dooood' in url:
            link = ' | dooood'
            name = name + link
            addDir(name, url, 100, '', '', '')
        elif 'dood' in url:
            link = ' | dood'
            name = name + link
            addDir(name, url, 100, '', '', '')
        elif 'vidsrc' in url:
            link = ' | vidsrc'
            name = name + link
            addDir(name, url, 100, '', '', '')
        elif '02tvseries' in url:
            addDir(name, url, 176, '', '', '')
        else:
            link = ' | link'
            name = name + link
            addDir(name, url, 100, '', '', '')

    else: 
        m2 = re.compile('<a href="(.+?)" target="_blank" rel="noopener">').findall(p)
        for url in m2:
            name = name.replace(' | dooood','').replace(' | dood','')
            if 'voe' in url:
                link = ' | voe'
                name = name + link
                addDir(name, url, 100, '', '', '')
            elif 'streamtape' in url:
                link = ' | streamtape'
                name = name + link
                addDir(name, url, 100, '', '', '')
            elif 'dood' in url:
                link = ' | dood'
                name = name + link
                addDir(name, url, 100, '', '', '')
            elif 'dooood' in url:
                link = ' | dooood'
                name = name + link
                addDir(name, url, 100, '', '', '')
            elif 'upstream' in url:
                link = ' | upstream'
                name = name + link
                addDir(name, url, 100, '', '', '')
            else:
                link = ' | link'
                name = name + link
                addDir(name, url, 100, '', '', '')

    try:
        m3 = re.compile('<button class="button" data-src="(.+?)">(.+?)</button>').findall(p)
        for url, epi in m3:
            epi = ' ' + epi
            addDir((name+epi), url, 100, '', '', '')
    except BaseException:
        pass


def get_links2(name, url, iconimage, description): #176
    hdrs = {'Referer': GOOJARA,
            'User-Agent': client.agent()}
    p = requests.get(url, headers=hdrs).text
    m = re.compile('<iframe src="(.+?)" width=').findall(p)
    for url in m:
        if 'vidzstore.com' in url:
            link = ' | vidzstore'
            name = name + link
            addDir(name, url, 100, '', '', '')
        elif 'filemoon' in url:
            link = ' | filemoon'
            name = name + link
            addDir(name, url, 100, '', '', '')
        elif 'vidsrc' in url:
            link = ' | vidsrc | Error'
            name = name + link
            addDir(name, url, 100, '', '', '')
        else:
            link = ' | link'
            name = name + link
            addDir(name, url, 100, '', '', '')


def search(url): #171
    keyb = xbmc.Keyboard('', 'Αναζήτηση Ταινίας...')
    keyb.doModal()
    if (keyb.isConfirmed()):
        search = keyb.getText().replace(' ', '+')
        url = GOOJARA + '?s=' + search
        goojara(url)


def clear_Title(txt):
    import six
    if six.PY2:
        txt = txt.encode('utf-8', 'ignore')
    else:
        txt = six.ensure_text(txt, encoding='utf-8', errors='ignore')
    txt = re.sub(r'<.+?>', '', txt)
    txt = re.sub(r'var\s+cp.+?document.write\(\'\'\);\s*', '', txt)
    txt = txt.replace("&quot;", "\"").replace('()', '').replace("&#038;", "&").replace('&#8211;', ':').replace('\n',
                                                                                                               ' ')
    txt = txt.replace("&amp;", "&").replace('&#8217;', "'").replace('&#039;', ':').replace('&#;', '\'').replace('&#8230;', '...')
    txt = txt.replace("&#38;", "&").replace('&#8221;', '"').replace('&#8216;', '"').replace('&#160;', '')
    txt = txt.replace("&nbsp;", "").replace('&#8220;', '"').replace('&#8216;', '"').replace('\t', ' ')
    return txt
