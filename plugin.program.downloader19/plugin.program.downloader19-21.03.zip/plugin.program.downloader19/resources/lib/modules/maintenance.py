""""""""""""""""""""""""""""""""""""""""""
"""  Believe in God - Ηelp as you can  """
""""""""""""""""""""""""""""""""""""""""""

import os, re, xbmc, xbmcgui, shutil, sqlite3
from xbmc import log
from updatervar import *
from xml.etree import ElementTree
from resources.lib.modules import db, cache, control
from resources.lib.modules.utils import addDir
try:                  # Python 3
    from urllib.parse import quote, urlparse
    from html.parser import HTMLParser
    from urllib.request import urlopen, Request, HTTPError, URLError

except ImportError:  # Python 2
    from urllib import quote
    from urlparse import urlparse
    from urllib2 import urlopen, Request, HTTPError, URLError
    import HTMLParser

home        = xbmcvfs.translatePath('special://home/')
addons_path = os.path.join(home, 'addons')
user_path   = os.path.join(home, 'userdata')
data_path   = os.path.join(user_path, 'addon_data')
SOURCES = os.path.join(user_path, 'sources.xml')
PROFILE = xbmcvfs.translatePath('special://profile/')
TEMP = xbmcvfs.translatePath('special://temp/')
ARCHIVE_CACHE = os.path.join(TEMP, 'archive_cache')
THUMBNAILS = xbmcvfs.translatePath('special://thumbnails/')
LOGPATH = xbmcvfs.translatePath('special://logpath/')
DATABASE = xbmcvfs.translatePath('special://database/')
PROFILEADDONDATA  = os.path.join(PROFILE, 'addon_data')
LOGFILES = ['log', 'xbmc.old.log', 'kodi.log']
addon_build ='[B][COLOR orange]TechNEWSology Build[/COLOR][/B]'
icon_down = 'special://home/addons/plugin.program.downloader19/icon.gif'
ADDON_ID = xbmcaddon.Addon().getAddonInfo('id')
EXCLUDES = [ADDON_ID, 'plugin.program.downloader19']
ADDON = xbmcaddon.Addon(ADDON_ID)
ADDON_NAME = ADDON.getAddonInfo('name')
ADDON_VERSION = ADDON.getAddonInfo('version')
ADDON_PATH = ADDON.getAddonInfo('path')
ADDON_ICON = ADDON.getAddonInfo('icon')
ADDON_FANART = ADDON.getAddonInfo('fanart')
KODIV = float(xbmc.getInfoLabel("System.BuildVersion")[:4])
RAM = int(xbmc.getInfoLabel("System.Memory(total)")[:-2])
DEFAULTPLUGINS = ['metadata.album.universal',
                  'metadata.artists.universal',
                  'metadata.common.fanart.tv',
                  'metadata.common.imdb.com',
                  'metadata.common.musicbrainz.org',
                  'metadata.themoviedb.org',
                  'metadata.tvdb.com',
                  'service.xbmc.versioncheck']

USER_AGENT = ('Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36'
              ' (KHTML, like Gecko) Chrome/35.0.1916.153 Safari'
              '/537.36 SE 2.X MetaSr 1.0')

COLOR1 = 'limegreen'
COLOR2 = 'white'

INCLUDEVIDEO      = control.get_setting('includevideo')
INCLUDEALL        = control.get_setting('includeall')
INCLUDESCRUBS     = control.get_setting('includescrubs')
INCLUDEBLACKLODGE = control.get_setting('includeblacklodge')
INCLUDETHECREW    = control.get_setting('includethecrew')
INCLUDEVENOM      = control.get_setting('includevenom')
INCLUDEGAIA       = control.get_setting('includegaia')
INCLUDESEREN      = control.get_setting('includeseren')
INCLUDEALIVEGR    = control.get_setting('includealivegr')
INCLUDESHADOW     = control.get_setting('includeshadow')
INCLUDEHOMELANDER = control.get_setting('includehomelander')
INCLUDEABSOLUTION = control.get_setting('includeabsolution')
INCLUDEFEN        = control.get_setting('includefen')
INCLUDEUBRELLA    = control.get_setting('includeubrella')
INCLUDEFREE99     = control.get_setting('includefree99')
INCLUDESHAZAM     = control.get_setting('includeshazam')
INCLUDEATLAS      = control.get_setting('includeatlas')


def convert_size(num, suffix='B'):
    for unit in ['', 'K', 'M', 'G']:
        if abs(num) < 1024.0:
            return "%3.02f %s%s" % (num, unit, suffix)
        num /= 1024.0
    return "%.02f %s%s" % (num, 'G', suffix)

def get_date(days=0, formatted=False):
    import time

    value = time.time() + (days * 24 * 60 * 60)  # days * 24h * 60m * 60s

    return value if not formatted else time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(value))

def get_size(path, total=0):
    for dirpath, dirnames, filenames in os.walk(path):
        for f in filenames:
            fp = os.path.join(dirpath, f)
            total += os.path.getsize(fp)
    return total

def purge_db(db):
    if os.path.exists(db):
        try:
            conn = sqlite3.connect(db)
            cur = conn.cursor()
        except Exception as e:
            xbmc.log("DB Connection Error: %s" % str(e), xbmc.LOGDEBUG)
            return False
    else: 
        xbmc.log('%s not found.' % db, xbmc.LOGINFO)
        return False
    cur.execute("SELECT name FROM sqlite_master WHERE type = 'table'")
    for table in cur.fetchall():
        if table[0] == 'version': 
            xbmc.log('Data from table `%s` skipped.' % table[0], xbmc.LOGDEBUG)
        else:
            try:
                cur.execute("DELETE FROM %s" % table[0])
                conn.commit()
                xbmc.log('Data from table `%s` cleared.' % table[0], xbmc.LOGDEBUG)
            except Exception as e:
                xbmc.log("DB Remove Table `%s` Error: %s" % (table[0], str(e)), xbmc.LOGERROR)
    conn.close()
    xbmc.log('%s DB Purging Complete.' % db, xbmc.LOGINFO)

def remove_folder(path):
    xbmc.log("Deleting Folder: {0}".format(path))
    try:
        shutil.rmtree(path, ignore_errors=True, onerror=None)
    except:
        return False

def remove_file(path):
    xbmc.log("Deleting File: {0}".format(path))
    try:
        os.remove(path)
    except:
        return False

def redo_thumbs():
    if not os.path.exists(THUMBNAILS):
        os.makedirs(THUMBNAILS)
    thumbfolders = '0123456789abcdef'
    videos = os.path.join(THUMBNAILS, 'Video', 'Bookmarks')
    for item in thumbfolders:
        foldname = os.path.join(THUMBNAILS, item)
        if not os.path.exists(foldname):
            os.makedirs(foldname)
    if not os.path.exists(videos):
        os.makedirs(videos)

def get_cache_size():
    dbfiles = [
        (os.path.join(data_path, 'plugin.video.scrubsv2', 'cache.db')),
        (os.path.join(data_path, 'plugin.video.blacklodge', 'cache.db')),
        (os.path.join(data_path, 'plugin.video.thecrew', 'cache.db')),
        (os.path.join(data_path, 'plugin.video.venom', 'cache.db')),
        (os.path.join(data_path, 'plugin.video.gaia', 'cache.db')),
        (os.path.join(data_path, 'plugin.video.seren', 'cache.db')),
        (os.path.join(data_path, 'plugin.video.shadow', 'cache.db')),
        (os.path.join(data_path, 'plugin.video.homelander', 'cache.db')),
        (os.path.join(data_path, 'plugin.video.absolution', 'cache.db')),
        (os.path.join(data_path, 'plugin.video.fen', 'cache.db')),
        (os.path.join(data_path, 'plugin.video.umbrella', 'cache.db')),
        (os.path.join(data_path, 'plugin.video.free99', 'cache.db')),
        (os.path.join(data_path, 'plugin.video.shazam', 'cache.db')),
        (os.path.join(data_path, 'plugin.video.atlas', 'cache.db')),
        (os.path.join(data_path, 'plugin.video.AliveGR', 'cache.db')),
        (os.path.join(data_path, 'script.module.simplecache', 'simplecache.db'))]
    cachelist = [
        data_path,
        (os.path.join(home, 'cache')),
        (os.path.join(home, 'temp')),
        (os.path.join('/private/var/mobile/Library/Caches/AppleTV/Video/', 'Other')),
        (os.path.join('/private/var/mobile/Library/Caches/AppleTV/Video/', 'LocalAndRental')),
        (os.path.join(data_path,'script.module.simple.downloader')),
        (os.path.join(data_path,'plugin.video.itv','Images')),
        (os.path.join(data_path, 'script.extendedinfo', 'images')),
        (os.path.join(data_path, 'script.extendedinfo', 'TheMovieDB')),
        (os.path.join(data_path, 'script.extendedinfo', 'YouTube')),
        (os.path.join(data_path, 'plugin.program.autocompletion', 'Google')),
        (os.path.join(data_path, 'plugin.program.autocompletion', 'Bing')),
        (os.path.join(data_path, 'plugin.video.openmeta', '.storage'))]

    if not PROFILEADDONDATA == data_path:
        cachelist.append(os.path.join(PROFILEADDONDATA, 'script.module.simple.downloader'))
        cachelist.append(os.path.join(PROFILEADDONDATA, 'plugin.video.itv','Images'))
        cachelist.append(os.path.join(data_path, 'script.extendedinfo', 'images'))
        cachelist.append(os.path.join(data_path, 'script.extendedinfo', 'TheMovieDB')),
        cachelist.append(os.path.join(data_path, 'script.extendedinfo', 'YouTube')),
        cachelist.append(os.path.join(data_path, 'plugin.program.autocompletion', 'Google')),
        cachelist.append(os.path.join(data_path, 'plugin.program.autocompletion', 'Bing')),
        cachelist.append(os.path.join(data_path, 'plugin.video.openmeta', '.storage')),
        cachelist.append(PROFILEADDONDATA)

    totalsize = 0

    for item in cachelist:
        if not os.path.exists(item):
            continue
        if item not in [data_path, PROFILEADDONDATA]:
            totalsize = get_size(item, totalsize)
        else:
            for root, dirs, files in os.walk(item):
                for d in dirs:
                    if 'cache' in d.lower() and d.lower() not in ['meta_cache']:
                        totalsize = get_size(os.path.join(root, d), totalsize)

    if INCLUDEVIDEO == 'true':
        files = []
        if INCLUDEALL == 'true':
            files = dbfiles
        else:
            if INCLUDESCRUBS == 'true':
                files.append(os.path.join(data_path, 'plugin.video.scrubsv2', 'cache.db'))
            if INCLUDEBLACKLODGE == 'true':
                files.append(os.path.join(data_path, 'plugin.video.blacklodge', 'cache.db'))
            if INCLUDETHECREW == 'true':
                files.append(os.path.join(data_path, 'plugin.video.thecrew', 'cache.db'))
            if INCLUDEVENOM == 'true':
                files.append(os.path.join(data_path, 'plugin.video.venom', 'cache.db'))
            if INCLUDEGAIA == 'true':
                files.append(os.path.join(data_path, 'plugin.video.gaia', 'cache.db'))
            if INCLUDESEREN == 'true':
                files.append(os.path.join(data_path, 'plugin.video.seren', 'cache.db'))
            if INCLUDEALIVEGR == 'true':
                files.append(os.path.join(data_path, 'plugin.video.AliveGR', 'cache.db'))
            if INCLUDESHADOW == 'true':
                files.append(os.path.join(data_path, 'plugin.video.shadow', 'cache.db'))
            if INCLUDEHOMELANDER == 'true':
                files.append(os.path.join(data_path, 'plugin.video.homelander', 'cache.db'))
            if INCLUDEABSOLUTION == 'true':
                files.append(os.path.join(data_path, 'plugin.video.absolution', 'cache.db'))
            if INCLUDEFEN == 'true':
                files.append(os.path.join(data_path, 'plugin.video.fen', 'cache.db'))
            if INCLUDEUBRELLA == 'true':
                files.append(os.path.join(data_path, 'plugin.video.umbrella', 'cache.db'))
            if INCLUDEFREE99 == 'true':
                files.append(os.path.join(data_path, 'plugin.video.free99', 'cache.db'))
            if INCLUDESHAZAM == 'true':
                files.append(os.path.join(data_path, 'plugin.video.shazam', 'cache.db'))
            if INCLUDEATLAS == 'true':
                files.append(os.path.join(data_path, 'plugin.video.atlas', 'cache.db'))

        if len(files) > 0:
            for item in files:
                if not os.path.exists(item):
                    continue
                totalsize += os.path.getsize(item)
        else:
            xbmc.log("Clear Cache: Clear Video Cache Not Enabled")

    return totalsize

def get_provider_size():
    dbfiles = [
        (os.path.join(data_path, 'plugin.video.scrubsv2', 'providers.db')),
        (os.path.join(data_path, 'plugin.video.blacklodge', 'providers.13.db')),
        (os.path.join(data_path, 'plugin.video.thecrew', 'providers.13.db')),
        (os.path.join(data_path, 'plugin.video.venom', 'providers.db')),
        (os.path.join(data_path, 'plugin.video.seren', 'providers.db')),
        (os.path.join(data_path, 'plugin.video.shadow', 'providers.db')),
        (os.path.join(data_path, 'plugin.video.homelander', 'providers.13.db')),
        (os.path.join(data_path, 'plugin.video.absolution', 'providers.13.db')),
        (os.path.join(data_path, 'plugin.video.fen', 'providerscache2.db')),
        (os.path.join(data_path, 'plugin.video.umbrella', 'providers.db')),
        (os.path.join(data_path, 'plugin.video.free99', 'providers.db')),
        (os.path.join(data_path, 'plugin.video.shazam', 'providers.13.db'))]
    providerlist = [
        data_path,
        (os.path.join(home, 'cache')),
        (os.path.join(home, 'temp')),
        (os.path.join('/private/var/mobile/Library/Caches/AppleTV/Video/', 'Other')),
        (os.path.join('/private/var/mobile/Library/Caches/AppleTV/Video/', 'LocalAndRental')),
        (os.path.join(data_path,'script.module.simple.downloader')),
        (os.path.join(data_path,'plugin.video.itv','Images')),
        (os.path.join(data_path, 'script.extendedinfo', 'images')),
        (os.path.join(data_path, 'script.extendedinfo', 'TheMovieDB')),
        (os.path.join(data_path, 'script.extendedinfo', 'YouTube')),
        (os.path.join(data_path, 'plugin.program.autocompletion', 'Google')),
        (os.path.join(data_path, 'plugin.program.autocompletion', 'Bing')),
        (os.path.join(data_path, 'plugin.video.openmeta', '.storage'))]

    if not PROFILEADDONDATA == data_path:
        providerlist.append(os.path.join(PROFILEADDONDATA, 'script.module.simple.downloader'))
        providerlist.append(os.path.join(PROFILEADDONDATA, 'plugin.video.itv','Images'))
        providerlist.append(os.path.join(data_path, 'script.extendedinfo', 'images'))
        providerlist.append(os.path.join(data_path, 'script.extendedinfo', 'TheMovieDB')),
        providerlist.append(os.path.join(data_path, 'script.extendedinfo', 'YouTube')),
        providerlist.append(os.path.join(data_path, 'plugin.program.autocompletion', 'Google')),
        providerlist.append(os.path.join(data_path, 'plugin.program.autocompletion', 'Bing')),
        providerlist.append(os.path.join(data_path, 'plugin.video.openmeta', '.storage')),
        providerlist.append(PROFILEADDONDATA)

    totalsize = 0

    for item in providerlist:
        if not os.path.exists(item):
            continue
        if item not in [data_path, PROFILEADDONDATA]:
            totalsize = get_size(item, totalsize)
        else:
            for root, dirs, files in os.walk(item):
                for d in dirs:
                    if 'cache' in d.lower() and d.lower() not in ['meta_cache']:
                        totalsize = get_size(os.path.join(root, d), totalsize)

    if INCLUDEVIDEO == 'true':
        files = []
        if INCLUDEALL == 'true':
            files = dbfiles
        else:
            if INCLUDESCRUBS == 'true':
                files.append(os.path.join(data_path, 'plugin.video.scrubsv2', 'providers.db'))
            if INCLUDEBLACKLODGE == 'true':
                files.append(os.path.join(data_path, 'plugin.video.blacklodge', 'providers.13.db'))
            if INCLUDETHECREW == 'true':
                files.append(os.path.join(data_path, 'plugin.video.thecrew', 'providers.13.db'))
            if INCLUDEVENOM == 'true':
                files.append(os.path.join(data_path, 'plugin.video.venom', 'providers.db'))
            if INCLUDESEREN == 'true':
                files.append(os.path.join(data_path, 'plugin.video.seren', 'providers.db'))
            if INCLUDESHADOW == 'true':
                files.append(os.path.join(data_path, 'plugin.video.shadow', 'providers.db'))
            if INCLUDEHOMELANDER == 'true':
                files.append(os.path.join(data_path, 'plugin.video.homelander', 'providers.13.db'))
            if INCLUDEABSOLUTION == 'true':
                files.append(os.path.join(data_path, 'plugin.video.absolution', 'providers.13.db'))
            if INCLUDEFEN == 'true':
                files.append(os.path.join(data_path, 'plugin.video.fen', 'providerscache2.db'))
            if INCLUDEUBRELLA == 'true':
                files.append(os.path.join(data_path, 'plugin.video.umbrella', 'providers.db'))
            if INCLUDEFREE99 == 'true':
                files.append(os.path.join(data_path, 'plugin.video.free99', 'providers.db'))
            if INCLUDESHAZAM == 'true':
                files.append(os.path.join(data_path, 'plugin.video.shazam', 'providers.13.db'))

        if len(files) > 0:
            for item in files:
                if not os.path.exists(item):
                    continue
                totalsize += os.path.getsize(item)
        else:
            xbmc.log("Clear Cache: Clear Video Cache Not Enabled")

    return totalsize

def total_clean():
    dialog = xbmcgui.Dialog()
    if dialog.yesno(addon_build,
                        '[B][COLOR white]Εκκαθάριση:[/COLOR][/B][COLOR lime][CR]Cache[CR]Providers[CR]Packages[CR]Thumbnails[CR]Archive Cache[CR]ResolveUrl Reset Cache[/COLOR]'.format(COLOR2),
                        nolabel='[B][COLOR orange]Ακύρωση[/COLOR][/B]',
                        yeslabel='[B][COLOR lime]Εκκαθάριση Όλων[/COLOR][/B]'):
        clear_archive(type=True)
        clear_packages()
        cache.clear_cache()
        cache.clear_provider()
        clear_function_cache(over=True)
        clear_thumbs('total')

def clear_archive(type=None):
    dialog = xbmcgui.Dialog()
    if type is not None:
        choice = 1
    else:
        choice = dialog.yesno(addon_name,
                            '[COLOR {0}]Θέλετε να διαγράψετε το φάκελο \'Archive_Cache\'?[/COLOR]'.format(COLOR2),
                            nolabel='[B][COLOR red]Όχι, Ακύρωση[/COLOR][/B]',
                            yeslabel='[B][COLOR springgreen]Ναι[/COLOR][/B]')
        if os.path.exists(ARCHIVE_CACHE):
            clean_house(ARCHIVE_CACHE)

    if choice == 1:
                    if os.path.exists(ARCHIVE_CACHE):
                        clean_house(ARCHIVE_CACHE)

def clear_thumbs(type=None):
    dialog = xbmcgui.Dialog()
    thumb_locations = {THUMBNAILS,
                       os.path.join(data_path, 'script.module.metadatautils', 'animatedgifs'),
                       os.path.join(data_path, 'script.extendedinfo', 'images')}

    latest = db.latest_db('Textures')
    if type is not None:
        choice = 1
    else:
        choice = dialog.yesno(addon_name, '[COLOR {0}]Would you like to delete the {1} and related thumbnail folders?'.format(COLOR2, latest) + '\n' + "They will repopulate on the next startup[/COLOR]", nolabel='[B][COLOR red]Don\'t Delete[/COLOR][/B]', yeslabel='[B][COLOR springgreen]Delete Thumbs[/COLOR][/B]')
    if choice == 1:
        try:
            remove_file(os.path.join(DATABASE, latest))
        except:
            xbmc.log('Failed to delete, Purging DB.')
            db.purge_db_file(latest)
        for i in thumb_locations:
            remove_folder(i)
    else:
        xbmc.log('Clear thumbnames cancelled')

    redo_thumbs()

def clear_function_cache(over=False):
    if xbmc.getCondVisibility('System.HasAddon(script.module.resolveurl)'):
        xbmc.executebuiltin('RunPlugin(plugin://script.module.resolveurl/?mode=reset_cache)')
    if xbmc.getCondVisibility('System.HasAddon(script.module.urlresolver)'):
        xbmc.executebuiltin('RunPlugin(plugin://script.module.urlresolver/?mode=reset_cache)')


def old_thumbs():
    dbfile = os.path.join(DATABASE, db.latest_db('Textures'))
    use = 30
    week = get_date(days=-7)
    ids = []
    images = []
    size = 0
    if os.path.exists(dbfile):
        try:
            textdb = database.connect(dbfile, isolation_level=None)
            textexe = textdb.cursor()
        except Exception as e:
            xbmc.log("DB Connection Error: {0}".format(str(e)), level=xbmc.LOGERROR)
            return False
    else:
        xbmc.log('{0} not found.'.format(dbfile), level=xbmc.LOGERROR)
        return False
    textexe.execute("SELECT idtexture FROM sizes WHERE usecount < ? AND lastusetime < ?", (use, str(week)))
    found = textexe.fetchall()
    for rows in found:
        idfound = rows[0]
        ids.append(idfound)
        textexe.execute("SELECT cachedurl FROM texture WHERE id = ?", (idfound, ))
        found2 = textexe.fetchall()
        for rows2 in found2:
            images.append(rows2[0])
    xbmc.log("{0} total thumbs cleaned up.".format(str(len(images))))
    for id in ids:
        textexe.execute("DELETE FROM sizes WHERE idtexture = ?", (id, ))
        textexe.execute("DELETE FROM texture WHERE id = ?", (id, ))
    textexe.execute("VACUUM")
    textdb.commit()
    textexe.close()
    for image in images:
        path = os.path.join(CONFIG.THUMBNAILS, image)
        try:
            imagesize = os.path.getsize(path)
            os.remove(path)
            size += imagesize
        except:
            pass
    removed = convert_size(size)
    if len(images) > 0:
        xbmcgui.Dialog().notification(addon_name , '[COLOR {0}]Clear Thumbs: {1} Files / {2} MB[/COLOR]!'.format(COLOR2, str(len(images)), removed), icon_down, sound=False)

    else:
        xbmcgui.Dialog().notification(addon_name , '[COLOR {0}]Clear Thumbs: None Found![/COLOR]'.format(COLOR2), icon_down, sound=False)

def clear_crash():
    files = []
    for file in glob.glob(os.path.join(LOGPATH, '*crashlog*.*')):
        files.append(file)
    if len(files) > 0:
        dialog = xbmcgui.Dialog()

        if dialog.yesno(addon_name,
                            '[COLOR {0}]Would you like to delete the Crash logs?'.format(COLOR2)
                            +'\n'+'[COLOR {0}]{1}[/COLOR] Files Found[/COLOR]'.format(COLOR1, len(files)),
                            yeslabel="[B][COLOR springgreen]Remove Logs[/COLOR][/B]",
                            nolabel="[B][COLOR red]Keep Logs[/COLOR][/B]"):
            for f in files:
                os.remove(f)
            xbmcgui.Dialog().notification('[COLOR {0}]Clear Crash Logs[/COLOR]'.format(COLOR1) , '[COLOR {0}]{1} Crash Logs Removed[/COLOR]'.format(COLOR2, len(files)), icon_down, sound=False)
        else:
            xbmcgui.Dialog().notification(addon_name , '[COLOR {0}]Clear Crash Logs Cancelled[/COLOR]'.format(COLOR2), icon_down, sound=False)

    else:
        xbmcgui.Dialog().notification('[COLOR {0}]Clear Crash Logs[/COLOR]'.format(COLOR1) , '[COLOR {0}]No Crash Logs Found[/COLOR]'.format(COLOR2), icon_down, sound=False)

def clear_pack(over=None): ###################
    from resources.libs.common import tools

    if os.path.exists(packages):
        try:
            for root, dirs, files in os.walk(packages):
                file_count = 0
                file_count += len(files)
                if file_count > 0:
                    size = convert_size(get_size(packages))
                    if over:
                        yes = 1
                    else:
                        dialog = xbmcgui.Dialog()
                    
                        yes = dialog.yesno("[COLOR {0}]Delete Package Files[/COLOR]".format(CONFIG.COLOR2), "[COLOR {0}]{1}[/COLOR] files found / [COLOR {2}]{3}[/COLOR] in size.".format(CONFIG.COLOR1, str(file_count),CONFIG.COLOR1, size) + '\n' + "Do you want to delete them?", nolabel='[B][COLOR red]Don\'t Clear[/COLOR][/B]', yeslabel='[B][COLOR springgreen]Clear Packages[/COLOR][/B]')
                    if yes:
                        for f in files:
                            os.unlink(os.path.join(root, f))
                        for d in dirs:
                            shutil.rmtree(os.path.join(root, d))
                        logging.log_notify(CONFIG.ADDONTITLE,
                                  '[COLOR {0}]Clear Packages: Success![/COLOR]'.format(CONFIG.COLOR2))
                else:
                    logging.log_notify(CONFIG.ADDONTITLE,
                              '[COLOR {0}]Clear Packages: None Found![/COLOR]'.format(CONFIG.COLOR2))
        except Exception as e:
            logging.log_notify(CONFIG.ADDONTITLE,
                      '[COLOR {0}]Clear Packages: Error![/COLOR]'.format(CONFIG.COLOR2))
            xbmc.log("Clear Packages Error: {0}".format(str(e)), level=xbmc.LOGERROR)
    else:
        logging.log_notify(CONFIG.ADDONTITLE,
                  '[COLOR {0}]Clear Packages: None Found![/COLOR]'.format(CONFIG.COLOR2))

def clear_packages_starting():
    if not setting('clear_packages') == 'false':
        file_count = len([name for name in os.listdir(packages)])
        if file_count > 0:
            for filename in os.listdir(packages):
                file_path = os.path.join(packages, filename)
                try:
                    if os.path.isfile(file_path) or os.path.islink(file_path):
                        os.unlink(file_path)
                    elif os.path.isdir(file_path):
                        shutil.rmtree(file_path)
                except Exception as e:
                    xbmc.log('Failed to delete %s. Reason: %s' % (file_path, e), xbmc.LOGINFO)
            xbmc.sleep(1000)
            if file_count == 1:
                xbmcgui.Dialog().notification(addon_name , '[COLOR lime]Eκκαθάριση:[/COLOR]' + '[B][COLOR white] %s [/COLOR][/B]' % file_count + '[COLOR white]πακέτoυ![/COLOR]', icon_down, sound=False)
            else:
                xbmcgui.Dialog().notification(addon_name , '[COLOR lime]Eκκαθάριση:[/COLOR]' + '[B][COLOR white] %s [/COLOR][/B]' % file_count + '[COLOR white]πακέτων![/COLOR]', icon_down, sound=False)
            return

def clear_packages():
    file_count = len([name for name in os.listdir(packages)])
    for filename in os.listdir(packages):
        file_path = os.path.join(packages, filename)
        try:
            if os.path.isfile(file_path) or os.path.islink(file_path):
                os.unlink(file_path)
            elif os.path.isdir(file_path):
                shutil.rmtree(file_path)
        except Exception as e:
            xbmc.log('Failed to delete %s. Reason: %s' % (file_path, e), xbmc.LOGINFO)
    xbmc.sleep(1000)
    if file_count == 1:
        xbmcgui.Dialog().notification(addon_name , '[COLOR lime]Eκκαθάριση:[/COLOR]' + '[B][COLOR white] %s [/COLOR][/B]' % file_count + '[COLOR white]πακέτoυ![/COLOR]', icon_down, sound=False)
    elif file_count == 0:
        xbmcgui.Dialog().notification(addon_name , '[COLOR lime]Eκκαθάριση: [COLOR white]Δεν βρέθηκαν πακέτα![/COLOR]', icon_down, sound=False)
    else:
        xbmcgui.Dialog().notification(addon_name , '[COLOR lime]Eκκαθάριση:[/COLOR]' + '[B][COLOR white] %s [/COLOR][/B]' % file_count + '[COLOR white]πακέτων![/COLOR]', icon_down, sound=False)
    return

def clear_thumbnails():
    try:
        if os.path.exists(os.path.join(user_path, 'Thumbnails')):
            shutil.rmtree(os.path.join(user_path, 'Thumbnails'))
    except Exception as e:
            xbmc.log('Failed to delete %s. Reason: %s' % (os.path.join(user_path, 'Thumbnails'), e), xbmc.LOGINFO)
            return
    try:
        if os.path.exists(os.path.join(db_path, 'Textures13.db')):
            os.unlink(os.path.join(db_path, 'Textures13.db'))
    except:
        purge_db(textures_db)
    xbmc.sleep(1000)
    xbmcgui.Dialog().ok(addon_name, '[CR]                  [B][COLOR lime]Πραγματοποιήθηκε εκκαθάριση των Μικρογραφιών[CR][CR]                  [B][COLOR white]Επανεκκίνηση του Kodi για ανανέωση![/COLOR][/B]')
#    xbmcgui.Dialog().notification(addon_name , '[COLOR lime]Πραγματοποιήθηκε εκκαθάριση Μικρογραφιών[/COLOR]', icon_down, sound=False)

    return

def clear_cache(over=None):
    PROFILEADDONDATA = os.path.join(PROFILE,'addon_data')
    dbfiles = [
        (os.path.join(data_path, 'plugin.video.gaia', 'cache.db')),
        (os.path.join(data_path, 'plugin.video.gaia', 'meta.db')),

        (os.path.join(data_path, 'plugin.video.exodusredux', 'cache.db')),
        (os.path.join(data_path, 'plugin.video.exodusredux', 'meta.5.db')),
        (os.path.join(data_path, 'plugin.video.exodusredux', 'providers.13.db')),

        (os.path.join(data_path, 'plugin.video.thecrew', 'cache.db')),
        (os.path.join(data_path, 'plugin.video.thecrew', 'meta.5.db')),
        (os.path.join(data_path, 'plugin.video.thecrew', 'providers.13.db')),

        (os.path.join(data_path, 'plugin.video.venom', 'cache.db')),
        (os.path.join(data_path, 'plugin.video.venom', 'meta.5.db')),
        (os.path.join(data_path, 'plugin.video.venom', 'cache.providers.db')),

        (os.path.join(data_path, 'plugin.video.numbersbynumbers', 'cache.db')),
        (os.path.join(data_path, 'plugin.video.numbersbynumbers', 'meta.5.db')),
        (os.path.join(data_path, 'plugin.video.numbersbynumbers', 'providers.13.db')),

        (os.path.join(data_path, 'plugin.video.scrubsv2', 'cache.db')),
        (os.path.join(data_path, 'plugin.video.scrubsv2', 'meta.5.db')),
        (os.path.join(data_path, 'plugin.video.scrubsv2', 'providers.db')),

        (os.path.join(data_path, 'plugin.video.blacklodge', 'cache.db')),
        (os.path.join(data_path, 'plugin.video.blacklodge', 'meta.5.db')),
        (os.path.join(data_path, 'plugin.video.blacklodge', 'providers.13.db')),

        (os.path.join(data_path, 'plugin.video.seren', 'cache.db')),
        (os.path.join(data_path, 'plugin.video.seren', 'torrentScrape.db')),

        (os.path.join(data_path, 'script.module.simplecache', 'simplecache.db'))]

    cachelist = [
        PROFILEADDONDATA,
        data_path,
        (os.path.join(home, 'cache')),
        (os.path.join(home, 'temp')),
        (os.path.join('/private/var/mobile/Library/Caches/AppleTV/Video/', 'Other')),
        (os.path.join('/private/var/mobile/Library/Caches/AppleTV/Video/', 'LocalAndRental')),
        (os.path.join(data_path, 'script.module.simple.downloader')),
        (os.path.join(data_path, 'plugin.video.itv', 'Images')),
        (os.path.join(PROFILEADDONDATA, 'script.module.simple.downloader')),
        (os.path.join(PROFILEADDONDATA, 'plugin.video.itv', 'Images')),
        (os.path.join(data_path, 'script.extendedinfo', 'images')),
        (os.path.join(data_path, 'script.extendedinfo', 'TheMovieDB')),
        (os.path.join(data_path, 'script.extendedinfo', 'YouTube')),
        (os.path.join(data_path, 'plugin.program.autocompletion', 'Google')),
        (os.path.join(data_path, 'plugin.program.autocompletion', 'Bing')),
        (os.path.join(data_path, 'plugin.video.openmeta', '.storage'))]

    delfiles = 0
    excludes = ['meta_cache', 'archive_cache']
    for item in cachelist:
        if not os.path.exists(item):
            continue
        if item not in [data_path, PROFILEADDONDATA]:
            for root, dirs, files in os.walk(item):
                dirs[:] = [d for d in dirs if d not in excludes]
                file_count = 0
                file_count += len(files)
                if file_count > 0:
                    for f in files:
                        if f not in LOGFILES:
                            try:
                                os.unlink(os.path.join(root, f))
                                xbmc.log("[Wiped] {0}".format(os.path.join(root, f)))
                                delfiles += 1
                            except:
                                pass
                        else:
                            xbmc.log('Ignore Log File: {0}'.format(f))
                    for d in dirs:
                        try:
                            shutil.rmtree(os.path.join(root, d))
                            delfiles += 1
                            xbmc.log("[Success] cleared {0} files from {1}".format(str(file_count), os.path.join(item, d)),
                                        level=xbmc.LOGINFO)
                        except:
                            xbmc.log("[Failed] to wipe cache in: {0}".format(os.path.join(item, d)),
                                        level=xbmc.LOGINFO)
        else:
            for root, dirs, files in os.walk(item):
                dirs[:] = [d for d in dirs if d not in excludes]
                for d in dirs:
                    if not str(d.lower()).find('cache') == -1:
                        try:
                            shutil.rmtree(os.path.join(root, d))
                            delfiles += 1
                            xbmc.log("[Success] wiped {0} ".format(os.path.join(root, d)))
                        except:
                            xbmc.log("[Failed] to wipe cache in: {0}".format(os.path.join(item, d)))

    if INCLUDEVIDEO == 'true' and over is None:
        files = []
        if INCLUDEALL == 'true':
            files = dbfiles
        else:
            if INCLUDEEXODUSREDUX == 'true':
                files.append(os.path.join(data_path, 'plugin.video.exodusredux', 'cache.db'))
                files.append(os.path.join(data_path, 'plugin.video.exodusredux', 'meta.5.db'))
                files.append(os.path.join(data_path, 'plugin.video.exodusredux', 'providers.13.db'))
            if INCLUDEVENOM == 'true':
                files.append(os.path.join(data_path, 'plugin.video.venom', 'cache.db'))
                files.append(os.path.join(data_path, 'plugin.video.venom', 'meta.5.db'))
                files.append(os.path.join(data_path, 'plugin.video.venom', 'providers.db'))
            if INCLUDENUMBERS == 'true':
                files.append(os.path.join(data_path, 'plugin.video.numbersbynumbers', 'cache.db'))
                files.append(os.path.join(data_path, 'plugin.video.numbersbynumbers', 'meta.5.db'))
                files.append(os.path.join(data_path, 'plugin.video.numbersbynumbers', 'providers.13.db'))
            if INCLUDESCRUBS == 'true':
                files.append(os.path.join(data_path, 'plugin.video.scrubsv2', 'cache.db'))
                files.append(os.path.join(data_path, 'plugin.video.scrubsv2', 'meta.5.db'))
                files.append(os.path.join(data_path, 'plugin.video.scrubsv2', 'providers.db'))
            if INCLUDEBLACKLODGE == 'true':
                files.append(os.path.join(data_path, 'plugin.video.blacklodge', 'cache.db'))
                files.append(os.path.join(data_path, 'plugin.video.blacklodge', 'meta.5.db'))
                files.append(os.path.join(data_path, 'plugin.video.blacklodge', 'providers.13.db'))
            if INCLUDETHECREW == 'true':
                files.append(os.path.join(data_path, 'plugin.video.thecrew', 'cache.db'))
                files.append(os.path.join(data_path, 'plugin.video.thecrew', 'meta.5.db'))
                files.append(os.path.join(data_path, 'plugin.video.thecrew', 'providers.13.db'))
            if INCLUDEGAIA == 'true':
                files.append(os.path.join(data_path, 'plugin.video.gaia', 'cache.db'))
                files.append(os.path.join(data_path, 'plugin.video.gaia', 'meta.db'))
            if INCLUDESEREN == 'true':
                files.append(os.path.join(data_path, 'plugin.video.seren', 'cache.db'))
                files.append(os.path.join(data_path, 'plugin.video.seren', 'torrentScrape.db'))
        if len(files) > 0:
            for item in files:
                if os.path.exists(item):
                    delfiles += 1
                    try:
                        textdb = database.connect(item)
                        textexe = textdb.cursor()
                    except Exception as e:
                        xbmc.log("DB Connection error: {0}".format(str(e)), level=xbmc.LOGERROR)
                        continue
                    if 'Database' in item:
                        try:
                            textexe.execute("DELETE FROM url_cache")
                            textexe.execute("VACUUM")
                            textdb.commit()
                            textexe.close()
                            xbmc.log("[Success] wiped {0}".format(item))
                        except Exception as e:
                            xbmc.log("[Failed] wiped {0}: {1}".format(item, str(e)))
                    else:
                        textexe.execute("SELECT name FROM sqlite_master WHERE type = 'table'")
                        for table in textexe.fetchall():
                            try:
                                textexe.execute("DELETE FROM {0}".format(table[0]))
                                textexe.execute("VACUUM")
                                textdb.commit()
                                xbmc.log("[Success] wiped {0} in {1}".format(table[0], item))
                            except Exception as e:
                                try:
                                    xbmc.log("[Failed] wiped {0} in {1}: {2}".format(table[0], item, str(e)))
                                except:
                                    pass
                        textexe.close()
        else:
            xbmc.log("Clear Cache: Clear Video Cache Not Enabled")
    xbmcgui.Dialog().notification(addon_build , '[COLOR {0}]Clear Cache: Removed {1} Files[/COLOR]'.format(COLOR2, delfiles), icon_down, sound=False)

def clear_provider(over=None):
    PROFILEADDONDATA = os.path.join(PROFILE,'addon_data')
    dbfiles = [
        (os.path.join(data_path, 'plugin.video.scrubsv2', 'providers.db')),
        (os.path.join(data_path, 'plugin.video.blacklodge', 'providers.13.db')),
        (os.path.join(data_path, 'plugin.video.thecrew', 'providers.13.db')),
        (os.path.join(data_path, 'plugin.video.venom', 'providers.db')),
        (os.path.join(data_path, 'plugin.video.seren', 'providers.db')),
        (os.path.join(data_path, 'plugin.video.shadow', 'providers.db')),
        (os.path.join(data_path, 'plugin.video.homelander', 'providers.13.db')),
        (os.path.join(data_path, 'plugin.video.absolution', 'providers.13.db')),
        (os.path.join(data_path, 'plugin.video.fen', 'providerscache2.db')),
        (os.path.join(data_path, 'plugin.video.umbrella', 'providers.db')),
        (os.path.join(data_path, 'plugin.video.free99', 'providers.db')),
        (os.path.join(data_path, 'plugin.video.shazam', 'providers.13.db'))]
    providerlist = [
        PROFILEADDONDATA,
        data_path,
        (os.path.join(home, 'cache')),
        (os.path.join(home, 'temp')),
        (os.path.join('/private/var/mobile/Library/Caches/AppleTV/Video/', 'Other')),
        (os.path.join('/private/var/mobile/Library/Caches/AppleTV/Video/', 'LocalAndRental')),
        (os.path.join(data_path, 'script.module.simple.downloader')),
        (os.path.join(data_path, 'plugin.video.itv', 'Images')),
        (os.path.join(PROFILEADDONDATA, 'script.module.simple.downloader')),
        (os.path.join(PROFILEADDONDATA, 'plugin.video.itv', 'Images')),
        (os.path.join(data_path, 'script.extendedinfo', 'images')),
        (os.path.join(data_path, 'script.extendedinfo', 'TheMovieDB')),
        (os.path.join(data_path, 'script.extendedinfo', 'YouTube')),
        (os.path.join(data_path, 'plugin.program.autocompletion', 'Google')),
        (os.path.join(data_path, 'plugin.program.autocompletion', 'Bing')),
        (os.path.join(data_path, 'plugin.video.openmeta', '.storage'))]

    delfiles = 0
    excludes = ['meta_cache', 'archive_cache']
    for item in providerlist:
        if not os.path.exists(item):
            continue
        if item not in [data_path, PROFILEADDONDATA]:
            for root, dirs, files in os.walk(item):
                dirs[:] = [d for d in dirs if d not in excludes]
                file_count = 0
                file_count += len(files)
                if file_count > 0:
                    for f in files:
                        if f not in LOGFILES:
                            try:
                                os.unlink(os.path.join(root, f))
                                xbmc.log("[Wiped] {0}".format(os.path.join(root, f)))
                                delfiles += 1
                            except:
                                pass
                        else:
                            xbmc.log('Ignore Log File: {0}'.format(f))
                    for d in dirs:
                        try:
                            shutil.rmtree(os.path.join(root, d))
                            delfiles += 1
                            xbmc.log("[Success] cleared {0} files from {1}".format(str(file_count), os.path.join(item, d)),
                                        level=xbmc.LOGINFO)
                        except:
                            xbmc.log("[Failed] to wipe cache in: {0}".format(os.path.join(item, d)),
                                        level=xbmc.LOGINFO)
        else:
            for root, dirs, files in os.walk(item):
                dirs[:] = [d for d in dirs if d not in excludes]
                for d in dirs:
                    if not str(d.lower()).find('cache') == -1:
                        try:
                            shutil.rmtree(os.path.join(root, d))
                            delfiles += 1
                            xbmc.log("[Success] wiped {0} ".format(os.path.join(root, d)))
                        except:
                            xbmc.log("[Failed] to wipe cache in: {0}".format(os.path.join(item, d)))

    if INCLUDEVIDEO == 'true' and over is None:
        files = []
        if INCLUDEALL == 'true':
            files = dbfiles
        else:
            if INCLUDESCRUBS == 'true':
                files.append(os.path.join(data_path, 'plugin.video.scrubsv2', 'providers.db'))
            if INCLUDEBLACKLODGE == 'true':
                files.append(os.path.join(data_path, 'plugin.video.blacklodge', 'providers.13.db'))
            if INCLUDETHECREW == 'true':
                files.append(os.path.join(data_path, 'plugin.video.thecrew', 'providers.13.db'))
            if INCLUDEVENOM == 'true':
                files.append(os.path.join(data_path, 'plugin.video.venom', 'providers.db'))
            if INCLUDESEREN == 'true':
                files.append(os.path.join(data_path, 'plugin.video.seren', 'providers.db'))
            if INCLUDESHADOW == 'true':
                files.append(os.path.join(data_path, 'plugin.video.shadow', 'providers.db'))
            if INCLUDEHOMELANDER == 'true':
                files.append(os.path.join(data_path, 'plugin.video.homelander', 'providers.13.db'))
            if INCLUDEABSOLUTION == 'true':
                files.append(os.path.join(data_path, 'plugin.video.absolution', 'providers.13.db'))
            if INCLUDEFEN == 'true':
                files.append(os.path.join(data_path, 'plugin.video.fen', 'providerscache2.db'))
            if INCLUDEUBRELLA == 'true':
                files.append(os.path.join(data_path, 'plugin.video.umbrella', 'providers.db'))
            if INCLUDEFREE99 == 'true':
                files.append(os.path.join(data_path, 'plugin.video.free99', 'providers.db'))
            if INCLUDESHAZAM == 'true':
                files.append(os.path.join(data_path, 'plugin.video.shazam', 'providers.13.db'))
        if len(files) > 0:
            for item in files:
                if os.path.exists(item):
                    delfiles += 1
                    try:
                        textdb = database.connect(item)
                        textexe = textdb.cursor()
                    except Exception as e:
                        xbmc.log("DB Connection error: {0}".format(str(e)), level=xbmc.LOGERROR)
                        continue
                    if 'Database' in item:
                        try:
                            textexe.execute("DELETE FROM url_cache")
                            textexe.execute("VACUUM")
                            textdb.commit()
                            textexe.close()
                            xbmc.log("[Success] wiped {0}".format(item))
                        except Exception as e:
                            xbmc.log("[Failed] wiped {0}: {1}".format(item, str(e)))
                    else:
                        textexe.execute("SELECT name FROM sqlite_master WHERE type = 'table'")
                        for table in textexe.fetchall():
                            try:
                                textexe.execute("DELETE FROM {0}".format(table[0]))
                                textexe.execute("VACUUM")
                                textdb.commit()
                                xbmc.log("[Success] wiped {0} in {1}".format(table[0], item))
                            except Exception as e:
                                try:
                                    xbmc.log("[Failed] wiped {0} in {1}: {2}".format(table[0], item, str(e)))
                                except:
                                    pass
                        textexe.close()
        else:
            xbmc.log("Clear Cache: Clear Video Cache Not Enabled")
    xbmcgui.Dialog().notification(addon_build , '[COLOR {0}]Clear Cache: Removed {1} Files[/COLOR]'.format(COLOR2, delfiles), icon_down, sound=False)

def advanced_settings():
    selection = xbmcgui.Dialog().select('[COLOR orange]Επιλέξτε το μέγεθος Ram της συσκευής σας[/COLOR]',
                                       ['[B][COLOR white]Συσκευές =>[COLOR orange] 1GB[/COLOR][/B]',
                                        '[B][COLOR white]Συσκευές =>[COLOR orange] 1.5GB[/COLOR][/B]',
                                        '[B][COLOR white]Συσκευές =>[COLOR orange] 2GB[/COLOR][/B]',
                                        '[B][COLOR white]Συσκευές =>[COLOR orange] 3GB και πάνω[/COLOR][/B]',
                                        '[B][COLOR orange]Επαναφορά στην Προεπιλογή[/COLOR][/B]',
                                        '[B][COLOR red]Διαγραφή [COLOR grey]αποθηκευμένου xml - [COLOR orange]Advanced Settings[/COLOR][/B]'])
    if selection==0:
        xml = os.path.join(advancedsettings_folder, '1g.xml')
    elif selection==1:
        xml = os.path.join(advancedsettings_folder, '1_5g.xml')
    elif selection==2:
        xml = os.path.join(advancedsettings_folder, '2g.xml')
    elif selection==3:
        xml = os.path.join(advancedsettings_folder, '3g.xml')
    elif selection==4:
        xml = os.path.join(advancedsettings_folder, 'default.xml')
    elif selection==5:
        if os.path.exists(advancedsettings_xml):
            os.unlink(advancedsettings_xml)
        xbmc.sleep(1000)
        yes_enable = dialog.yesno(addon_name, '[B][COLOR lime]Το advancedsettings.xml διαγράφηκε με επιτυχία![/COLOR][CR][CR]Επιθυμείτε να κλείσει το kodi για να αποθηκευτούν οι αλλαγές τώρα?[/B]', nolabel='[B][COLOR orange]Οχι[/COLOR][/B]',yeslabel='[B][COLOR lime]Ναι[/COLOR][/B]')
        if yes_enable:
            os._exit(1)
        else:
            return
    else:
        return
    if os.path.exists(advancedsettings_xml):
        os.unlink(advancedsettings_xml)
    shutil.copyfile(xml, advancedsettings_xml)
    xbmc.sleep(1000)
    yes_enable = dialog.yesno(addon_name, '[B][COLOR lime]Έχουν οριστεί οι απαραίτητες ρυθμίσεις![/COLOR][CR][CR]Επιθυμείτε να κλείσει το kodi για να αποθηκευτούν οι αλλαγές τώρα?[/B]', nolabel='[B][COLOR orange]Οχι[/COLOR][/B]',yeslabel='[B][COLOR lime]Ναι[/COLOR][/B]')
    if yes_enable:
        os._exit(1)
    else:
        return

def reloadProfile(profile=None):
    if profile == None:
        xbmc.executebuiltin('LoadProfile(Master user)')
    else:
        xbmc.executebuiltin('LoadProfile(%s)' % profile)

def write_to_file(file, content, mode='w'):
    f = open(file, mode, encoding='utf-8')
    f.write(content)
    f.close()

def read_from_file(file, mode='r'):
    f = open(file, mode, encoding='utf-8')
    a = f.read()
    f.close()
    return a

def file_count(home, excludes=True):
    exclude_dirs = [
        addon_id,
        'cache',
        'system',
        'packages',
        'Thumbnails',
        'peripheral_data',
        'temp',
        'My_Builds',
        'library',
        'keymaps',
        ]
    exclude_files = ['Textures13.db', '.DS_Store',
                     'advancedsettings.xml', 'Thumbs.db', '.gitignore']
    item = []
    for (base, dirs, files) in os.walk(home):
        if excludes:
            dirs[:] = [d for d in dirs if d not in exclude_dirs]
            files[:] = [f for f in files if f not in exclude_files]
        for file in files:
            item.append(file)
    return len(item)

def forceUpdate(silent=False):
    xbmc.executebuiltin('UpdateAddonRepos()')
    xbmc.executebuiltin('UpdateLocalAddons()')
    if silent == False:
        xbmcgui.Dialog().notification(addon_build, '[COLOR lime]Forcing Addon Updates[/COLOR]', icon_down, sound=False)

def percentage(part, whole):
    return 100 * float(part)/float(whole)

def convertSpecial(url, over=False):
    pd = xbmcgui.DialogProgress()
    total = file_count(url)
    start = 0
    pd.create(addon_build, "[COLOR limegreen]Changing Physical Paths To Special" + "\n" + "Please Wait[/COLOR]")
    for root, dirs, files in os.walk(url):
        for file in files:
            start += 1
            perc = int(percentage(start, total))
            if file.endswith(".xml") or file.endswith(".hash") or file.endswith("properies"):
                pd.update(perc, "[COLOR lime]Scanning: [COLOR white]{0}[/COLOR]".format(root.replace(home, '')) + '\n' + "[COLOR orange]{0}[/COLOR]".format(file) + '\n' + "Παρακαλώ περιμένετε ...[/COLOR]")
                a = read_from_file(os.path.join(root, file))
                encodedpath = quote(home)
                encodedpath2 = quote(home).replace('%3A', '%3a').replace('%5C', '%5c')
                b = a.replace(home, 'special://home/').replace(encodedpath, 'special://home/').replace(encodedpath2, 'special://home/')
                
                try:
                    write_to_file(os.path.join(root, file), b)
                except IOError as e:
                    xbmc.log('Unable to open file to convert special paths: {}'.format(os.path.join(root, file)))

                if pd.iscanceled():
                    pd.close()
                    xbmcgui.Dialog().notification(addon_build, "[COLOR white]Convert Path Cancelled[/COLOR]", icon_down, sound=False)
                    sys.exit()
    pd.close()
    xbmc.log("[Convert Paths to Special] Complete")
    if not over:
        xbmcgui.Dialog().notification(addon_build, "[COLOR white]Convert Paths to Special: [COLOR lime]Complete![/COLOR]", icon_down, sound=False)

def addon_updates(do=None):
    setting = '"general.addonupdates"'
    if do == 'set':
        query = '{{"jsonrpc":"2.0", "method":"Settings.GetSettingValue","params":{{"setting":{0}}}, "id":1}}'.format(setting)
        response = xbmc.executeJSONRPC(query)
        match = re.compile('{"value":(.+?)}').findall(response)
        if len(match) > 0:
            default = match[0]
        else:
            default = 0
        setting_set('default.addonupdate', str(default))
        query = '{{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{{"setting":{0},"value":{1}}}, "id":1}}'.format(setting, '2')
        response = xbmc.executeJSONRPC(query)
    elif do == 'reset':
        try:
            value = int(float(setting_set('default.addonupdate')))
        except:
            value = 0
        if value not in [0, 1, 2]:
            value = 0
        query = '{{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{{"setting":{0},"value":{1}}}, "id":1}}'.format(setting, value)
        response = xbmc.executeJSONRPC(query)

def empty_folder(folder):
    total = 0
    for root, dirs, files in os.walk(folder, topdown=True):
        dirs[:] = [d for d in dirs if d not in EXCLUDES]
        file_count = 0
        file_count += len(files) + len(dirs)
        if file_count == 0:
            shutil.rmtree(os.path.join(root))
            total += 1

            xbmc.log("Empty Folder: {0}".format(root))
    return total

def clean_house(folder, ignore=False):
    ADDON_ID = xbmcaddon.Addon().getAddonInfo('id')
    EXCLUDES = [ADDON_ID, 'plugin.program.downloader19']
    log(folder)
    total_files = 0
    total_folds = 0
    for root, dirs, files in os.walk(folder):
        if not ignore:
            dirs[:] = [d for d in dirs if d not in EXCLUDES]
        file_count = 0
        file_count += len(files)
        if file_count >= 0:
            for f in files:
                try:
                    os.unlink(os.path.join(root, f))
                    total_files += 1
                except:
                    try:
                        shutil.rmtree(os.path.join(root, f))
                    except:
                        xbmc.log("Error Deleting {0}".format(f), level=xbmc.LOGERROR)
            for d in dirs:
                total_folds += 1
                try:
                    shutil.rmtree(os.path.join(root, d))
                    total_folds += 1
                except:
                    xbmc.log("Error Deleting {0}".format(d), level=xbmc.LOGERROR)
    return total_files, total_folds

def remove_addon_menu():
    dialog = xbmcgui.Dialog()
    addonfolders = glob.iglob(os.path.join(addons_path, '*/'))
    addonnames = []
    addonids = []
    for folder in addonfolders:
        foldername = os.path.split(folder[:-1])[1]
        
        if foldername in addon_id:
            continue
        elif foldername in DEFAULTPLUGINS:
            continue
        elif foldername == 'packages':
            continue    
        
        xml = os.path.join(folder, 'addon.xml')
        
        if os.path.exists(xml):
            root = ElementTree.parse(xml).getroot()
            addonid = root.get('id')
            addonname = root.get('name')
            
            try:
                addonnames.append(addonname)
                addonids.append(addonid)
            except:
                pass
                
    if len(addonnames) == 0:
        xbmcgui.Dialog().notification(addon_build, "[COLOR white]Δεν υπάρχουν πρόσθετα προς κατάργηση[/COLOR]", icon_down, sound=False)
        return
    selected = dialog.multiselect("[B][COLOR orange]Επιλέξτε τα πρόσθετα που θέλετε να αφαιρέσετε:[/COLOR][/B]", addonnames)
    if not selected:
        return
    if len(selected) > 0:
        addon_updates('set')
        for addon in selected:
            remove_addon(addon=addonids[addon], name=addonnames[addon], over=True)

        xbmc.sleep(500)

        addon_updates('reset')
        if dialog.yesno('[B][COLOR orange]TechNEWSology Build[/COLOR][/B]',
                            '[COLOR white]Για να καταχωρηθούν οι αλλαγές πρέπει να γίνει επαναφόρτωση του προφίλ ή άμεση έξοδος απο το kodi[CR]Τι από τα δύο επιθυμείτε?[/COLOR]',
                            yeslabel='[B][COLOR springgreen]Reload Profile[/COLOR][/B]',
                            nolabel='[B][COLOR orange]Force Close[/COLOR][/B]'):
            reloadProfile()
        else:
            os._exit(1)

def remove_addon(addon, name, over=False, data=True):
    import sqlite3
    from resources.lib.modules import db
    if over:
        yes = 1
    else:
        dialog = xbmcgui.Dialog()
        
        yes = dialog.yesno('[B][COLOR orange]TechNEWSology Build[/COLOR][/B]',
                               '[COLOR lime]Are you sure you want to delete the add-on:'
                               +'\n'+'Name: [COLOR orange]{0}[/COLOR]'.format(name)
                               +'\n'+'ID: [COLOR orange]{0}[/COLOR][/COLOR]'.format(addon),
                               yeslabel='[B][COLOR springgreen]Remove Add-on[/COLOR][/B]',
                               nolabel='[B][COLOR red]Don\'t Remove[/COLOR][/B]')
    if yes == 1:
        folder = os.path.join(addons_path, addon)
        xbmc.log("Removing Add-on: {0}".format(addon))

        clean_house(folder)
        xbmc.sleep(200)
        
        xbmc.executebuiltin('StopScript({0})'.format(addon))
        
        sqldb = sqlite3.connect(os.path.join(db_path, db.latest_db('Addons')))
        sqlexe = sqldb.cursor()
        query = "DELETE FROM {0} WHERE addonID = '{1}'"
        
        for table in ['addons', 'installed', 'package']:
            sqlexe.execute(query.format(table, addon))
        
        try:
            shutil.rmtree(folder)
        except Exception as e:
            xbmc.log("Error removing {0}: {1}".format(addon, str(e)))
        
        if data:
            remove_addon_data(addon)
            
        return True
            
    if not over:
        xbmcgui.Dialog().notification(addon_build, "[COLOR red] Removed {0}[/COLOR]".format(name), icon_down, sound=False)

def remove_addon_data(addon):
    dialog = xbmcgui.Dialog()
    if addon == 'all':
        if dialog.yesno(addon_build,
                        '[COLOR white]Would you like to remove [COLOR orange]ALL[/COLOR] addon data stored in your userdata folder?[/COLOR]',
                        yeslabel='[B][COLOR springgreen]Remove Data[/COLOR][/B]',
                        nolabel='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):
            clean_house(data_path)
        else:
            xbmcgui.Dialog().notification('[COLOR red]Remove Addon Data[/COLOR]', '[COLOR orange]Cancelled![/COLOR]', icon_down, sound=False)

    elif addon == 'uninstalled':
        if dialog.yesno(addon_build,
                        '[COLOR white]Would you like to remove [COLOR orange]ALL[/COLOR] addon data stored in your userdata folder for uninstalled addons?[/COLOR]',
                        yeslabel='[B][COLOR springgreen]Remove Data[/COLOR][/B]',
                        nolabel='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):
                        
            total = 0
            
            for folder in glob.glob(os.path.join(data_path, '*')):
                foldername = folder.replace(data_path, '').replace('\\', '').replace('/', '')
                if foldername in EXCLUDES:
                    pass
                elif os.path.exists(os.path.join(addons_path, foldername)):
                    pass
                elif os.path.isdir(folder):
                    clean_house(folder)
                    total += 1
                    xbmc.log(folder)
                    shutil.rmtree(folder)
            xbmcgui.Dialog().notification('[COLOR lime]Clean up Uninstalled[/COLOR]', '[COLOR red]{0} Folders(s) Removed[/COLOR]'.format(total), icon_down, sound=False)
        else:
            xbmcgui.Dialog().notification('[COLOR red]Remove Add-on Data[/COLOR]', '[COLOR orange]Cancelled![/COLOR]', icon_down, sound=False)
    elif addon == 'empty':
        if dialog.yesno(addon_build,
                        '[COLOR white]Would you like to remove [COLOR red]ALL[/COLOR] empty addon data folders in your userdata folder?[/COLOR]',
                        yeslabel='[B][COLOR springgreen]Remove Data[/COLOR][/B]',
                        nolabel='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):
            total = empty_folder(data_path)
            xbmcgui.Dialog().notification('[COLOR red]Remove Empty Folders[/COLOR]', '[COLOR red]{0} Folders(s) Removed[/COLOR]'.format(total), icon_down, sound=False)
        else:
            xbmcgui.Dialog().notification('[COLOR red]Remove Empty Folders[/COLOR]', '[COLOR orange]Cancelled![/COLOR]', icon_down, sound=False)
    else:
        addon_data = os.path.join(data_path, addon)
        if addon in EXCLUDES:
            xbmcgui.Dialog().notification("[COLOR red]Protected Plugin[/COLOR]", "[COLOR orange]Not allowed to remove add-on data[/COLOR]")
        elif os.path.exists(addon_data):
            if dialog.yesno(addon_build, '[COLOR orange]Would you also like to remove the add-on data for:[/COLOR]' + '\n' + '[COLOR orange]{0}[/COLOR]'.format(addon), yeslabel='[B][COLOR springgreen]Remove Data[/COLOR][/B]', nolabel='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):
                clean_house(addon_data)
                try:
                    shutil.rmtree(addon_data)
                except:
                    xbmc.log("Error deleting: {0}".format(addon_data))
            else:
                xbmc.log('Add-on data for {0} was not removed'.format(addon))
    xbmc.executebuiltin('Container.Refresh()')

def get_addon_by_id(id):
    try:
        return xbmcaddon.Addon(id=id)
    except:
        return False

def get_addon_info(id, info):
    addon = get_addon_by_id(id)
    if addon:
        return addon.getAddonInfo(info)
    else:
        return False

def get_info_label(label):
    try:
        return xbmc.getInfoLabel(label)
    except:
        return False

def enable_addons(all=False):
    fold = glob.glob(os.path.join(addons_path, '*/'))
    addonnames = []
    addonids = []
    for folder in sorted(fold, key=lambda x: x):
        foldername = os.path.split(folder[:-1])[1]
        if foldername in EXCLUDES:
            continue
        elif foldername in DEFAULTPLUGINS:
            continue
        elif foldername == 'packages':
            continue
        xml = os.path.join(folder, 'addon.xml')
        if os.path.exists(xml):
            root = ElementTree.parse(xml).getroot()
            addonid = root.get('id')
            addonname = root.get('name')
            addonids.append(addonid)
            addonnames.append(addonname)
    if not all:
        if len(addonids) == 0:
            addDir('[COLOR red]No Addons Found to Enable or Disable.[/COLOR]', '', '', icon_down, addon_fanart,'', isFolder=False)
        else:
            addDir('[I][B][COLOR red]!!Notice: Disabling Some Addons Can Cause Issues!![/COLOR][/B][/I]', '', '', icon_Build, addon_fanart,'', isFolder=False)
            addDir('[B][COLOR white]Enable [COLOR lime]All [COLOR white]Addons[/COLOR][/B]', '', 53, ADDON_ICON, addon_fanart,'', isFolder=False)
            addDir('[COLOR lime]Enable All Addons On Next StartUp[/COLOR]', '', 26, ADDON_ICON, addon_fanart,'', isFolder=False)
            addDir('[COLOR lime]Cancel Enable All Addons On Next StartUp[/COLOR]', '', 27, ADDON_ICON, addon_fanart, '', isFolder=False)

        for i in range(0, len(addonids)):
                folder = os.path.join(addons_path, addonids[i])
                icon = os.path.join(folder, 'icon.png') if os.path.exists(os.path.join(folder, 'icon.png')) else ADDON_ICON
                fanart = os.path.join(folder, 'fanart.jpg') if os.path.exists(os.path.join(folder, 'fanart.jpg')) else ADDON_FANART
                if get_addon_info(addonids[i], 'name'):
                    state = "[COLOR lime][Enabled][/COLOR]"
                    goto = "false"
                else:
                    state = "[COLOR red][Disabled][/COLOR]"
                    goto = "true"
                addDir("{0} [COLOR white]{1}[/COLOR]".format(state, addonnames[i]), goto, 54, icon, fanart,'', addonids[i], isFolder=False)
    else:
        from resources.lib.modules import db
        for addonid in addonids:
            db.toggle_addon(addonid, 'true')
        xbmc.executebuiltin('Container.Refresh()')

def grab_log(file=False, old=False, wizard=False):
    LOGPATH = xbmcvfs.translatePath('special://logpath/')
    ADDON_ID = xbmcaddon.Addon().getAddonInfo('id')
    PLUGIN_DATA = os.path.join(data_path, ADDON_ID)
    WIZLOG = os.path.join(PLUGIN_DATA, 'wizard.log')
    if wizard:
        if os.path.exists(WIZLOG):
            return WIZLOG if file else read_from_file(WIZLOG)
        else:
            return False
                
    logsfound = []

    for item in [file for file in os.listdir(LOGPATH) if os.path.basename(file).startswith('kodi')]:
        if item.endswith('.log'):
            if (old and 'old' in item) or (not old and 'old' not in item):
                logsfound.append(os.path.join(LOGPATH, item))

    if len(logsfound) > 0:
        logsfound.sort(key=lambda f: os.path.getmtime(f))
        if file:
            return logsfound[-1]
        else:
            return read_from_file(logsfound[-1])
    else:
        return False

def check_repos():
    progress_dialog = xbmcgui.DialogProgress()
    progress_dialog.create(addon_build, '[COLOR orange]Checking Repositories...[/COLOR]')
    badrepos = []
    xbmc.executebuiltin('UpdateAddonRepos')
    repolist = glob.glob(os.path.join(addons_path, 'repo*'))
    if len(repolist) == 0:
        progress_dialog.close()
        xbmcgui.Dialog().notification(addon_build, '[COLOR orange]No Repositories Found![/COLOR]', icon_down, sound=False)
        return
    sleeptime = len(repolist)
    start = 0
    while start < sleeptime:
        start += 1
        if progress_dialog.iscanceled():
            break
        perc = int(percentage(start, sleeptime))
        progress_dialog.update(perc,
                      '\n' + '[COLOR lime]Checking: [/COLOR][COLOR white]{0}[/COLOR]'.format(repolist[start-1].replace(addons_path, '')[1:]))
        xbmc.sleep(1000)
    if progress_dialog.iscanceled():
        progress_dialog.close()
        xbmcgui.Dialog().notification(addon_build, '[COLOR orange]Enabling Addons Cancelled[/COLOR]', icon_down, sound=False)

        sys.exit()
    progress_dialog.close()
    logfile = grab_log()
    fails = re.compile('CRepositoryUpdateJob(.+?)failed').findall(logfile)
    for item in fails:
        xbmc.log("Bad Repository: {0} ".format(item))
        brokenrepo = item.replace('[', '').replace(']', '').replace(' ', '').replace('/', '').replace('\\', '')
        if brokenrepo not in badrepos:
            badrepos.append(brokenrepo)
    if len(badrepos) > 0:
        msg = "[COLOR {0}]Below is a list of Repositories that did not resolve.  This does not mean that they are Depreciated, sometimes hosts go down for a short period of time.  Please do serveral scans of your repository list before removing a repository just to make sure it is broken.[/COLOR][CR][CR][COLOR {1}]".format(COLOR2, COLOR1)
        msg += '[CR]'.join(badrepos)
        msg += '[/COLOR]'
        window.show_text_box("Viewing Broken Repositories", msg)
    else:
        xbmcgui.Dialog().notification(addon_build, '[COLOR lime]All Repositories Working![/COLOR]', icon_down, sound=False)

def _is_url(url):
    try:
        result = urlparse(url)
        return all([result.scheme, result.netloc])
    except ValueError:
        return False

def _check_url(url, cred):
    if _is_url(url):
        try:
            response = requests.head(url, headers={'user-agent': USER_AGENT}, allow_redirects=True, auth=cred)
            
            if response.status_code < 300:
                xbmc.log("URL check passed for {0}: Status code [{1}]".format(url, response.status_code), level=xbmc.LOGDEBUG)
                return True
            elif response.status_code < 400:
                xbmc.log("URL check redirected from {0} to {1}: Status code [{2}]".format(url, response.headers['Location'], response.status_code), level=xbmc.LOGDEBUG)
                return _check_url(response.headers['Location'])
            elif response.status_code == 401:
                xbmc.log("URL requires authentication for {0}: Status code [{1}]".format(url, response.status_code), level=xbmc.LOGDEBUG)
                return 'auth'
            else:
                xbmc.log("URL check failed for {0}: Status code [{1}]".format(url, response.status_code), level=xbmc.LOGDEBUG)
                return False
        except Exception as e:
            xbmc.log("URL check error for {0}: [{1}]".format(url, e), level=xbmc.LOGDEBUG)
            return False
    else:
        xbmc.log("URL is not of a valid schema: {0}".format(url), level=xbmc.LOGDEBUG)
        return False

def open_url(url, stream=False, check=False, cred=None, count=0):
    if not url:
        return False

    dialog = xbmcgui.Dialog()
    user_agent = {'user-agent': USER_AGENT}
    count = 0
    
    valid = _check_url(url, cred)

    if not valid:
        return False
    else:
        if check:
            return True if valid else False
            
        if valid == 'auth' and not cred:
            cred = (get_keyboard(heading='Username'), get_keyboard(heading='Password'))
            
        response = requests.get(url, headers=user_agent, timeout=10.000, stream=stream, auth=cred)

        if response.status_code == 401:
            retry = dialog.yesno(addon_build, 'Either the username or password were invalid. Would you like to try again?', yeslabel='Try Again', nolabel='Cancel')
            
            if retry and count < 3:
                count += 1
                cred = (get_keyboard(heading='Username'), get_keyboard(heading='Password'))
                
                response = open_url(url, stream, check, cred, count)
            else:
                dialog.ok(addon_build, 'Authentication Failed.')
                return False
        
        return response

def check_sources():
    dialog = xbmcgui.Dialog()
    progress_dialog = xbmcgui.DialogProgress()
    
    if not os.path.exists(SOURCES):
        xbmcgui.Dialog().notification(addon_build, '[COLOR lime]No sources.xml File Found![/COLOR]', icon_down, sound=False)
        return False
    x = 0
    bad = []
    remove = []
    a = read_from_file(SOURCES)
    temp = a.replace('\r', '').replace('\n', '').replace('\t', '')
    match = re.compile('<files>.+?</files>').findall(temp)

    if len(match) > 0:
        match2 = re.compile('<source>.+?<name>(.+?)</name>.+?<path pathversion="1">(.+?)</path>.+?<allowsharing>(.+?)</allowsharing>.+?</source>').findall(match[0])
        progress_dialog.create(addon_build, "[COLOR orange]Scanning Sources for Broken Links[/COLOR]")
        for name, path, sharing in match2:
            x += 1
            perc = int(percentage(x, len(match2)))
            progress_dialog.update(perc,
                          '' + '\n' + "[COLOR lime]Checking [COLOR orange]{0}[/COLOR]:[/COLOR]".format(name) + '\n' + "[COLOR orange]{0}[/COLOR]".format(path))
                          
            working = open_url(path, check=True)
            if not working:
                bad.append([name, path, sharing, working])

        xbmc.log("Bad Sources: {0}".format(len(bad)))
        if len(bad) > 0:
            choice = dialog.yesno(addon_build, "[COLOR lime]{0}[/COLOR][COLOR orange] Source(s) have been found Broken".format(len(bad)) + '\n' + "[COLOR white]Would you like to Remove all or choose one by one?[/COLOR]",
                                      yeslabel="[B][COLOR springgreen]Remove All[/COLOR][/B]",
                                      nolabel="[B][COLOR red]Choose to Delete[/COLOR][/B]")
            if choice == 1:
                remove = bad
            else:
                for name, path, sharing, working in bad:
                    xbmc.log("{0} sources: {1}, {2}".format(name, path, working))
                    if dialog.yesno(addon_build,
                                        "[COLOR lime]{0}[/COLOR][COLOR orange] was reported as non working".format(name) + '\n' + "[COLOR orange]{0}[/COLOR]".format(path) + '\n' + "[COLOR orange]{0}[/COLOR]".format(working),
                                        yeslabel="[B][COLOR springgreen]Remove Source[/COLOR][/B]",
                                        nolabel="[B][COLOR red]Keep Source[/COLOR][/B]"):
                        remove.append([name, path, sharing, working])
                        xbmc.log("Removing Source {0}".format(name))
                    else:
                        xbmc.log("Source {0} was not removed".format(name))
            if len(remove) > 0:
                for name, path, sharing, working in remove:
                    a = a.replace('\n<source>\n<name>{0}</name>\n<path pathversion="1">{1}</path>\n<allowsharing>{2}</allowsharing>\n</source>'.format(name, path, sharing), '')
                    xbmc.log("Removing Source {0}".format(name))

                write_to_file(SOURCES, str(a))
                alive = len(match) - len(bad)
                kept = len(bad) - len(remove)
                removed = len(remove)
                dialog.ok(addon_build,
                              "[COLOR orange]Checking sources for broken paths has been completed" + '\n' + "[COLOR white]Working: [COLOR lime]{0}[/COLOR] | [COLOR white]Kept: [COLOR orange]{1}[/COLOR] | [COLOR white]Removed: [COLOR red]{2}[/COLOR][/COLOR]".format(alive, kept, removed))
            else:
                xbmc.log("No Bad Sources to be removed.")
        else:
            xbmcgui.Dialog().notification(addon_build, '[COLOR lime]All Sources Are Working![/COLOR]', icon_down, sound=False)

    else:
        xbmc.log("No Sources Found")
