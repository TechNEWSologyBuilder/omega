﻿""""""""""""""""""""""""""""""""""""""""""
"""  Believe in God - Ηelp as you can  """
""""""""""""""""""""""""""""""""""""""""""

import os, xbmc, xbmcgui, xbmcvfs, xbmcaddon
xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"general.addonupdates","value":2}}')
xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid": "pvr.stalker","enabled":false}}')

from resources.lib.modules import check
from resources.lib.modules import maintenance
from resources.lib.GUIcontrol.txt_updater import get_check
check_version = get_check()
setting = xbmcaddon.Addon('plugin.program.downloader19').getSetting
setting_set = xbmcaddon.Addon('plugin.program.downloader19').setSetting


if __name__ == '__main__':
    if os.path.exists(xbmcvfs.translatePath('special://home/addons/skin.TechNEWSology')):
        xbmcgui.Dialog().notification('[B][COLOR orange]TechNEWSology Build[/COLOR][/B]', '[B][COLOR white]Καλώς ήρθατε![/COLOR][/B]', 'special://home/addons/plugin.program.downloader19/icon.gif', sound=False)
        if not setting('updaterversion') == 'false':
            if check_version > int(setting('checkversion')):
                xbmcgui.Dialog().notification('[B][COLOR orange]TechNEWSology Build[/COLOR][/B]', '[B][COLOR white]Εισαγωγή νέων ενημερώσεων ...[/COLOR][/B]', 'special://home/addons/plugin.program.downloader19/icon.gif', sound=False)
                maintenance.clear_packages_starting()
                check.addonupdates_Disable()
                check.autoenable()
                check.var()
                check.players()
                check.skin_py()
                check.delete()
                check.zip1()
                check.zip2()
                check.zip3()
                check.zip4()
                check.zip5()
                check.zip6()
                check.zip7()
                check.zip8()
                check.zip9()
                check.zip10()
                check.zip11()
                check.zip12()
                check.installation()
                check.updater()
                check.setsetting()
                check.database()
                check.xmlskin()
                check.UpdateAddonRepos()
                setting_set('checkversion', str(check_version))
                check.notifyT()
            else:
                maintenance.clear_packages_starting()
            #    xbmcgui.Dialog().notification('[B][COLOR orange]TechNEWSology Build[/COLOR][/B]', '[B][COLOR white]Έλεγχος για ενημερώσεις πρόσθετων ...[/COLOR][/B]', 'special://home/addons/plugin.program.downloader19/icon.gif', sound=False)
                check.autoenable()
                check.Update()
                check.notifyT()
        else:
            xbmcgui.Dialog().notification('[B][COLOR orange]TechNEWSology Build[/COLOR][/B]', '[B]Οι αυτόματες ενημερώσεις είναι απενερ/μένες[/B]', 'special://home/addons/plugin.program.downloader19/icon.gif', sound=False)
            maintenance.clear_packages_starting()
            xbmcgui.Dialog().notification('[B][COLOR orange]TechNEWSology Build[/COLOR][/B]', '[B][COLOR white]Έλεγχος για ενημερώσεις πρόσθετων ...[/COLOR][/B]', 'special://home/addons/plugin.program.downloader19/icon.gif', sound=False)
            check.autoenable()
            check.Update()
            check.notifyT()
    else:
        xbmcgui.Dialog().notification('[B][COLOR orange]Καλώς ήρθατε![/COLOR][/B]', '[B][COLOR white]Αναμονή έναρξης πρόσθετου ...[/COLOR][/B]', 'special://home/addons/plugin.program.downloader19/icon.gif', sound=False)
        xbmc.executebuiltin('ActivateWindow(10001,plugin://plugin.program.downloader19)')

