# Aeon Nox 5: SiLVO
A modded version of [Aeon Nox 5](http://forum.kodi.tv/showthread.php?tid=183504)

**Branches guide:**
 - **master:** Kodi v18 Codename Leia
 - **krypton:** Kodi v17 Codename Krypton
 - **jarvis:** Kodi v16 Codename Jarvis
 - **isengard:** Kodi v15 Codename Isengard
 - **helix:** Kodi v14 Codename Helix

*Check the [Aeon Nox 5: SiLVO thread](http://forum.kodi.tv/showthread.php?tid=210069) for more information and support*

**ALL OTHER BRANCHES SHOULD NOT BE USED OR INSTALLED**
