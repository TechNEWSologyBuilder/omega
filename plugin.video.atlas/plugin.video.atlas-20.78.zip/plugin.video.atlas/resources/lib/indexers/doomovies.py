# -*- coding: utf-8 -*-

import xbmcgui
import xbmcaddon
import xbmc
import re
import requests
import six
from six.moves.urllib_parse import quote_plus
from resources.lib.modules import client
from resources.lib.modules import control
from resources.lib.modules import views
from resources.lib.modules import dom_parser as dom
from resources.lib.modules.control import addDir
ADDON       = xbmcaddon.Addon()
ADDON_DATA  = ADDON.getAddonInfo('profile')
ADDON_PATH  = ADDON.getAddonInfo('path')
DESCRIPTION = ADDON.getAddonInfo('description')
FANART      = ADDON.getAddonInfo('fanart')
ICON        = ADDON.getAddonInfo('icon')
ID          = ADDON.getAddonInfo('id')
NAME        = ADDON.getAddonInfo('name')
VERSION     = ADDON.getAddonInfo('version')
Lang        = control.lang
Dialog      = xbmcgui.Dialog()
vers = VERSION
ART = ADDON_PATH + "/resources/icons/"
icon_doomovies = ART + 'doomovies.png'
DOOMOVIES = 'https://doomovies.net'


def Doomovies_menu(): #155
    addDir('[B][COLOR yellow]2024[/COLOR][/B]', DOOMOVIES + '/release/2024/', 154, icon_doomovies, FANART, '')
    addDir('[B][COLOR yellow]2023[/COLOR][/B]', DOOMOVIES + '/release/2023/', 154, icon_doomovies, FANART, '')
#    addDir('[B][COLOR yellow]2022[/COLOR][/B]', DOOMOVIES + '/release/2022/', 154, icon_doomovies, FANART, '')
    addDir('[B][COLOR yellow]Trending[/COLOR][/B]', DOOMOVIES + '/trending/?get=movies', 154, ART + 'doomovies.png', FANART, '')
    addDir('[B][COLOR yellow]Featured[/COLOR][/B]', DOOMOVIES + '/genre/featured/', 154, icon_doomovies, FANART, '')
    addDir('[B][COLOR yellow]Έτος[/COLOR][/B]', '', 151, icon_doomovies, FANART, '')
    addDir('[B][COLOR yellow]Κατηγορίες[/COLOR][/B]', '', 152, icon_doomovies, FANART, '')

def menu_year(): #151
    years = []
    for i in range(1961, 2024):
        i += 1
        title = '[B][COLOR yellow]{}[/COLOR][/B]'.format(str(i))
        link = DOOMOVIES + '/release/{}'.format(str(i))
        years.append((title, link))
    for title, link in sorted(years, reverse=True):
        addDir(title, link, 154, icon_doomovies, FANART, '')


def menu_genre(): #152
    addDir('[B][COLOR yellow]3D[/COLOR][/B]', DOOMOVIES + '/genre/3d/', 154, icon_doomovies, FANART, '')
    addDir('[B][COLOR yellow]Action[/COLOR][/B]', DOOMOVIES + '/genre/action/', 154, icon_doomovies, FANART, '')
    addDir('[B][COLOR yellow]Action & Adventure[/COLOR][/B]', DOOMOVIES + '/genre/action-adventure/', 154, icon_doomovies, FANART, '')
    addDir('[B][COLOR yellow]Adventure[/COLOR][/B]', DOOMOVIES + '/genre/adventure/', 154, icon_doomovies, FANART, '')
    addDir('[B][COLOR yellow]Animation[/COLOR][/B]', DOOMOVIES + '/genre/animation/', 154, icon_doomovies, FANART, '')
    addDir('[B][COLOR yellow]Biography[/COLOR][/B]', DOOMOVIES + '/genre/biography/', 154, icon_doomovies, FANART, '')
    addDir('[B][COLOR yellow]Comedy[/COLOR][/B]', DOOMOVIES + '/genre/comedy/', 154, icon_doomovies, FANART, '')
    addDir('[B][COLOR yellow]Crime[/COLOR][/B]', DOOMOVIES + '/genre/crime/', 154, icon_doomovies, FANART, '')
    addDir('[B][COLOR yellow]Documentary[/COLOR][/B]', DOOMOVIES + '/genre/documentary/', 154, icon_doomovies, FANART, '')
    addDir('[B][COLOR yellow]Drama[/COLOR][/B]', DOOMOVIES + '/genre/drama/', 154, icon_doomovies, FANART, '')
    addDir('[B][COLOR yellow]Family[/COLOR][/B]', DOOMOVIES + '/genre/family/', 154, icon_doomovies, FANART, '')
    addDir('[B][COLOR yellow]Fantasy[/COLOR][/B]', DOOMOVIES + '/genre/fantasy/', 154, icon_doomovies, FANART, '')
    addDir('[B][COLOR yellow]Featured[/COLOR][/B]', DOOMOVIES + '/genre/featured/', 154, icon_doomovies, FANART, '')
    addDir('[B][COLOR yellow]History[/COLOR][/B]', DOOMOVIES + '/genre/history/', 154, icon_doomovies, FANART, '')
    addDir('[B][COLOR yellow]Horror[/COLOR][/B]', DOOMOVIES + '/genre/horror/', 154, icon_doomovies, FANART, '')
    addDir('[B][COLOR yellow]Kids[/COLOR][/B]', DOOMOVIES + '/genre/kids/', 154, icon_doomovies, FANART, '')
    addDir('[B][COLOR yellow]Music[/COLOR][/B]', DOOMOVIES + '/genre/music/', 154, icon_doomovies, FANART, '')
    addDir('[B][COLOR yellow]Musical[/COLOR][/B]', DOOMOVIES + '/genre/musical/', 154, icon_doomovies, FANART, '')
    addDir('[B][COLOR yellow]Mystery[/COLOR][/B]', DOOMOVIES + '/genre/mystery/', 154, icon_doomovies, FANART, '')
    addDir('[B][COLOR yellow]News[/COLOR][/B]', DOOMOVIES + '/genre/news/', 154, icon_doomovies, FANART, '')
    addDir('[B][COLOR yellow]Reality[/COLOR][/B]', DOOMOVIES + '/genre/reality/', 154, icon_doomovies, FANART, '')
    addDir('[B][COLOR yellow]Romance[/COLOR][/B]', DOOMOVIES + '/genre/romance/', 154, icon_doomovies, FANART, '')
    addDir('[B][COLOR yellow]Sci-Fi & Fantasy[/COLOR][/B]', DOOMOVIES + '/genre/sci-fi-fantasy/', 154, icon_doomovies, FANART, '')
    addDir('[B][COLOR yellow]Science Fiction[/COLOR][/B]', DOOMOVIES + '/genre/science-fiction/', 154, icon_doomovies, FANART, '')
    addDir('[B][COLOR yellow]Short[/COLOR][/B]', DOOMOVIES + '/genre/short/', 154, icon_doomovies, FANART, '')
    addDir('[B][COLOR yellow]Sport[/COLOR][/B]', DOOMOVIES + '/genre/sport/', 154, icon_doomovies, FANART, '')
    addDir('[B][COLOR yellow]Thriller[/COLOR][/B]', DOOMOVIES + '/genre/thriller/', 154, icon_doomovies, FANART, '')
    addDir('[B][COLOR yellow]TV Movie[/COLOR][/B]', DOOMOVIES + '/genre/tv-movie/', 154, icon_doomovies, FANART, '')
    addDir('[B][COLOR yellow]TV Special[/COLOR][/B]', DOOMOVIES + '/genre/tv-special/', 154, icon_doomovies, FANART, '')
    addDir('[B][COLOR yellow]WWE[/COLOR][/B]', DOOMOVIES + '/genre/wwe/', 154, icon_doomovies, FANART, '')
    addDir('[B][COLOR yellow]War[/COLOR][/B]', DOOMOVIES + '/genre/war/', 154, icon_doomovies, FANART, '')
    addDir('[B][COLOR yellow]War & Politics[/COLOR][/B]', DOOMOVIES + '/genre/war-politics/', 154, icon_doomovies, FANART, '')
    addDir('[B][COLOR yellow]Western[/COLOR][/B]', DOOMOVIES + '/genre/western/', 154, icon_doomovies, FANART, '')


def doomovies(url): #154
    hdrs = {'Referer': DOOMOVIES,
            'User-Agent': client.agent()}
    p = requests.get(url, headers=hdrs).text
    m = re.compile('<img src="(.+?)" alt=.+?><div class="rating">(.+?)</div>.+?<h3><a href="(.+?)">(.+?)</a></h3> <span>.+?, (.+?)</span>', re.DOTALL).findall(p)
    for icon, rating, url, name, year in m:
        name = clear_Title(name)
        fanart = icon
        year = '[B][COLOR white] (%s)[/COLOR][/B]' % year
        rating = ' | ' + '[B][COLOR blue]%s IMDb[/COLOR][/B]' % rating
     #   quality = ' | ' + '[B][COLOR lime]%s[/COLOR][/B]' % quality
        addDir(('[B][COLOR=white]%s[/COLOR][/B]' % name + year + rating), url, 153, icon, fanart, '')
    try:
        m = re.compile('<link rel="next" href="(.+?)" />').findall(p)[0]
        addDir('[B][COLOR=lime]Επόμενη σελίδα >>[/COLOR][/B]', m, 154, 'http://i.imgur.com/rKSs0yq.png', FANART, '')
    except BaseException:
        pass
    views.selectView('movies', 'movie-view')


def get_links(name, url, iconimage, description): #153
    hdrs = {'Referer': DOOMOVIES,
            'User-Agent': client.agent()}
    p = requests.get(url, headers=hdrs).text
    m = re.compile(''' <a href='(.+?)' target='_blank'>(.+?)</a></td><td><strong class='quality'>(.+?)</strong></td><td>(.+?)</td>''').findall(p)
    t = re.compile('<h1>(.+?)</h1>.+?, (.+?)</span>').findall(p)
    for url, link, quality, language in m:
        for name, year in t:
            link = ' | ' + link
            quality = ' | ' + quality
            language = ' | ' + language
            name = clear_Title(name)
            year = ' (%s)' % year
            addDir((name+year+language+quality+link), url, 100, iconimage, '', '')


def search(url): #150
    keyb = xbmc.Keyboard('', 'Αναζήτηση Ταινίας - Τήλ.Σειράς')
    keyb.doModal()
    if (keyb.isConfirmed()):
        search = keyb.getText().replace(' ', '+')
        url = 'https://doomovies.net/?s=' + search
        doomovies_s(url)


def doomovies_s(url): #156
    hdrs = {'Referer': DOOMOVIES,
            'User-Agent': client.agent()}
    p = requests.get(url, headers=hdrs).text
    m = re.compile('<img src="(.+?)".+?<div class="title"><a href="(.+?)">(.+?)</a>', re.DOTALL).findall(p)
    for icon, url, name in m:
        name = clear_Title(name)
        addDir(('[B][COLOR=white]%s[/COLOR][/B]' % name), url, 153, icon, '', '')
    try:
        m = re.compile('<link rel="next" href="(.+?)" />').findall(p)[0]
        addDir('[B][COLOR=lime]Επόμενη σελίδα >>[/COLOR][/B]', m, 156, 'http://i.imgur.com/rKSs0yq.png', FANART, '')
    except BaseException:
        pass


def clear_Title(txt):
    import six
    if six.PY2:
        txt = txt.encode('utf-8', 'ignore')
    else:
        txt = six.ensure_text(txt, encoding='utf-8', errors='ignore')
    txt = re.sub(r'<.+?>', '', txt)
    txt = re.sub(r'var\s+cp.+?document.write\(\'\'\);\s*', '', txt)
    txt = txt.replace("&quot;", "\"").replace('()', '').replace("&#038;", "&").replace('&#8211;', ':').replace('\n',
                                                                                                               ' ')
    txt = txt.replace("&amp;", "&").replace('&#8217;', "'").replace('&#039;', ':').replace('&#;', '\'').replace('&#8230;', '...')
    txt = txt.replace("&#38;", "&").replace('&#8221;', '"').replace('&#8216;', '"').replace('&#160;', '')
    txt = txt.replace("&nbsp;", "").replace('&#8220;', '"').replace('&#8216;', '"').replace('\t', ' ')
    return txt
