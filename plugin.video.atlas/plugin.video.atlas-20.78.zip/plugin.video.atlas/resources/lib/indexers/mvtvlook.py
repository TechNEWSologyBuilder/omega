# -*- coding: utf-8 -*-

import xbmcgui
import xbmcaddon
import xbmc
import re
import requests
import six
from six.moves.urllib_parse import quote_plus
from resources.lib.modules import client
from resources.lib.modules import control
from resources.lib.modules import views
from resources.lib.modules import dom_parser as dom
from resources.lib.modules.control import addDir
ADDON       = xbmcaddon.Addon()
ADDON_DATA  = ADDON.getAddonInfo('profile')
ADDON_PATH  = ADDON.getAddonInfo('path')
DESCRIPTION = ADDON.getAddonInfo('description')
FANART      = ADDON.getAddonInfo('fanart')
ICON        = ADDON.getAddonInfo('icon')
ID          = ADDON.getAddonInfo('id')
NAME        = ADDON.getAddonInfo('name')
VERSION     = ADDON.getAddonInfo('version')
Lang        = control.lang
Dialog      = xbmcgui.Dialog()
vers = VERSION
ART = ADDON_PATH + "/resources/icons/"
MVTVLOOK = 'https://mvtvlook.club/'


def mvtvlook_menu(): #230
    addDir('[B][COLOR orange]Ταινίες [COLOR white]2023[/COLOR][/B]', 'https://mvtvlook.club/category/movies/', 238, ART + 'mvtvlook.png', FANART, '')
    addDir('[B][COLOR orange]Τελευταίες Προσθήκες[/COLOR][/B]', 'https://mvtvlook.club/category/movies/', 235, ART + 'mvtvlook.png', FANART, '')
    addDir('[B][COLOR orange]Κατηγορίες [COLOR white]Ταινίες-Σειρές[/COLOR][/B]', '', 233, ART + 'mvtvlook.png', FANART, '')
    addDir('[B][COLOR orange]Χώρα [COLOR white]Ταινίες-Σειρές[/COLOR][/B]', '', 237, ART + 'mvtvlook.png', FANART, '')
    addDir('[B][COLOR orange]Έτος [COLOR white]Ταινίες-Σειρές[/COLOR][/B]', '', 232, ART + 'mvtvlook.png', FANART, '')


def mvtvlook_menu_tv(): #229
    addDir('[B][COLOR orange]Σειρές [COLOR white]2023[/COLOR][/B]', 'https://mvtvlook.club/category/tv-series/', 238, ART + 'mvtvlook.png', FANART, '')
    addDir('[B][COLOR orange]Τελευταίες Προσθήκες[/COLOR][/B]', 'https://mvtvlook.club/category/tv-series/', 235, ART + 'mvtvlook.png', FANART, '')
    addDir('[B][COLOR orange]Κατηγορίες [COLOR white]Ταινίες-Σειρές[/COLOR][/B]', '', 233, ART + 'mvtvlook.png', FANART, '')
    addDir('[B][COLOR orange]Χώρα [COLOR white]Ταινίες-Σειρές[/COLOR][/B]', '', 237, ART + 'mvtvlook.png', FANART, '')
    addDir('[B][COLOR orange]Έτος [COLOR white]Ταινίες-Σειρές[/COLOR][/B]', '', 232, ART + 'mvtvlook.png', FANART, '')


def menu_genre(): #233
    addDir('[COLOR orange]Δράση[/COLOR]', MVTVLOOK + 'category/action/', 235, ART + 'mvtvlook.png', FANART, '')
    addDir('[COLOR orange]Περιπέτεια - Δράση[/COLOR]', MVTVLOOK + 'category/action-adventure/', 235, ART + 'mvtvlook.png', FANART, '')
    addDir('[COLOR orange]Περιπέτεια[/COLOR]', MVTVLOOK + 'category/adventure/', 235, ART + 'mvtvlook.png', FANART, '')
    addDir('[COLOR orange]Animation[/COLOR]', MVTVLOOK + 'category/animation/', 235, ART + 'mvtvlook.png', FANART, '')
    addDir('[COLOR orange]Κωμωδίες[/COLOR]', MVTVLOOK + 'category/comedy/', 235, ART + 'mvtvlook.png', FANART, '')
    addDir('[COLOR orange]Έγκλημα[/COLOR]', MVTVLOOK + 'category/crime/', 235, ART + 'mvtvlook.png', FANART, '')
    addDir('[COLOR orange]Ντοκιμαντέρ[/COLOR]', MVTVLOOK + 'category/documentary/', 235, ART + 'mvtvlook.png', FANART, '')
    addDir('[COLOR orange]Δράμα[/COLOR]', MVTVLOOK + 'category/drama/', 235, ART + 'mvtvlook.png', FANART, '')
    addDir('[COLOR orange]Οικογενειακές[/COLOR]', 'category/family/', 235, ART + 'mvtvlook.png', FANART, '')
    addDir('[COLOR orange]Φαντασίας[/COLOR]', MVTVLOOK + 'category/fantasy/', 235, ART + 'mvtvlook.png', FANART, '')
    addDir('[COLOR orange]Ιστορικές[/COLOR]', MVTVLOOK + 'category/history/', 235, ART + 'mvtvlook.png', FANART, '')
    addDir('[COLOR orange]Τρόμου[/COLOR]', MVTVLOOK + 'category/horror/', 235, ART + 'mvtvlook.png', FANART, '')
    addDir('[COLOR orange]Κινούμενα Σχέδια[/COLOR]', MVTVLOOK + 'category/kids/', 235, ART + 'mvtvlook.png', FANART, '')
    addDir('[COLOR orange]Μουσική[/COLOR]', MVTVLOOK + 'category/music/', 235, ART + 'mvtvlook.png', FANART, '')
    addDir('[COLOR orange]Μυστήριο[/COLOR]', MVTVLOOK + 'category/mystery/', 235, ART + 'mvtvlook.png', FANART, '')
    addDir('[COLOR orange]Reality[/COLOR]', MVTVLOOK + 'category/reality/', 235, ART + 'mvtvlook.png', FANART, '')
    addDir('[COLOR orange]Ρομαντικές[/COLOR]', MVTVLOOK + 'category/romance/', 235, ART + 'mvtvlook.png', FANART, '')
    addDir('[COLOR orange]Επιστημονική Φαντασία[/COLOR]', MVTVLOOK + 'category/science-fiction/', 235, ART + 'mvtvlook.png', FANART, '')
    addDir('[COLOR orange]Soap[/COLOR]', MVTVLOOK + 'category/soap/', 235, ART + 'mvtvlook.png', FANART, '')
    addDir('[COLOR orange]Θρίλερ[/COLOR]', MVTVLOOK + 'category/thriller/', 235, ART + 'mvtvlook.png', FANART, '')
    addDir('[COLOR orange]Tv-Movie[/COLOR]', MVTVLOOK + 'category/tv-movie/', 235, ART + 'mvtvlook.png', FANART, '')
    addDir('[COLOR orange]Πολέμου[/COLOR]', MVTVLOOK + 'category/war/', 235, ART + 'mvtvlook.png', FANART, '')
    addDir('[COLOR orange]Πολέμου - Πολιτική[/COLOR]', MVTVLOOK + 'category/war-politics/', 235, ART + 'mvtvlook.png', FANART, '')
    addDir('[COLOR orange]Γουέστερν[/COLOR]', MVTVLOOK + 'category/western/', 235, ART + 'mvtvlook.png', FANART, '')

def menu_coundry(): #237
    addDir('[COLOR orange]afghanistan[/COLOR]', MVTVLOOK + 'country/afghanistan/', 235, ART + 'mvtvlook.png', FANART, '')
    addDir('[COLOR orange]argentina[/COLOR]', MVTVLOOK + 'country/argentina/', 235, ART + 'mvtvlook.png', FANART, '')
    addDir('[COLOR orange]aruba[/COLOR]', MVTVLOOK + 'country/aruba/', 235, ART + 'mvtvlook.png', FANART, '')
    addDir('[COLOR orange]australia[/COLOR]', MVTVLOOK + 'country/australia/', 235, ART + 'mvtvlook.png', FANART, '')
    addDir('[COLOR orange]austria[/COLOR]', MVTVLOOK + 'country/austria/', 235, ART + 'mvtvlook.png', FANART, '')
    addDir('[COLOR orange]bahamas[/COLOR]', MVTVLOOK + 'country/bahamas/', 235, ART + 'mvtvlook.png', FANART, '')
    addDir('[COLOR orange]belarus[/COLOR]', MVTVLOOK + 'country/belarus/', 235, ART + 'mvtvlook.png', FANART, '')
    addDir('[COLOR orange]belgium[/COLOR]', MVTVLOOK + 'country/belgium/', 235, ART + 'mvtvlook.png', FANART, '')
    addDir('[COLOR orange]bolivia[/COLOR]', MVTVLOOK + 'country/bolivia/', 235, ART + 'mvtvlook.png', FANART, '')
    addDir('[COLOR orange]bosnia-and-herzegovina[/COLOR]', MVTVLOOK + 'country/bosnia-and-herzegovina/', 235, ART + 'mvtvlook.png', FANART, '')
    addDir('[COLOR orange]brazil[/COLOR]', MVTVLOOK + 'country/brazil/', 235, ART + 'mvtvlook.png', FANART, '')
    addDir('[COLOR orange]bulgaria[/COLOR]', MVTVLOOK + 'country/bulgaria/', 235, ART + 'mvtvlook.png', FANART, '')
    addDir('[COLOR orange]canada[/COLOR]', MVTVLOOK + 'country/canada/', 235, ART + 'mvtvlook.png', FANART, '')
    addDir('[COLOR orange]chile[/COLOR]', MVTVLOOK + 'country/chile/', 235, ART + 'mvtvlook.png', FANART, '')
    addDir('[COLOR orange]china[/COLOR]', MVTVLOOK + 'country/china/', 235, ART + 'mvtvlook.png', FANART, '')
    addDir('[COLOR orange]colombia[/COLOR]', MVTVLOOK + 'country/colombia/', 235, ART + 'mvtvlook.png', FANART, '')
    addDir('[COLOR orange]costa-rica[/COLOR]', MVTVLOOK + 'country/costa-rica/', 235, ART + 'mvtvlook.png', FANART, '')
    addDir('[COLOR orange]croatia[/COLOR]', MVTVLOOK + 'country/croatia/', 235, ART + 'mvtvlook.png', FANART, '')
    addDir('[COLOR orange]cyprus[/COLOR]', MVTVLOOK + 'country/cyprus/', 235, ART + 'mvtvlook.png', FANART, '')
    addDir('[COLOR orange]czech-republic[/COLOR]', MVTVLOOK + 'country/czech-republic/', 235, ART + 'mvtvlook.png', FANART, '')
    addDir('[COLOR orange]denmark[/COLOR]', MVTVLOOK + 'country/denmark/', 235, ART + 'mvtvlook.png', FANART, '')
    addDir('[COLOR orange]dominican-republic[/COLOR]', MVTVLOOK + 'country/dominican-republic/', 235, ART + 'mvtvlook.png', FANART, '')
    addDir('[COLOR orange]egypt[/COLOR]', MVTVLOOK + 'country/egypt/', 235, ART + 'mvtvlook.png', FANART, '')
    addDir('[COLOR orange]eritrea[/COLOR]', MVTVLOOK + 'country/eritrea/', 235, ART + 'mvtvlook.png', FANART, '')
    addDir('[COLOR orange]estonia[/COLOR]', MVTVLOOK + 'country/estonia/', 235, ART + 'mvtvlook.png', FANART, '')
    addDir('[COLOR orange]ethiopia[/COLOR]', MVTVLOOK + 'country/ethiopia/', 235, ART + 'mvtvlook.png', FANART, '')
    addDir('[COLOR orange]finland[/COLOR]', MVTVLOOK + 'country/finland/', 235, ART + 'mvtvlook.png', FANART, '')
    addDir('[COLOR orange]france[/COLOR]', MVTVLOOK + 'country/france/', 235, ART + 'mvtvlook.png', FANART, '')
    addDir('[COLOR orange]georgia[/COLOR]', MVTVLOOK + 'country/georgia/', 235, ART + 'mvtvlook.png', FANART, '')
    addDir('[COLOR orange]germany[/COLOR]', MVTVLOOK + 'country/germany/', 235, ART + 'mvtvlook.png', FANART, '')
    addDir('[COLOR orange]ghana[/COLOR]', MVTVLOOK + 'country/ghana/', 235, ART + 'mvtvlook.png', FANART, '')
    addDir('[COLOR orange]greece[/COLOR]', MVTVLOOK + 'country/greece/', 235, ART + 'mvtvlook.png', FANART, '')
    addDir('[COLOR orange]hong-kong[/COLOR]', MVTVLOOK + 'country/hong-kong/', 235, ART + 'mvtvlook.png', FANART, '')
    addDir('[COLOR orange]hungary[/COLOR]', MVTVLOOK + 'country/hungary/', 235, ART + 'mvtvlook.png', FANART, '')
    addDir('[COLOR orange]iceland[/COLOR]', MVTVLOOK + 'country/iceland/', 235, ART + 'mvtvlook.png', FANART, '')
    addDir('[COLOR orange]india[/COLOR]', MVTVLOOK + 'country/india/', 235, ART + 'mvtvlook.png', FANART, '')
    addDir('[COLOR orange]indonesia[/COLOR]', MVTVLOOK + 'country/indonesia/', 235, ART + 'mvtvlook.png', FANART, '')
    addDir('[COLOR orange]iran[/COLOR]', MVTVLOOK + 'country/iran/', 235, ART + 'mvtvlook.png', FANART, '')
    addDir('[COLOR orange]ireland[/COLOR]', MVTVLOOK + 'country/ireland/', 235, ART + 'mvtvlook.png', FANART, '')
    addDir('[COLOR orange]israel[/COLOR]', MVTVLOOK + 'country/israel/', 235, ART + 'mvtvlook.png', FANART, '')
    addDir('[COLOR orange]italy[/COLOR]', MVTVLOOK + 'country/italy/', 235, ART + 'mvtvlook.png', FANART, '')
    addDir('[COLOR orange]japan[/COLOR]', MVTVLOOK + 'country/japan/', 235, ART + 'mvtvlook.png', FANART, '')
    addDir('[COLOR orange]kenya[/COLOR]', MVTVLOOK + 'country/kenya/', 235, ART + 'mvtvlook.png', FANART, '')
    addDir('[COLOR orange]kuwait[/COLOR]', MVTVLOOK + 'country/kuwait/', 235, ART + 'mvtvlook.png', FANART, '')
    addDir('[COLOR orange]latvia[/COLOR]', MVTVLOOK + 'country/latvia/', 235, ART + 'mvtvlook.png', FANART, '')
    addDir('[COLOR orange]lithuania[/COLOR]', MVTVLOOK + 'country/lithuania/', 235, ART + 'mvtvlook.png', FANART, '')
    addDir('[COLOR orange]luxembourg[/COLOR]', MVTVLOOK + 'country/luxembourg/', 235, ART + 'mvtvlook.png', FANART, '')
    addDir('[COLOR orange]malaysia[/COLOR]', MVTVLOOK + 'country/malaysia/', 235, ART + 'mvtvlook.png', FANART, '')
    addDir('[COLOR orange]malta[/COLOR]', MVTVLOOK + 'country/malta/', 235, ART + 'mvtvlook.png', FANART, '')
    addDir('[COLOR orange]mauritius[/COLOR]', MVTVLOOK + 'country/mauritius/', 235, ART + 'mvtvlook.png', FANART, '')
    addDir('[COLOR orange]mexico[/COLOR]', MVTVLOOK + 'country/mexico/', 235, ART + 'mvtvlook.png', FANART, '')
    addDir('[COLOR orange]morocco[/COLOR]', MVTVLOOK + 'country/morocco/', 235, ART + 'mvtvlook.png', FANART, '')
    addDir('[COLOR orange]n-a[/COLOR]', MVTVLOOK + 'country/n-a/', 235, ART + 'mvtvlook.png', FANART, '')
    addDir('[COLOR orange]namibia[/COLOR]', MVTVLOOK + 'country/namibia/', 235, ART + 'mvtvlook.png', FANART, '')
    addDir('[COLOR orange]netherlands[/COLOR]', MVTVLOOK + 'country/netherlands/', 235, ART + 'mvtvlook.png', FANART, '')
    addDir('[COLOR orange]new-zealand[/COLOR]', MVTVLOOK + 'country/new-zealand/', 235, ART + 'mvtvlook.png', FANART, '')
    addDir('[COLOR orange]nigeria[/COLOR]', MVTVLOOK + 'country/nigeria/', 235, ART + 'mvtvlook.png', FANART, '')
    addDir('[COLOR orange]norway[/COLOR]', MVTVLOOK + 'country/norway/', 235, ART + 'mvtvlook.png', FANART, '')
    addDir('[COLOR orange]peru[/COLOR]', MVTVLOOK + 'country/peru/', 235, ART + 'mvtvlook.png', FANART, '')
    addDir('[COLOR orange]philippines[/COLOR]', MVTVLOOK + 'country/philippines/', 235, ART + 'mvtvlook.png', FANART, '')
    addDir('[COLOR orange]poland[/COLOR]', MVTVLOOK + 'country/poland/', 235, ART + 'mvtvlook.png', FANART, '')
    addDir('[COLOR orange]portugal[/COLOR]', MVTVLOOK + 'country/portugal/', 235, ART + 'mvtvlook.png', FANART, '')
    addDir('[COLOR orange]puerto-rico[/COLOR]', MVTVLOOK + 'country/puerto-rico/', 235, ART + 'mvtvlook.png', FANART, '')
    addDir('[COLOR orange]romania[/COLOR]', MVTVLOOK + 'country/romania/', 235, ART + 'mvtvlook.png', FANART, '')
    addDir('[COLOR orange]russia[/COLOR]', MVTVLOOK + 'country/russia/', 235, ART + 'mvtvlook.png', FANART, '')
    addDir('[COLOR orange]saudi-arabia[/COLOR]', MVTVLOOK + 'country/saudi-arabia/', 235, ART + 'mvtvlook.png', FANART, '')
    addDir('[COLOR orange]serbia[/COLOR]', MVTVLOOK + 'country/serbia/', 235, ART + 'mvtvlook.png', FANART, '')
    addDir('[COLOR orange]singapore[/COLOR]', MVTVLOOK + 'country/singapore/', 235, ART + 'mvtvlook.png', FANART, '')
    addDir('[COLOR orange]slovakia[/COLOR]', MVTVLOOK + 'country/slovakia/', 235, ART + 'mvtvlook.png', FANART, '')
    addDir('[COLOR orange]south-africa[/COLOR]', MVTVLOOK + 'country/south-africa/', 235, ART + 'mvtvlook.png', FANART, '')
    addDir('[COLOR orange]south-korea[/COLOR]', MVTVLOOK + 'country/south-korea/', 235, ART + 'mvtvlook.png', FANART, '')
    addDir('[COLOR orange]spain[/COLOR]', MVTVLOOK + 'country/spain/', 235, ART + 'mvtvlook.png', FANART, '')
    addDir('[COLOR orange]sweden[/COLOR]', MVTVLOOK + 'country/sweden/', 235, ART + 'mvtvlook.png', FANART, '')
    addDir('[COLOR orange]switzerland[/COLOR]', MVTVLOOK + 'country/switzerland/', 235, ART + 'mvtvlook.png', FANART, '')
    addDir('[COLOR orange]taiwan[/COLOR]', MVTVLOOK + 'country/taiwan/', 235, ART + 'mvtvlook.png', FANART, '')
    addDir('[COLOR orange]thailand[/COLOR]', MVTVLOOK + 'country/thailand/', 235, ART + 'mvtvlook.png', FANART, '')
    addDir('[COLOR orange]tunisia[/COLOR]', MVTVLOOK + 'country/tunisia/', 235, ART + 'mvtvlook.png', FANART, '')
    addDir('[COLOR orange]turkey[/COLOR]', MVTVLOOK + 'country/turkey/', 235, ART + 'mvtvlook.png', FANART, '')
    addDir('[COLOR orange]uk[/COLOR]', MVTVLOOK + 'country/uk/', 235, ART + 'mvtvlook.png', FANART, '')
    addDir('[COLOR orange]ukraine[/COLOR]', MVTVLOOK + 'country/ukraine/', 235, ART + 'mvtvlook.png', FANART, '')
    addDir('[COLOR orange]united-arab-emirates[/COLOR]', MVTVLOOK + 'country/united-arab-emirates/', 235, ART + 'mvtvlook.png', FANART, '')
    addDir('[COLOR orange]united-kingdom[/COLOR]', MVTVLOOK + 'country/united-kingdom/', 235, ART + 'mvtvlook.png', FANART, '')
    addDir('[COLOR orange]united-states[/COLOR]', MVTVLOOK + 'country/united-states/', 235, ART + 'mvtvlook.png', FANART, '')
    addDir('[COLOR orange]uruguay[/COLOR]', MVTVLOOK + 'country/uruguay/', 235, ART + 'mvtvlook.png', FANART, '')
    addDir('[COLOR orange]usa[/COLOR]', MVTVLOOK + 'country/usa/', 235, ART + 'mvtvlook.png', FANART, '')
    addDir('[COLOR orange]vietnam[/COLOR]', MVTVLOOK + 'country/vietnam/', 235, ART + 'mvtvlook.png', FANART, '')


def menu_year(): #232
    years = []
    for i in range(1953, 2023):
        i += 1
        title = '[B][COLOR orange]{}[/COLOR][/B]'.format(str(i))
        link = MVTVLOOK + '/years/{}'.format(str(i))
        years.append((title, link))
    for title, link in sorted(years, reverse=True):
        addDir(title, link, 235, ART + 'mvtvlook.png', FANART, '')

def mvtvlook_23(url): #238
    hdrs = {'Referer': MVTVLOOK,
            'User-Agent': client.agent()}
    p = requests.get(url, headers=hdrs).text
    m = re.compile('format-standard"><a href="(.+?)" rel="bookmark">.+? data-src="(.+?)" alt="(.+?)">.+?<p class="movie-description">(.+?)</p>.+?<span class="movie-date">(.+?)</span>.+?<span class="runtime">(.+?)</span>', re.DOTALL).findall(p)
    for url, icon, name, description, year, time in m:
        name = clear_Title(name)
        fanart = icon
        time = time.replace('min', 'λεπτά')
        time = ' | ' + '[B][COLOR blue]%s[/COLOR][/B]' % time
        name = name + ' (%s)' % year
        if '2023' in year:
            addDir(('[B][COLOR=white]%s [/COLOR][/B]' % name + time), url, 234, icon , fanart, description)
    try:
        m = re.compile('''<a aria-label='next' class='next arrow_pag' href="(.+?)">''').findall(p)[0]
        addDir('[B][COLOR=lime]Επόμενη σελίδα >>[/COLOR][/B]', m, 238, 'http://i.imgur.com/rKSs0yq.png', FANART, '')
    except BaseException:
        pass
    views.selectView('movies', 'movie-view')


def mvtvlook(url): #235
    hdrs = {'Referer': MVTVLOOK,
            'User-Agent': client.agent()}
    p = requests.get(url, headers=hdrs).text
    m = re.compile('format-standard"><a href="(.+?)" rel="bookmark">.+? data-src="(.+?)" alt="(.+?)">.+?<p class="movie-description">(.+?)</p>.+?<span class="movie-date">(.+?)</span>.+?<span class="runtime">(.+?)</span>', re.DOTALL).findall(p)
    for url, icon, name, description, year, time in m:
        name = clear_Title(name)
        fanart = icon
        time = time.replace('min', 'λεπτά')
        time = ' | ' + '[B][COLOR blue]%s[/COLOR][/B]' % time
        name = name + ' (%s)' % year
        addDir(('[B][COLOR=white]%s [/COLOR][/B]' % name + time), url, 234, icon , fanart, description)
    try:
        m = re.compile('''<a aria-label='next' class='next arrow_pag' href="(.+?)">''').findall(p)[0]
        addDir('[B][COLOR=lime]Επόμενη σελίδα >>[/COLOR][/B]', m, 235, 'http://i.imgur.com/rKSs0yq.png', FANART, '')
    except BaseException:
        pass
    views.selectView('movies', 'movie-view')


def get_links(name, url, iconimage, description): #234
    hdrs = {'Referer': MVTVLOOK,
            'User-Agent': client.agent()}
    p = requests.get(url, headers=hdrs).text
    t = re.compile('<a id="hover" href="(.+?)" rel="modal"').findall(p)
    for url in t:
        Trailer = '[B][COLOR=lime]Τρέιλερ[/COLOR][/B]'
        addDir(Trailer, url, 100, ART + 'youtube.png', FANART, str(description))
    try:
        m = re.compile('"movieimdb":"(.+?)"').findall(p)
        for url in m:
            url = 'https://coverapi.store/embed/' + url
            addDir(name, url, 100, iconimage, FANART, str(description))
    except BaseException:
        pass
    try:
        m = re.compile('"tvimdbid":"(.+?)"').findall(p)
        for url in m:
            url = 'https://coverapi.store/embed/' + url
            addDir(name, url, 100, iconimage, FANART, str(description))
        else:
            if not'coverapi' in url :
                name = '[B][COLOR orange] * Το link δεν είναι διαθέσιμο στo site *[/COLOR][/B]'
                addDir(name, url, 100, iconimage, FANART, str(description))
    except BaseException:
        pass


def search(url): #231
    keyb = xbmc.Keyboard('', 'Αναζήτηση Ταινίας - Τήλ.Σειράς')
    keyb.doModal()
    if (keyb.isConfirmed()):
        search = keyb.getText().replace(' ', '+')
        url = MVTVLOOK + '?s=' + search
        mvtvlook(url)

def clear_Title(txt):
    import six
    if six.PY2:
        txt = txt.encode('utf-8', 'ignore')
    else:
        txt = six.ensure_text(txt, encoding='utf-8', errors='ignore')
    txt = re.sub(r'<.+?>', '', txt)
    txt = re.sub(r'var\s+cp.+?document.write\(\'\'\);\s*', '', txt)
    txt = txt.replace("&quot;", "\"").replace('()', '').replace("&#038;", "&").replace('&#8211;', ':').replace('\n',
                                                                                                               ' ')
    txt = txt.replace("&amp;", "&").replace('&#8217;', "'").replace('&#039;', ':').replace('&#;', '\'').replace('&#8230;', '...')
    txt = txt.replace("&#38;", "&").replace('&#8221;', '"').replace('&#8216;', '"').replace('&#160;', '')
    txt = txt.replace("&nbsp;", "").replace('&#8220;', '"').replace('&#8216;', '"').replace('\t', ' ')
    txt = txt.replace('οσ ', 'ος ').replace('οσ:', 'ος:').replace('ασ ', 'ας ').replace('εσ ', 'ες ').replace('ησ ', 'ης ').replace('εισ ', 'εις ').replace('Τησ ', 'Της ')
    return txt
