﻿""""""""""""""""""""""""""""""""""""""""""
"""  Believe in God - Ηelp as you can  """
""""""""""""""""""""""""""""""""""""""""""

import os, sys, glob, base64, xbmc, xbmcvfs, xbmcaddon, xbmcgui, shutil
from datetime import datetime
from urllib.parse import parse_qs
from urllib.request import Request, urlopen

addon_id        = 'plugin.program.downloader19'
addon           = xbmcaddon.Addon(addon_id)
addoninfo       = addon.getAddonInfo
addon_version   = addoninfo('version')
addon_name      = addoninfo('name')
addon_icon      = addoninfo("icon")
addon_fanart    = addoninfo("fanart")
translatePath   = xbmcvfs.translatePath
addon_profile   = translatePath(addoninfo('profile'))
addon_path      = translatePath(addoninfo('path'))
setting         = addon.getSetting
setting_true    = lambda x: bool(True if setting(str(x)) == "true" else False)
setting_set     = addon.setSetting
local_string    = addon.getLocalizedString
home            = translatePath('special://home/')
dialog          = xbmcgui.Dialog()
dp              = xbmcgui.DialogProgress()
BG              = xbmcgui.DialogProgressBG()
xbmcPath        = os.path.abspath(home)
addons_path     = os.path.join(home, 'addons/')
user_path       = os.path.join(home, 'userdata/')
data_path       = os.path.join(user_path, 'addon_data/')
db_path         = os.path.join(user_path, 'Database/')
addons_db       = os.path.join(db_path,'Addons33.db')
textures_db     = os.path.join(db_path,'Textures13.db')
packages        = os.path.join(addons_path, 'packages/')
resources       = os.path.join(addon_path, 'resources/')
#UpdaterMatrix   = os.path.join(user_path, 'UpdaterMatrix/')
Downloader      = os.path.join(data_path, 'plugin.program.downloader19/')
UpdaterMatrix   = os.path.join(Downloader, 'UpdaterMatrix/')
installed_date  = str(datetime.now())[:-7]
EXCLUDES        = [addon_id, 'packages', 'Addons33.db', 'kodi.log']
user_agent      = 'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2272.101 Safari/537.36'
headers         = {'User-Agent': user_agent}
exists          = os.path.exists
yes_label       = '[COLOR lime]Ναι[/COLOR]'
no_label        = '[COLOR orange]Όχι[/COLOR]'
Background_path = 'Skin.SetImage(CustomDefaultBackground.path,special://home/addons/skin.TechNEWSology/backgrounds/)'
icon            = resources +'icon.gif'
icon_YouTube    = resources +'media/youtube.png'
icon_Build      = resources +'media/technewsology.png'
icon_Clean      = resources +'media/clean.png'
icon_Cleaner    = resources +'media/Cleaner.gif'
icon_Settings   = resources +'media/Settings.png'
icon_Settings_t = resources +'media/Settings_t.png'
icon_Notify     = resources +'media/Notify.png'
icon_Skinshortcuts        = resources +'media/skinshortcuts.png'
addon_data_youtube        = translatePath('special://home/userdata/addon_data/plugin.video.youtube')
advancedsettings_xml      =  os.path.join(user_path, 'advancedsettings.xml')
advancedsettings_folder   = os.path.join(resources, 'advancedsettings/')
addon_data_skinshortcuts  = translatePath('special://home/userdata/addon_data/script.skinshortcuts')
addons_data_path          = [translatePath('special://home/addons'), translatePath('special://home/userdata/addon_data')]
Dialog_TechNEWSology      = '[B][COLOR orange]TechNEWSology[/COLOR][/B]'
Dialog_welcome            = '[B][COLOR orange]Καλώς ήρθατε![/COLOR][/B]'
Dialog_Update             = '[B][COLOR white]Έναρξη TechNEWSology Updater ...[/COLOR][/B]'
Dialog_enable_on          = '[COLOR white]Επιλέξατε την ενεργοποίηση όλων των πρόσθετων[/COLOR]'
Dialog_enable             = '[COLOR lime]Τα πρόσθετα έχουν ενεργοποιηθεί![/COLOR]'
Dialog_not_Updater        = '[B]Οι αυτόματες ενημερώσεις είναι απενερ/μένες[/B]'
Dialog_Update_AddonsRepos = 'Αλλαγή αποθετηρίων σε πρόσθετα'
Dialog_LoadProfile        = '[COLOR white]Πατώντας [COLOR lime]Ναι[COLOR white], οι αλλαγές θα πραγματοποιηθούν τώρα[CR](η εικόνα θα παγώσει για λίγα δευτερόλεπτα μέχρι να γίνει επαναφόρτωση του προφίλ).[CR]Πατώντας [COLOR orange]Όχι[COLOR white], οι αλλαγές θα πραγματοποιηθούν στην επόμενη εκκίνηση του Build.[/COLOR]'
Dialog_Xml_Skin           = 'Προσθήκες-Διορθώσεις στο κέλυφος του Build ...'
Dialog_Players            = 'Διόρθωση/Εισαγωγή [COLOR lime]Players[/COLOR] TheMovieDb Helper ...'
Dialog_ReloadSkin         = 'Θα πραγματοποιηθεί [COLOR lime]επανεκκίνηση[/COLOR] κελύφους ...'
Dialog_Database           = 'Νέες καταχωρίσεις στην Database ...'
Dialog_Py                 = 'Διόρθωση/Εισαγωγή [COLOR lime]νέων αρχείων [/COLOR]στο Build ...'
Dialog_U1                 = '[B]Αναμονή για ολοκλήρωση ενημέρωσης[/B]'
Dialog_U2                 = 'Περιμένετε χωρίς να πατήσετε κάτι ...'
Dialog_U3                 = 'Εισαγωγή στοιχείων ...'
Dialog_U4                 = '[B][COLOR lime]Ολοκληρώθηκε με επιτυχία[/COLOR][/B]'
Dialog_U5                 = 'To Build είναι ενημερωμένο!'
Dialog_U6                 = 'Έλεγχος πρόσθετων για αναβαθμίσεις ...'
Dialog_U7                 = '[B][COLOR orange]TechNEWSology[/COLOR][/B]'
Dialog_U8                 = '[B]Έναρξη ενημέρωσης[/B]'
Dialog_U9                 = '[B][COLOR lime]Επιτυχής ενημέρωση![/COLOR][/B]'
Dialog_U10                = 'Διαγραφή αρχείων ...'
Dialog_U11                = 'Αναζήτηση αρχείων προς διαγραφή ...'
Dialog_U12                = '[B]Διαδικασία ενημέρωσης[/B]'
Dialog_U13                = '[B]Όλα είναι έτοιμα![/B]'


SRV = 'RunPlugin(plugin://plugin.program.downloader19/?url=https://gknwizard.eu/repo/Builds/TechNEWsology/UpdaterMatrix/'
GKN = 'https://gknwizard.eu/repo/Builds/TechNEWsology/UpdaterMatrix/XML/'

headers_TXT = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:58.0) Gecko/20100101 Firefox/58.0',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.5',
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1'}

downloader_startup        = 'RunScript(special://home/addons/plugin.program.downloader19/downloader_startup.py)'
downloader_startup_delete = 'special://home/addons/plugin.program.downloader19/downloader_startup.py'
downloader_startup_tk     = translatePath('special://home/addons/plugin.program.downloader19/downloader_startup.py')
del_startup               = 'RunScript(special://home/userdata/addon_data/plugin.program.downloader19/delete_files.py)'
install_startup           = 'RunScript(special://home/userdata/addon_data/plugin.program.downloader19/addons_list_installation.py)'
database_startup          = 'RunScript(special://home/userdata/addon_data/plugin.program.downloader19/Database_Addons33.py)'
set_setting_startup       = 'RunScript(special://home/userdata/addon_data/plugin.program.downloader19/set_setting.py)'


tempfile_1  = os.path.join(packages, 'tempfile.zip')
tempfile_2  = os.path.join(packages, 'tempfile_2.zip')
tempfile_3  = os.path.join(packages, 'tempfile_3.zip')
tempfile_4  = os.path.join(packages, 'tempfile_4.zip')
tempfile_5  = os.path.join(packages, 'tempfile_5.zip')
tempfile_6  = os.path.join(packages, 'tempfile_6.zip')
tempfile_7  = os.path.join(packages, 'tempfile_7.zip')
tempfile_8  = os.path.join(packages, 'tempfile_8.zip')
tempfile_9  = os.path.join(packages, 'tempfile_9.zip')
tempfile_10 = os.path.join(packages, 'tempfile_10.zip')
tempfile_11 = os.path.join(packages, 'tempfile_11.zip')
tempfile_12 = os.path.join(packages, 'tempfile_12.zip')
tempfile_13 = os.path.join(packages, 'tempfile_13.zip')
tempfile_14 = os.path.join(packages, 'tempfile_14.zip')
tempfile_15 = os.path.join(packages, 'tempfile_15.zip')

UpdaterMatrix_path   = os.path.join(UpdaterMatrix, 'UpdaterMatrix_1.md5')
UpdaterMatrix_path2  = os.path.join(UpdaterMatrix, 'UpdaterMatrix_2.md5')
UpdaterMatrix_path3  = os.path.join(UpdaterMatrix, 'UpdaterMatrix_3.md5')
UpdaterMatrix_path4  = os.path.join(UpdaterMatrix, 'UpdaterMatrix_4.md5')
UpdaterMatrix_path5  = os.path.join(UpdaterMatrix, 'UpdaterMatrix_5.md5')
UpdaterMatrix_path6  = os.path.join(UpdaterMatrix, 'UpdaterMatrix_6.md5')
UpdaterMatrix_path7  = os.path.join(UpdaterMatrix, 'UpdaterMatrix_7.md5')
UpdaterMatrix_path8  = os.path.join(UpdaterMatrix, 'UpdaterMatrix_8.md5')
UpdaterMatrix_path9  = os.path.join(UpdaterMatrix, 'UpdaterMatrix_9.md5')
UpdaterMatrix_path10 = os.path.join(UpdaterMatrix, 'UpdaterMatrix_10.md5')
UpdaterMatrix_path11 = os.path.join(UpdaterMatrix, 'UpdaterMatrix_11.md5')
UpdaterMatrix_path12 = os.path.join(UpdaterMatrix, 'UpdaterMatrix_12.md5')
UpdaterMatrix_path13 = os.path.join(UpdaterMatrix, 'UpdaterMatrix_13.md5')
UpdaterMatrix_path14 = os.path.join(UpdaterMatrix, 'UpdaterMatrix_14.md5')
UpdaterMatrix_path15 = os.path.join(UpdaterMatrix, 'UpdaterMatrix_15.md5')
UpdaterMatrix_path16 = os.path.join(UpdaterMatrix, 'UpdaterMatrix_16.md5')
UpdaterMatrix_path17 = os.path.join(UpdaterMatrix, 'UpdaterMatrix_17.md5')
UpdaterMatrix_path18 = os.path.join(UpdaterMatrix, 'UpdaterMatrix_18.md5')
UpdaterMatrix_path19 = os.path.join(UpdaterMatrix, 'UpdaterMatrix_19.md5')
UpdaterMatrix_path20 = os.path.join(UpdaterMatrix, 'UpdaterMatrix_20.md5')
UpdaterMatrix_path21 = os.path.join(UpdaterMatrix, 'UpdaterMatrix_21.md5')
UpdaterMatrix_path22 = os.path.join(UpdaterMatrix, 'UpdaterMatrix_22.md5')
UpdaterMatrix_path23 = os.path.join(UpdaterMatrix, 'UpdaterMatrix_23.md5')
UpdaterMatrix_path24 = os.path.join(UpdaterMatrix, 'UpdaterMatrix_24.md5')
UpdaterMatrix_path25 = os.path.join(UpdaterMatrix, 'UpdaterMatrix_25.md5')
UpdaterMatrix_path26 = os.path.join(UpdaterMatrix, 'UpdaterMatrix_26.md5')
UpdaterMatrix_path27 = os.path.join(UpdaterMatrix, 'UpdaterMatrix_27.md5')
UpdaterMatrix_path28 = os.path.join(UpdaterMatrix, 'UpdaterMatrix_28.md5')
UpdaterMatrix_path29 = os.path.join(UpdaterMatrix, 'UpdaterMatrix_29.md5')
UpdaterMatrix_path30 = os.path.join(UpdaterMatrix, 'UpdaterMatrix_30.md5')
UpdaterMatrix_path31 = os.path.join(UpdaterMatrix, 'UpdaterMatrix_31.md5')
UpdaterMatrix_path32 = os.path.join(UpdaterMatrix, 'UpdaterMatrix_32.md5')
UpdaterMatrix_path33 = os.path.join(UpdaterMatrix, 'UpdaterMatrix_33.md5')
UpdaterMatrix_path34 = os.path.join(UpdaterMatrix, 'UpdaterMatrix_34.md5')
UpdaterMatrix_path35 = os.path.join(UpdaterMatrix, 'UpdaterMatrix_35.md5')
UpdaterMatrix_path36 = os.path.join(UpdaterMatrix, 'UpdaterMatrix_36.md5')
UpdaterMatrix_path37 = os.path.join(UpdaterMatrix, 'UpdaterMatrix_37.md5')
UpdaterMatrix_path38 = os.path.join(UpdaterMatrix, 'UpdaterMatrix_38.md5')
UpdaterMatrix_path39 = os.path.join(UpdaterMatrix, 'UpdaterMatrix_39.md5')
UpdaterMatrix_path40 = os.path.join(UpdaterMatrix, 'UpdaterMatrix_40.md5')
UpdaterMatrix_path41 = os.path.join(UpdaterMatrix, 'UpdaterMatrix_41.md5')
UpdaterMatrix_path42 = os.path.join(UpdaterMatrix, 'UpdaterMatrix_42.md5')
UpdaterMatrix_path43 = os.path.join(UpdaterMatrix, 'UpdaterMatrix_43.md5')
UpdaterMatrix_path44 = os.path.join(UpdaterMatrix, 'UpdaterMatrix_44.md5')
UpdaterMatrix_path45 = os.path.join(UpdaterMatrix, 'UpdaterMatrix_45.md5')
UpdaterMatrix_path46 = os.path.join(UpdaterMatrix, 'UpdaterMatrix_46.md5')
UpdaterMatrix_path47 = os.path.join(UpdaterMatrix, 'UpdaterMatrix_47.md5')
UpdaterMatrix_path48 = os.path.join(UpdaterMatrix, 'UpdaterMatrix_48.md5')
UpdaterMatrix_path49 = os.path.join(UpdaterMatrix, 'UpdaterMatrix_49.md5')
UpdaterMatrix_path50 = os.path.join(UpdaterMatrix, 'UpdaterMatrix_50.md5')

UpdaterMatrix_pathT1 = os.path.join(UpdaterMatrix, 'UpdaterMatrix_T1.md5')
UpdaterMatrix_pathT2 = os.path.join(UpdaterMatrix, 'UpdaterMatrix_T2.md5')
UpdaterMatrix_pathT3 = os.path.join(UpdaterMatrix, 'UpdaterMatrix_T3.md5')

Installer_path       = os.path.join(UpdaterMatrix, 'Installer_1.md5')

Skinshortcuts_path   = translatePath('special://home/userdata/addon_data/script.skinshortcuts/skinshortcuts_1.md5')
Skinshortcuts_path2  = translatePath('special://home/userdata/addon_data/script.skinshortcuts/skinshortcuts_2.md5')

bzipfile                  = GKN + 'Build.txt'

api_youtube               = GKN + 'Youtube.txt'
notify_url                = GKN + 'notify.txt'
check_url_updater         = GKN + 'check_updater.txt'
py_url_updater            = GKN + 'py_updater.txt'
notify_url_updater        = GKN + 'notify_updater.txt'
skinshortcuts_url_updater = GKN + 'skinshortcuts_updater.txt'
addonsrepos_url_updater   = GKN + 'addonsrepos_updater.txt'
xmlskin_url_updater       = GKN + 'xmlskin_updater.txt'
players_url_updater       = GKN + 'players_updater.txt'
setting_url_updater       = GKN + 'setsetting_updater.txt'
installation_url_updater  = GKN + 'addonslistinstallation_updater.txt'
deletefiles_url_updater   = GKN + 'deletefiles_updater.txt'
var_url_updater           = GKN + 'var_updater.txt'
zip1_url_updater          = GKN + 'zip1_updater.txt'
zip2_url_updater          = GKN + 'zip2_updater.txt'
zip3_url_updater          = GKN + 'zip3_updater.txt'
zip4_url_updater          = GKN + 'zip4_updater.txt'
zip5_url_updater          = GKN + 'zip5_updater.txt'
zip6_url_updater          = GKN + 'zip6_updater.txt'
zip7_url_updater          = GKN + 'zip7_updater.txt'
zip8_url_updater          = GKN + 'zip8_updater.txt'
zip9_url_updater          = GKN + 'zip9_updater.txt'
zip10_url_updater         = GKN + 'zip10_updater.txt'
zip11_url_updater         = GKN + 'zip11_updater.txt'
zip12_url_updater         = GKN + 'zip12_updater.txt'

Check_startup        = SRV + 'Check_startup.zip&mode=9)'
Py_startup           = SRV + 'Py_startup.zip&mode=9)'
Updater_startup      = SRV + 'Updater_startup_new.zip&mode=9)'
skinshortcuts_menu   = SRV + 'skinshortcuts_menu.zip&mode=9)'
AddonsRepos_startup  = SRV + 'AddonsRepos_startup.zip&mode=9)'
XmlSkin_startup      = SRV + 'XmlSkin_startup.zip&mode=9)'
Players_startup      = SRV + 'Players_startup.zip&mode=9)'
SetSetting_startup   = SRV + 'SetSetting_startup.zip&mode=9)'
Installation_startup = SRV + 'Installation_startup.zip&mode=9)'
Delete_startup       = SRV + 'Delete_startup.zip&mode=9)'
Var_startup          = SRV + 'Var_startup.zip&mode=9)'
Zip1_startup         = SRV + 'Zip1_startup.zip&mode=9)'
Zip2_startup         = SRV + 'Zip2_startup.zip&mode=9)'
Zip3_startup         = SRV + 'Zip3_startup.zip&mode=9)'
Zip4_startup         = SRV + 'Zip4_startup.zip&mode=9)'
Zip5_startup         = SRV + 'Zip5_startup.zip&mode=9)'
Zip6_startup         = SRV + 'Zip6_startup.zip&mode=9)'
Zip7_startup         = SRV + 'Zip7_startup.zip&mode=9)'
Zip8_startup         = SRV + 'Zip8_startup.zip&mode=9)'
Zip9_startup         = SRV + 'Zip9_startup.zip&mode=9)'
Zip10_startup        = SRV + 'Zip10_startup.zip&mode=9)'
Zip11_startup        = SRV + 'Zip11_startup.zip&mode=9)'
Zip12_startup        = SRV + 'Zip12_startup.zip&mode=9)'

Backgrounds_With_Widgets = SRV + 'Backgrounds_With_Widgets.zip&mode=9&name=Backgrounds With Widgets)'
Backgrounds_Without_Widgets = SRV + 'Backgrounds_Without_Widgets.zip&mode=9&name=Backgrounds Without Widgets)'

skinshortcuts_not = SRV + 'skinshortcuts_not.zip&mode=9&name=Skinshortcuts without Widgets)'
skinshortcuts_0   = SRV + 'skinshortcuts.zip&mode=9&name=Skinshortcuts with Widgets)'
skinshortcuts_2   = SRV + 'skinshortcuts_2.zip&mode=9&name=Ενημέρωση στο μενού Skinshortcuts)'

UpdaterMatrix_1  = SRV + 'UpdaterMatrix_1.zip&mode=9)'
UpdaterMatrix_2  = SRV + 'UpdaterMatrix_2.zip&mode=9)'
UpdaterMatrix_3  = SRV + 'UpdaterMatrix_3.zip&mode=9)'
UpdaterMatrix_4  = SRV + 'UpdaterMatrix_4.zip&mode=9)'
UpdaterMatrix_5  = SRV + 'UpdaterMatrix_5.zip&mode=9)'
UpdaterMatrix_6  = SRV + 'UpdaterMatrix_6.zip&mode=9)'
UpdaterMatrix_7  = SRV + 'UpdaterMatrix_7.zip&mode=9)'
UpdaterMatrix_8  = SRV + 'UpdaterMatrix_8.zip&mode=9)'
UpdaterMatrix_9  = SRV + 'UpdaterMatrix_9.zip&mode=9)'
UpdaterMatrix_10 = SRV + 'UpdaterMatrix_10.zip&mode=9)'
UpdaterMatrix_11 = SRV + 'UpdaterMatrix_11.zip&mode=9)'
UpdaterMatrix_12 = SRV + 'UpdaterMatrix_12.zip&mode=9)'
UpdaterMatrix_13 = SRV + 'UpdaterMatrix_13.zip&mode=9)'
UpdaterMatrix_14 = SRV + 'UpdaterMatrix_14.zip&mode=9)'
UpdaterMatrix_15 = SRV + 'UpdaterMatrix_15.zip&mode=9)'
UpdaterMatrix_16 = SRV + 'UpdaterMatrix_16.zip&mode=9)'
UpdaterMatrix_17 = SRV + 'UpdaterMatrix_17.zip&mode=9)'
UpdaterMatrix_18 = SRV + 'UpdaterMatrix_18.zip&mode=9)'
UpdaterMatrix_19 = SRV + 'UpdaterMatrix_19.zip&mode=9)'
UpdaterMatrix_20 = SRV + 'UpdaterMatrix_20.zip&mode=9)'
UpdaterMatrix_21 = SRV + 'UpdaterMatrix_21.zip&mode=9)'
UpdaterMatrix_22 = SRV + 'UpdaterMatrix_22.zip&mode=9)'
UpdaterMatrix_23 = SRV + 'UpdaterMatrix_23.zip&mode=9)'
UpdaterMatrix_24 = SRV + 'UpdaterMatrix_24.zip&mode=9)'
UpdaterMatrix_25 = SRV + 'UpdaterMatrix_25.zip&mode=9)'
UpdaterMatrix_26 = SRV + 'UpdaterMatrix_26.zip&mode=9)'
UpdaterMatrix_27 = SRV + 'UpdaterMatrix_27.zip&mode=9)'
UpdaterMatrix_28 = SRV + 'UpdaterMatrix_28.zip&mode=9)'
UpdaterMatrix_29 = SRV + 'UpdaterMatrix_29.zip&mode=9)'
UpdaterMatrix_30 = SRV + 'UpdaterMatrix_30.zip&mode=9)'
UpdaterMatrix_31 = SRV + 'UpdaterMatrix_31.zip&mode=9)'
UpdaterMatrix_32 = SRV + 'UpdaterMatrix_32.zip&mode=9)'
UpdaterMatrix_33 = SRV + 'UpdaterMatrix_33.zip&mode=9)'
UpdaterMatrix_34 = SRV + 'UpdaterMatrix_34.zip&mode=9)'
UpdaterMatrix_35 = SRV + 'UpdaterMatrix_35.zip&mode=9)'
UpdaterMatrix_36 = SRV + 'UpdaterMatrix_36.zip&mode=9)'
UpdaterMatrix_37 = SRV + 'UpdaterMatrix_37.zip&mode=9)'
UpdaterMatrix_38 = SRV + 'UpdaterMatrix_38.zip&mode=9)'
UpdaterMatrix_39 = SRV + 'UpdaterMatrix_39.zip&mode=9)'
UpdaterMatrix_40 = SRV + 'UpdaterMatrix_40.zip&mode=9)'
UpdaterMatrix_41 = SRV + 'UpdaterMatrix_41.zip&mode=9)'
UpdaterMatrix_42 = SRV + 'UpdaterMatrix_42.zip&mode=9)'
UpdaterMatrix_43 = SRV + 'UpdaterMatrix_43.zip&mode=9)'
UpdaterMatrix_44 = SRV + 'UpdaterMatrix_44.zip&mode=9)'
UpdaterMatrix_45 = SRV + 'UpdaterMatrix_45.zip&mode=9)'
UpdaterMatrix_46 = SRV + 'UpdaterMatrix_46.zip&mode=9)'
UpdaterMatrix_47 = SRV + 'UpdaterMatrix_47.zip&mode=9)'
UpdaterMatrix_48 = SRV + 'UpdaterMatrix_48.zip&mode=9)'
UpdaterMatrix_49 = SRV + 'UpdaterMatrix_49.zip&mode=9)'
UpdaterMatrix_50 = SRV + 'UpdaterMatrix_50.zip&mode=9)'

UpdaterMatrix_T1 = 'RunPlugin(plugin://plugin.program.downloader19/?url=https%3A%2F%2Fgithub.com%2FTechNEWSologyBuilds%2FUploader%2Fraw%2Fmain%2FUpdaterMatrix_T1.zip&mode=9)'
UpdaterMatrix_T2 = 'RunPlugin(plugin://plugin.program.downloader19/?url=https%3A%2F%2Fgithub.com%2FTechNEWSologyBuilds%2FUploader%2Fraw%2Fmain%2FUpdaterMatrix_T2.zip&mode=9)'
UpdaterMatrix_T3 = 'RunPlugin(plugin://plugin.program.downloader19/?url=https%3A%2F%2Fgithub.com%2FTechNEWSologyBuilds%2FUploader%2Fraw%2Fmain%2FUpdaterMatrix_T3.zip&mode=9)'

def isBase64(s):
    if base64.b64encode(base64.b64decode(s)).decode('utf8') == s:
        return True
    else:
        return False
