# Module: default
# Author: jurialmunkey
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html
import sys
from resources.lib.script.context import router

if __name__ == '__main__':
    router(sys.argv[1])
