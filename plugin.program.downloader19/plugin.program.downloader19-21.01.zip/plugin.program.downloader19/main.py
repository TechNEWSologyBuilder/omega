﻿import os, sys, shutil, json, base64, xbmc, xbmcplugin, xbmcaddon, xbmcgui
import xml.etree.ElementTree as ET
from xbmc import log
from updatervar import *
from zipfile import ZipFile
from urllib.request import urlopen
from urllib.request import Request
from urllib.parse import unquote_plus
from resources.lib.modules.utils import addDir, play_video
from resources.lib.modules import skinSwitch
from resources.lib.modules.downloader import downloader, downloader_b
from resources.lib.modules.save_data import save_check, save_backup, save_restore, save_menu
from resources.lib.modules.backup_restore import backup_gui, backup_build, restore_menu, restore_menu_gui, restore_gui, restore_build, restore_gui_build, get_backup_folder, reset_backup_folder
from resources.lib.modules.parser import Parser
from resources.lib.modules import control, cache
from resources.lib.modules import maintenance

addon_build ='[B][COLOR orange]TechNEWSology Build[/COLOR][/B]'
args = parse_qs(sys.argv[2][1:])
KODIV  = float(xbmc.getInfoLabel("System.BuildVersion")[:4])
handle = int(sys.argv[1])

def currSkin():
    return xbmc.getSkinDir()
def percentage(part, whole):
    return 100 * float(part)/float(whole)


def MainMenu():
    addDir(addon_build + '[COLOR lime] [v%s][/COLOR]' % addon_version,'','',icon_Build,addon_fanart,'',isFolder=False)
    addDir('[COLOR orange][B]=====================================[/B][/COLOR]', '', '', icon_Build, addon_fanart,'', isFolder=False)
    addDir('[B][COLOR lime]Καθαρή Εγκατάσταση[/COLOR][/B]','',12,icon_Build,addon_fanart,'',isFolder=True)
    addDir('[B][COLOR white]Συντήρηση [/COLOR][/B]','',33,icon_Build,addon_fanart,'',isFolder=True)
#    addDir('[B][COLOR white]Εργαλεία [/COLOR][/B]','',14,icon_Build,addon_fanart,'',isFolder=False)
    addDir('[B][COLOR white]Ρυθμίσεις [/COLOR][/B]','',2,icon_Build,addon_fanart,'',isFolder=False)
    addDir('[B][COLOR white]Μήνυμα καταγραφής[/COLOR][/B]','',100,icon_Build,addon_fanart,'Bring up the notifications dialog',isFolder=False)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def subMenu_maintenance():
    addDir('[COLOR white]Εκκαθάριση Παρόχων[/COLOR]','',23,icon_Build,addon_fanart,'',isFolder=False)
    addDir('[COLOR white]Εκκαθάριση Πακέτων[/COLOR]','',6,icon_Build,addon_fanart,'',isFolder=False)
    addDir('[COLOR white]Εκκαθάριση Μικρογραφιών[/COLOR]','',7,icon_Build,addon_fanart,'',isFolder=False)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def main_backup_restore():
    addDir('[COLOR white]Αντίγραφο - Build[/COLOR]', '', 18,icon_Build, addon_fanart,'Backup Build', isFolder=False)
    addDir('[COLOR white]Αντίγραφο - GuiSettings[/COLOR]', '', 35,icon_Build, addon_fanart,'Backup Build', isFolder=False)
    addDir('[COLOR white]Επαναφορά από αντίγραφο Build[/COLOR]', '', 19, icon_Build, addon_fanart,'Restore Backup')
    addDir('[COLOR white]Επαναφορά από αντίγραφο GuiSettings[/COLOR]', '',38, icon_Build, addon_fanart,'Restore Backup')
    addDir('[COLOR white]Επαναφορά προεπιλεγμένων GuiSettings Build[/COLOR]', '', 37, icon_Build, addon_fanart,'Restore Backup')
    addDir('[COLOR white]Αλλαγή τοποθεσίας αντιγράφων ασφαλείας[/COLOR]', '', 21, icon_Build, addon_fanart,'Change the location where backups will be stored and accessed.', isFolder=False)
    addDir('[COLOR white]Επαναφορά θέσης αντιγράφων ασφαλείας[/COLOR]', '', 22, icon_Build, addon_fanart,'Set the backup location to its default.', isFolder=False)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def main_enable_addons():
    addDir('[COLOR white]Remove Addons[/COLOR]', '', 43, icon_Build, addon_fanart, '', isFolder=False)
    addDir('[COLOR white]Remove Addon Data[/COLOR]', '',47, icon_Build, addon_fanart, '', isFolder=True)
    addDir('[COLOR white]Force Update Addons[/COLOR]', '', 46, icon_Build, addon_fanart, '',isFolder=False)
    addDir('[COLOR white]Enable/Disable Addons[/COLOR]', '', 52,icon_Build, addon_fanart, '', isFolder=True)
#    addDir('[COLOR white]Ενεργοποίηση όλων των πρόσθετων[/COLOR]', '', 25, icon_Build, addon_fanart, '', isFolder=False)
#    addDir('[COLOR white]Ενεργοποίηση όλων των πρόσθετων στην επόμενη εκκίνηση[/COLOR]', '', 26, icon_Build, addon_fanart,'', isFolder=False)
#    addDir('[COLOR white]Ακύρωση ενεργοποίησης στην επόμενη εκκίνηση[/COLOR]', '', 27, icon_Build, addon_fanart, '', isFolder=False)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def main_maintenance():
    addDir('[B][COLOR white]Εκκαθάριση[/COLOR][/B]','',5,icon_Build,addon_fanart,'',isFolder=True)
    addDir('[B][COLOR white]Πρόσθετα Εργαλεία[/COLOR][/B]','',28,icon_Build,addon_fanart,'',isFolder=True)
    addDir('[B][COLOR white]Διάφορα Συντήρησης[/COLOR][/B]','',39,icon_Build,addon_fanart,'',isFolder=True)
    addDir('[B][COLOR white]Αντίγραφο ασφαλείας & Επαναφορά[/COLOR][/B]','',17,icon_Build,addon_fanart,'',isFolder=True)
    addDir('[B][COLOR white]Τροποποιήσεις Συστήματος - Διορθώσεις[/COLOR][/B]','',50,icon_Build,addon_fanart,'',isFolder=True)
#    addDir('[B][COLOR white]Απενεργοποίηση αυτόματων ενημερώσεων TecNEWSology Updater[/COLOR][/B]','',29,icon_Build,addon_fanart,'',isFolder=True)
#    addDir('[B][COLOR white]Eνεργοποίηση αυτόματων ενημερώσεων TecNEWSology Updater[/COLOR][/B]','',30,icon_Build,addon_fanart,'',isFolder=True)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def main_misc_maintenance():
    addDir('[COLOR white]Reload Skin[/COLOR]','',40,icon_Build,addon_fanart,'',isFolder=False)
    addDir('[COLOR white]Reload Profile[/COLOR]','',41,icon_Build,addon_fanart,'',isFolder=False)
    addDir('[COLOR white]YouTube Api Key[/COLOR]','',1,icon_Build,addon_fanart,'',isFolder=True)
    addDir('[COLOR white]Εγκατάσταση Binary Addons[/COLOR]','',16,icon_Build,addon_fanart,'',isFolder=False)
    addDir('[COLOR white]Εξουσιοδότηση/Επαναφορά Derbid[/COLOR]','',24,icon_Build,addon_fanart,'',isFolder=False)
    addDir('[COLOR white]Speedtest[/COLOR]','',31,icon_Build,addon_fanart,'', isFolder=False)
    addDir('[COLOR white]View Log[/COLOR]','', 32, icon_Build,addon_fanart,'', isFolder=False)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def system_fixes():
    addDir('[COLOR white]Advanced Settings[/COLOR]','',4,icon_Build,addon_fanart,'',isFolder=False)
    addDir('[COLOR white]Scan Sources For Broken Links[/COLOR]','',56,icon_Build,addon_fanart,'',isFolder=False)
    addDir('[COLOR white]Scan For Broken Repositories[/COLOR]','',55,icon_Build,addon_fanart,'',isFolder=False)
    addDir('[COLOR white]Convert Paths Special[/COLOR]','',42,icon_Build,addon_fanart,'',isFolder=False)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))


def remove_addon_data_menu():
    addons_files = xbmcvfs.translatePath('special://home/addons')
    addon_data_files = xbmcvfs.translatePath('special://home/userdata/addon_data')
    ADDON_ID = xbmcaddon.Addon().getAddonInfo('id')
    EXCLUDES = [ADDON_ID, 'plugin.program.downloader19']
    if os.path.exists(addon_data_files):
        addDir('[COLOR red][B][REMOVE][/B][/COLOR] All Addon_Data','', 44,icon_Build,addon_fanart,'', isFolder=False)
        addDir('[COLOR red][B][REMOVE][/B][/COLOR] All Addon_Data for Uninstalled Addons','', 45, icon_Build, addon_fanart,'', isFolder=False)
        addDir('[COLOR red][B][REMOVE][/B][/COLOR] All Empty Folders in Addon_Data','', 48, icon_Build, addon_fanart,'', isFolder=False)
        addDir('[COLOR red][B][REMOVE][/B][/COLOR] {0} Addon_Data'.format(addon_build),'', 49, icon_Build, addon_fanart,'', isFolder=False)
        addDir('[COLOR red][B]=====================================[/B][/COLOR]', '', '', icon_Build, addon_fanart,'', isFolder=False)

        fold = glob.glob(os.path.join(addon_data_files, '*/'))
        for folder in sorted(fold, key = lambda x: x):
            foldername = folder.replace(addon_data_files, '').replace('\\', '').replace('/', '')
            icon = os.path.join(folder.replace(addon_data_files, addons_files), 'icon.png')
            fanart = os.path.join(folder.replace(addon_data_files, addons_files), 'fanart.jpg')
            folderdisplay = foldername
            replace = {'audio.': '[COLOR orange][AUDIO] [/COLOR]', 'metadata.': '[COLOR cyan][METADATA] [/COLOR]',
                       'module.': '[COLOR orange][MODULE] [/COLOR]', 'plugin.': '[COLOR blue][PLUGIN] [/COLOR]',
                       'program.': '[COLOR orange][PROGRAM] [/COLOR]', 'repository.': '[COLOR gold][REPO] [/COLOR]',
                       'script.': '[COLOR springgreen][SCRIPT] [/COLOR]',
                       'pvr.': '[COLOR lime][PVR] [/COLOR]', 'pvr.': '[COLOR lime][PVR] [/COLOR]',
                       'service.': '[COLOR springgreen][SERVICE] [/COLOR]', 'skin.': '[COLOR dodgerblue][SKIN] [/COLOR]',
                       'video.': '[COLOR orange][VIDEO] [/COLOR]', 'weather.': '[COLOR yellow][WEATHER] [/COLOR]'}
            for rep in replace:
                folderdisplay = folderdisplay.replace(rep, replace[rep])
            if foldername in EXCLUDES:
                folderdisplay = '[COLOR springgreen][B][PROTECTED][/B][/COLOR] {0}'.format(folderdisplay)
            else:
                folderdisplay = '[COLOR red][B][REMOVE][/B][/COLOR] {0}'.format(folderdisplay)
            
            addDir(' {0}'.format(folderdisplay), '', 51, icon, fanart, '', foldername, isFolder=False)

    else:
        addDir('No Addon data folder found.','','',icon_Build,addon_fanart,'', isFolder=False)


def main_ApiMenu(NAME, NAME2, VERSION, URL, ICON, FANART, DESCRIPTION):
    yes_api = dialog.yesno(NAME, '[COLOR white]Αν το Api Key Youtube έχει υπερβεί το ημερήσιο όριο αναπαραγωγής και δε λειτουργεί, δοκιμάζουμε κάποιο άλλο. Το ημερήσιο όριο αναπαραγωγής ανανεώνεται καθημερινά στις 10:00 π.μ.[CR]Για να μην υπερβαίνετε το ημερήσιο όριο, δημιουργήστε δικό σας API KEY (μια μικρή αναζήτηση στο διαδίκτυο θα σας δείξει τον τρόπο).[/COLOR]', nolabel='Άκυρο', yeslabel='Συνέχεια')
    if yes_api:
        downloader(NAME, NAME2, VERSION, URL)
        dialog.notification("[B][COLOR red]YouTube [COLOR white]Api Key[/COLOR][/B]",'[COLOR white]Επιτυχής καταχώριση κλειδιού![/COLOR]' , icon_YouTube)
    else:
        return

def main_Skinshortcuts(NAME, NAME2, VERSION, URL, ICON, FANART, DESCRIPTION):
    downloader(NAME, NAME2, VERSION, URL)

def main_BuildMenu(NAME, NAME2, VERSION, URL, ICON, FANART, DESCRIPTION):
    yesSave = dialog.yesno('[B][COLOR lime]Εγκατάσταση TechNEWSology Build[/COLOR][/B]', '[COLOR red]                                        ΠΡΟΣΟΧΗ![/COLOR][CR]  Θα πραγματοποιηθεί διαγραφή όλων των αρχείων και[CR]  εκ νέου καθαρή εγκατάσταση του Build από την αρχή![CR][CR] (Σε περίπτωση που έχουμε το Build εγκαταστημένο, θα ακολουθήσει επιλογή διατήρησης στοιχείων κατά την νέα εγκατάσταση στη συσκευή μας)', nolabel='[COLOR orange]Ακυρο[/COLOR]', yeslabel='[COLOR lime]Συνέχεια[/COLOR]')
    if yesSave:
        if os.path.exists(xbmcvfs.translatePath('special://home/addons/skin.TechNEWSology')):
            save_menu()
        save_check()
        save_backup()
    else:
        return
    yesInstall = dialog.yesno(NAME, '[COLOR white]Επιθυμείτε να συνεχιστεί η καθαρή εγκατάσταση του Build;[/COLOR]', nolabel='[COLOR orange]Άκυρο[/COLOR]', yeslabel='[COLOR lime]Ναι, επιθυμώ[/COLOR]')
    if yesInstall:
        freshStart()
        downloader_b(NAME, NAME2, VERSION, URL)
        dialog.ok(addon_name, '[COLOR lime]Το Build εγκαταστάθηκε με επιτυχία ![/COLOR][CR]Πατώντας Οκ θα τερματίσει το Kodi. Στην πρώτη έναρξη δώστε του 2 λεπτά να λάβει τις απαραίτητες ενημερώσεις.[CR]Για τη σωστή λειτουργία των πρόσθετων είναι απαραίτητη η αλλαγή DNS.')
        os._exit(1)
    else:
        return

def main_downloader(NAME, NAME2, VERSION, URL, ICON, FANART, DESCRIPTION):
    downloader(NAME, NAME2, VERSION, URL)

def enable_now():
    yes_enable = dialog.yesno(addon_name, '[B]Θέλετε να ενεργοποιήσετε όλα τα πρόσθετα τώρα;[/B]', nolabel='[B]Ακύρωση[/B]',yeslabel='[B][COLOR lime]Ενεργοποίηση[/COLOR][/B]')
    if yes_enable:
        from resources.lib.modules import addonsEnable
        addonsEnable.enable_addons()
        dialog.notification("[B][COLOR orange]TechNEWSology Build[/COLOR][/B]",'[COLOR white]Τα πρόσθετα [COLOR lime]ενεργοποιήθηκαν[COLOR white] με επιτυχία![/COLOR]' , icon_Build)
    else:
        return

def enable_next_start():
    yes_enable = dialog.yesno(addon_name, '[B]Θέλετε να ενεργοποιήσετε όλα τα πρόσθετα στην επόμενη εκκίνηση του Build;[/B]', nolabel='[B]Ακύρωση[/B]',yeslabel='[B][COLOR lime]Ενεργοποίηση[/COLOR][/B]')
    if yes_enable:
        setting_set('autoenable','true')
        dialog.notification("[COLOR white]Η [COLOR lime]Ενεργοποίηση[COLOR white] όλων των πρόσθετων[/COLOR]",'[COLOR white]έχει πλέον οριστεί για την επόμενη εκκίνηση του Build![/COLOR]' , icon_Build)
    else:
        return

def disable_downloader_startup():
    yes_enable = dialog.yesno(addon_name, 'Θέλετε να απενεργοποιήσετε τις αυτόματες ενημερώσεις του Downloader Startup του TechNEWSology Updater στην επόμενη εκκίνηση του Build;', nolabel='Ακύρωση',yeslabel='[COLOR orange]Απενεργοποίηση[/COLOR]')
    if yes_enable:
        setting_set('updaterversion','false')
        ok = dialog.ok(addon_name, 'Απενεργοποιήσατε τις αυτόματες ενημερώσεις του TechNEWSology Updater!')
        exit()
    else:
        return

def enable_downloader_startup():
    yes_enable = dialog.yesno(addon_name, 'Θέλετε να ενεργοποιήσετε τις αυτόματες ενημερώσεις του TechNEWSology Updater στην επόμενη εκκίνηση του Build;', nolabel='Ακύρωση',yeslabel='[COLOR lime]Ενεργοποίηση[/COLOR]')
    if yes_enable:
        setting_set('updaterversion','0')
        ok = dialog.ok(addon_name, 'Eνεργοποιήσατε τις αυτόματες ενημερώσεις του TechNEWSology Updater!')
        exit()
    else:
        return

def cancel_next_start():
    yes_cancel = dialog.yesno(addon_name, 'Θέλετε να ακυρώσετε την ενεργοποίηση όλων των πρόσθετων κατά την επόμενη εκκίνηση;', nolabel='Διατήρηση Ενεργ/σης',yeslabel='Ακύρωση Ενεργ/σης')
    if yes_cancel:
        setting_set('autoenable','false')
        ok = dialog.ok(addon_name, 'Η ενεργοποίηση των πρόσθετων ακυρώθηκε.')
    else:
        return

def cache_clear():
    cache.clear(withyes=False)

def search_clear():
    cache.delete(control.searchFile, withyes=False)
    control.refresh()
    control.idle()

def BuildMenu():
    req = Request(bzipfile, headers = headers)
    response = urlopen(req).read()
    try:
        builds = json.loads(response)['builds']
        for build in builds:
            name = (build.get('name', ''))
            url = (build.get('url', ''))
            icon = (build.get('icon', addon_icon))
            fanart = (build.get('fanart', addon_fanart))
            description = (build.get('description', 'No Description Available.'))
            if url.endswith('.zip'):
                addDir(name,url,11,icon,fanart,description,name2=name,isFolder=False)
            else:
                addDir('Μη έγκυρη διεύθυνση URL έκδοσης. Επικοινωνήστε με τον δημιουργό του build.','','','','','',isFolder=False)
    except:
        builds = ET.fromstring(response)
        for build in builds.findall('build'):
            try:
                name = build.get('name')
            except:
                name = ''
            try:
                url = build.find('url').text
            except:
                url = ''
            try:
                icon = build.find('icon').text
            except:
                icon = addon_icon
            try:
                fanart = build.find('fanart').text
            except:
                fanart = addon_fanart
            try:
                description = build.find('description').text
            except:
                description = 'No Description Available.'
            if url.endswith('.zip'):
                addDir(name,url,11,icon,fanart,description,name2=name,isFolder=False)
            else:
                addDir('Μη έγκυρη διεύθυνση URL έκδοσης. Επικοινωνήστε με τον δημιουργό του build.','','','','','',isFolder=False)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def freshStart():
    dialog.notification("[B][COLOR red]Διαγραφή[/COLOR][/B]",'[COLOR white]όλων των δεδομένων![/COLOR]' , icon_Build)
    if mode == 11:
        if not currSkin() in ['skin.estuary']:
            skinSwitch.swapSkins('skin.estuary')
            x = 0
            xbmc.sleep(1000)
            while not xbmc.getCondVisibility("Window.isVisible(yesnodialog)") and x < 150:
                x += 1
                xbmc.sleep(200)
                xbmc.executebuiltin('SendAction(Select)')
            if xbmc.getCondVisibility("Window.isVisible(yesnodialog)"):
                xbmc.executebuiltin('SendClick(11)')
            else: 
                log('Fresh Install: Skin Swap Timed Out!', xbmc.LOGINFO)
                return False
            xbmc.sleep(1000)
        if not currSkin() in ['skin.estuary']:
            log('Fresh Install: Skin Swap failed.', xbmc.LOGINFO)
            return
        
        if mode==10:
            save_menu()
            save_check()
            save_backup()
            
        dp.create(addon_name, 'Διαγραφή αρχείων και φακέλων...')
        xbmc.sleep(1000)
        dp.update(30, 'Διαγραφή αρχείων και φακέλων...')
        xbmc.sleep(1000)
        for root, dirs, files in os.walk(xbmcPath, topdown=True):
            dirs[:] = [d for d in dirs if d not in EXCLUDES]
            for name in files:
                if name not in EXCLUDES:
                    try:
                        os.remove(os.path.join(root, name))
                    except:
                        log('Unable to delete ' + name, xbmc.LOGINFO)
        dp.update(60, 'Διαγραφή αρχείων και φακέλων...')
        xbmc.sleep(1000)
        for root, dirs, files in os.walk(xbmcPath,topdown=True):
            dirs[:] = [d for d in dirs if d not in EXCLUDES]
            for name in dirs:
                if name not in ["Database","userdata","temp","addons","packages","addon_data"]:
                    try:
                        shutil.rmtree(os.path.join(root,name),ignore_errors=True, onerror=None)
                    except:
                        log('Unable to delete ' + name, xbmc.LOGINFO)
        dp.update(60, 'Διαγραφή αρχείων και φακέλων...')
        xbmc.sleep(1000)
        if not os.path.exists(packages):
            os.mkdir(packages)
        dp.update(100, 'Διαγραφή αρχείων και φακέλων...Ολοκληρώθηκε!')
        xbmc.sleep(2000)
        if mode == 10:
            dialog.ok(addon_name, 'Η διαγραφή ολοκληρώθηκε.[CR] Πατήστε εντάξει για να κλείσει το kodi.')
            os._exit(1)
    else:
        return

def reloadProfile(profile=None):
    if profile == None:
        xbmc.executebuiltin('LoadProfile(Master user)')
    else:
        xbmc.executebuiltin('LoadProfile(%s)' % profile)

def get_setting(key, id=xbmcaddon.Addon().getAddonInfo('id')):
    try:
        return xbmcaddon.Addon(id).getSetting(key)
    except:
        return False

def set_view():
    auto_view = get_setting('auto-view')

    if auto_view == 'true':
        view_type = get_setting('viewType')

        xbmc.executebuiltin("Container.SetViewMode({0})".format(view_type))

def _finish(handle):
    set_view()
    xbmcplugin.setContent(handle, 'files')
    xbmcplugin.endOfDirectory(handle)

def GetParams():
    param=[]
    paramstring=sys.argv[2]
    if len(paramstring)>=2:
        params=sys.argv[2]
        cleanedparams=params.replace('?','')
        if (params[len(params)-1]=='/'):
            params=params[0:len(params)-2]
        pairsofparams=cleanedparams.split('&')
        param={}
        for i in range(len(pairsofparams)):
            splitparams={}
            splitparams=pairsofparams[i].split('=')
            if (len(splitparams))==2:
                param[splitparams[0]]=splitparams[1]
    return param

params=GetParams()
url=None
name=None
name2=None
version=None
mode=None
iconimage=None
fanart=None
description=None
log(str(params),xbmc.LOGDEBUG)

try:
    url=unquote_plus(params["url"])
except:
    pass
try:
    name=unquote_plus(params["name"])
except:
    pass
try:
    iconimage=unquote_plus(params["iconimage"])
except:
    pass
try:
    mode=int(params["mode"])
except:
    pass
try:
    fanart=unquote_plus(params["fanart"])
except:
    pass
try:
    description=unquote_plus(params["description"])
except:
    pass
try:
    name2 =unquote_plus(params["name2"])
except:
    pass
try:
    version =unquote_plus(params["version"])
except:
    pass


xbmc.executebuiltin('Dialog.Close(busydialog)')

if mode == None:
    MainMenu()

elif mode == 1:
    from resources.lib.modules.apiYutube import ApiMenu
    ApiMenu()

elif mode == 2:
    xbmcaddon.Addon(addon_id).openSettings()

elif mode == 3:
    main_ApiMenu(name, name2, version, url, iconimage, fanart, description)

elif mode==4:
    maintenance.advanced_settings()

elif mode==5:
    subMenu_maintenance()

elif mode==6:
    maintenance.clear_packages()

elif mode==7:
    maintenance.clear_thumbnails()

elif mode==8:
    maintenance.advanced_settings()

elif mode==9:
    main_Skinshortcuts(name, name2, version, url, iconimage, fanart, description)

elif mode==10:
    freshStart()

elif mode==11:
    main_BuildMenu(name, name2, version, url, iconimage, fanart, description)

elif mode==12:
    BuildMenu()

elif mode==13:
     xbmc.executebuiltin('RunScript(special://home/addons/skin.TechNEWSology/16x9/TechNEWSology/Skin.py)')

elif mode==14:
     xbmc.executebuiltin('RunScript(special://home/addons/skin.TechNEWSology/16x9/TechNEWSology/Tools.py)')

elif mode==15:
    main_downloader(name, name2, version, url, iconimage, fanart, description)
    xbmc.sleep(2000)
    from resources.lib.modules import addonsEnable
    addonsEnable.enable_addons()

elif mode==16:
    from resources.lib.modules.installer_binary import Installer_Binary_Addons

elif mode == 17:
    main_backup_restore()

elif mode == 18:
    backup_build()

elif mode == 19:
    restore_menu()

elif mode == 20:
    restore_build(url)

elif mode == 21:
    get_backup_folder()

elif mode == 22:
    reset_backup_folder()

elif mode == 23:
    from resources.lib.modules.cache import clear_provider
    clear_provider()

#elif mode == 23:
#    play_video(name, url, icon, description)

elif mode == 24:
    from resources.lib.modules.derbid_authorize import derbid_authorize

elif mode == 25:
    enable_now()

elif mode == 26:
    enable_next_start()

elif mode == 27:
    cancel_next_start()

elif mode == 28:
    main_enable_addons()

elif mode == 29:
    disable_downloader_startup()

elif mode == 30:
    enable_downloader_startup()

elif mode == 31:
    from resources.lib.modules.speedtester.addon import run
    run()

elif mode == 32:
    from resources.lib.modules.quick_log import log_viewer
    log_viewer()

elif mode == 33:
    main_maintenance()

elif mode == 34:
    from resources.lib.modules import addonsEnable
    addonsEnable.enable_addons()

elif mode == 35:
    backup_gui()

elif mode == 36:
    restore_gui(url)

elif mode == 37:
    restore_gui_build()

elif mode == 38:
    restore_menu_gui()

elif mode == 39:
    main_misc_maintenance()

elif mode == 40:
    xbmc.executebuiltin("ReloadSkin()")

elif mode == 41:
    reloadProfile()

elif mode == 42:
    maintenance.convertSpecial(home)

elif mode == 43:
    maintenance.remove_addon_menu()

elif mode == 44:
    maintenance.remove_addon_data(addon='all')

elif mode == 45:
    maintenance.remove_addon_data(addon='uninstalled')

elif mode == 46:
    maintenance.forceUpdate()

elif mode == 47:
    remove_addon_data_menu()

elif mode == 48:
    maintenance.remove_addon_data(addon='empty')

elif mode == 49:
    addon_data_files = xbmcvfs.translatePath('special://userdata/addon_data/plugin.program.downloader19')
    maintenance.clean_house(addon_data_files, ignore=True)
    dialog.notification("[B][COLOR orange]TechNEWSology Build[/COLOR][/B]",'[COLOR red]Addon_Data reset![/COLOR]' , icon_Build)

elif mode == 50:
    system_fixes()

elif mode == 51:
    maintenance.remove_addon_data(name2)

elif mode == 52:
    maintenance.enable_addons()
    _finish(handle)

elif mode == 53:
    maintenance.enable_addons(all=True)

elif mode == 54:
    from resources.lib.modules import db
    db.toggle_addon(name2, url)
    xbmc.executebuiltin('Container.Refresh()')

elif mode == 55:
    maintenance.check_repos()
    xbmc.executebuiltin('Container.Refresh()')

elif mode == 56:
    maintenance.check_sources()
    xbmc.executebuiltin('Container.Refresh()')

elif mode==100:
    from resources.lib.GUIcontrol import notify
    d=notify.notify()
    d.doModal()
    del d

xbmcplugin.endOfDirectory(int(sys.argv[1]))