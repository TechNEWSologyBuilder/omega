# -*- coding: utf-8 -*-
import requests
from html import escape as escape_xml

def macportal(server_url, mac_address, cat_id=None):
    """
    Obtiene categorías o canales de un portal tipo Stalker (por MAC)
    y devuelve XML con estructura <items><item>...</item></items>
    """

    try:
        # ─── Cabeceras típicas MAG ───────────────────────────────
        headers = {
            'User-Agent': 'Mozilla/5.0 (QtEmbedded; U; Linux; C) '
                          'AppleWebKit/533.3 (KHTML, like Gecko) MAG250 stbapp ver: 4 rev: 250 Safari/533.3',
            'X-User-Agent': 'Model: MAG250; Link: Ethernet',
            'Referer': server_url + '/c/',
            'Cookie': f'mac={mac_address}',
        }

        # ─── Paso 1: Obtener token ───────────────────────────────
        handshake = requests.get(f"{server_url}/portal.php?type=stb&action=handshake&JsHttpRequest=1-xml", headers=headers, timeout=10)
        token = handshake.json()['js']['token']

        headers['Authorization'] = f"Bearer {token}"

        # ─── Paso 2: Validar perfil ──────────────────────────────
        profile = requests.get(f"{server_url}/portal.php?type=stb&action=get_profile&JsHttpRequest=1-xml", headers=headers, timeout=10)
        if 'js' not in profile.json():
            return _xml_error("MAC incorrecta o no autorizada")

        # ─── Si no se pasa cat_id: mostrar categorías ────────────
        if not cat_id:
            cats_url = f"{server_url}/portal.php?type=itv&action=get_genres&JsHttpRequest=1-xml"
            cats = requests.get(cats_url, headers=headers, timeout=10).json().get('js', [])
            if not cats:
                return _xml_error("No se encontraron categorías")

            items = ""
            for cat in cats:
                cid = cat.get('id')
                name = escape_xml(cat.get('title', 'Sin nombre'))

                items += f"""
<item>
  <title>[B][COLOR skyblue]{name}[/COLOR][/B]</title>
  <link>NA</link>
  <externallink>$doregex[cat_{cid}]</externallink>
  <thumbnail>https://bgaddon.pro/black/img/television.png</thumbnail>
  <regex>
    <name>cat_{cid}</name>
    <expres><![CDATA[#$pyFunction
def GetLSProData(page_data, Cookie_Jar, m):
    from resources.lib import macportal
    return macportal.macportal("{server_url}", "{mac_address}", "{cid}")
]]></expres>
    <page></page>
  </regex>
</item>
"""
            return f"<items>{items}</items>"

        # ─── Si hay cat_id: mostrar canales de esa categoría ─────
        chans_url = f"{server_url}/portal.php?type=itv&action=get_ordered_list&genre={cat_id}&JsHttpRequest=1-xml"
        chans_data = requests.get(chans_url, headers=headers, timeout=10).json().get('js', {}).get('data', [])
        if not chans_data:
            return _xml_error(f"No hay canales en la categoría {cat_id}")

        items = ""
        for ch in chans_data:
            name = escape_xml(ch.get('name', 'Sin nombre'))
            logo = ch.get('logo', '')
            cmd = ch.get('cmd', '')

            # Limpia "ffmpeg " o comandos anidados
            if cmd.startswith('ffmpeg '):
                cmd = cmd.replace('ffmpeg ', '').strip()

            items += f"""
<item>
  <title>{name}</title>
  <link>{escape_xml(cmd)}</link>
  <thumbnail>{server_url}/{logo}</thumbnail>
</item>
"""

        return f"<items>{items}</items>"

    except Exception as e:
        return _xml_error(str(e))


def _xml_error(msg):
    return f"<items><item><title>Error: {escape_xml(msg)}</title><link>NA</link></item></items>"
