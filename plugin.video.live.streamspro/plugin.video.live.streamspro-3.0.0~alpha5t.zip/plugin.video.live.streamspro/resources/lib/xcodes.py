# -*- coding: utf-8 -*-
"""
Librería Xcodes para regex $pyFunction en addons Kodi
Muestra categorías y canales desde servidores Xtream Codes API.

Uso en XML:
    return xcodes.xcodes("http://server:port/player_api.php?username=USER&password=PASS")

- Si NO recibe cat_id: devuelve las categorías (envueltas en <items>).
- Si recibe cat_id: devuelve los canales de esa categoría (envueltos en <items>).
"""

import re
import requests
import urllib.parse

# ============================================================
# Utilidades
# ============================================================

def parse_api_url(api_url: str):
    """Extrae base_url, username y password desde la URL del player_api."""
    match = re.match(r"(https?://[^/]+)/player_api\.php\?username=([^&]+)&password=([^&]+)", api_url)
    if not match:
        raise ValueError("URL API inválida. Debe tener formato player_api.php?username=USER&password=PASS")
    base_url, user, pwd = match.groups()
    return base_url, user, pwd

def get_json(url):
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                      "AppleWebKit/537.36 (KHTML, like Gecko) "
                      "Chrome/131.0.0.0 Safari/537.36",
        "Accept": "application/json, text/javascript, */*; q=0.01",
        "Connection": "keep-alive",
    }
    r = requests.get(url, headers=headers, timeout=10)
    r.raise_for_status()
    return r.json()

# ============================================================
# API Xtream Codes
# ============================================================

def get_categories(api_url):
    base, user, pwd = parse_api_url(api_url)
    url = f"{base}/player_api.php?username={user}&password={pwd}&action=get_live_categories"
    return get_json(url)

def get_channels(api_url, category_id):
    base, user, pwd = parse_api_url(api_url)
    url = f"{base}/player_api.php?username={user}&password={pwd}&action=get_live_streams&category_id={category_id}"
    channels = get_json(url)

    # Cabeceras necesarias para Kodi (URL encoded)
    from urllib.parse import quote_plus
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                      "AppleWebKit/537.36 (KHTML, like Gecko) "
                      "Chrome/131.0.0.0 Safari/537.36",
        "Referer": base + "/",
        "Connection": "keep-alive"
    }

    header_str = "&".join([f"{k}={quote_plus(v)}" for k, v in headers.items()])

    # Agrega la URL completa del stream con headers
    for ch in channels:
        stream_id = ch.get("stream_id", "")
        ch["stream_url"] = (
            f"{base}/live/{user}/{pwd}/{stream_id}.ts|{header_str}"
        )

    return channels


def buscar_canal(api_url, term):
    """
    Busca canales en todo el panel Xtream Codes por nombre (sin importar mayúsculas/minúsculas).
    Devuelve XML <items> con los resultados encontrados.
    """
    try:
        base, user, pwd = parse_api_url(api_url)
        url = f"{base}/player_api.php?username={user}&password={pwd}&action=get_live_streams"
        channels = get_json(url)

        term = term.lower().strip()
        encontrados = []

        # Cabeceras para reproducir correctamente en Kodi
        from urllib.parse import quote_plus
        headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                          "AppleWebKit/537.36 (KHTML, like Gecko) "
                          "Chrome/131.0.0.0 Safari/537.36",
            "Referer": base + "/",
            "Connection": "keep-alive"
        }
        header_str = "&".join([f"{k}={quote_plus(v)}" for k, v in headers.items()])

        # Buscar coincidencias en nombre del canal
        for ch in channels:
            nombre = ch.get("name", "")
            if term in nombre.lower():
                stream_id = ch.get("stream_id", "")
                logo = ch.get("stream_icon", "")
                stream_url = f"{base}/live/{user}/{pwd}/{stream_id}.ts|{header_str}"

                encontrados.append({
                    "name": nombre,
                    "logo": logo,
                    "url": stream_url
                })

        # Generar XML
        if not encontrados:
            return f"<items><item><title>No se encontraron canales  con '{escape_xml(term)}'</title><link>NA</link></item></items>"

        items = ""
        for c in encontrados:
            items += f"""
<item>
  <title>[COLORlightblue]{escape_xml(c['name'])}[/COLOR]</title>
  <link>{escape_xml(c['url'])}</link>
  <thumbnail>{escape_xml(c['logo'])}</thumbnail>
</item>
"""
        return f"<items>{items}</items>"

    except Exception as e:
        return f"<items><item><title>Error en búsqueda: {escape_xml(str(e))}</title><link>NA</link></item></items>"


# ============================================================
# Generadores XML (con <items> wrapper)
# ============================================================
def make_category_list(api_url):
    """Genera XML <items> con todas las categorías (cada una crea un regex dinámico)."""
    try:
        cats = get_categories(api_url)
        items = ""

        # =========================================
        # Botón de BUSCAR CANAL (solo una vez)
        # =========================================
        buscarcanal = f"""
<item>
  <title>[COLOR lightblue]BUSCAR CANAL[/COLOR]</title>
  <link>NA</link>
  <externallink>$doregex[buscar_TDN]</externallink>

  <regex>
    <name>buscar_TDN</name>
    <expres><![CDATA[#$pyFunction
def GetLSProData(page_data, Cookie_Jar, m):
    from resources.lib import xcodes
    return xcodes.buscar_canal("{api_url}", "$doregex[buscar]")
]]></expres>
    <page></page>
  </regex>

  <regex>
    <name>buscar</name>
    <expres><![CDATA[#$pyFunction
import xbmc
import xbmcgui
def GetLSProData(page_data, Cookie_Jar, m):
    dialog = xbmcgui.Dialog()
    term = dialog.input('Buscar canal:', type=xbmcgui.INPUT_ALPHANUM)
    return term.replace(" ", "+")
]]></expres>
    <page></page>
  </regex>

  <thumbnail>https://bgaddon.pro/black/img/icon.png</thumbnail>
  <fanart>https://bgaddon.pro/black/img/fanart.jpg</fanart>
  <info>Introduce el nombre del canal que deseas buscar.</info>
</item>
"""

        # =========================================
        # Lista de categorías
        # =========================================
        for c in cats:
            name = c.get("category_name", "Sin nombre")
            cid = c.get("category_id", "")
            link = f"$doregex[cat_{cid}]"

            items += f"""
<item>
  <title>{escape_xml(name)}</title>
  <link>NA</link>
  <externallink>{link}</externallink>
  <thumbnail>https://bgaddon.pro/black/img/television.png</thumbnail>
  <regex>
    <name>cat_{cid}</name>
    <expres><![CDATA[#$pyFunction
def GetLSProData(page_data, Cookie_Jar, m):
    from resources.lib import xcodes
    return xcodes.xcodes("{api_url}", cat_id="{cid}")
]]></expres>
    <page></page>
  </regex>
</item>
"""

        return f"<items>{buscarcanal}{items}</items>"

    except Exception as e:
        return f"<items><item><title>Error cargando categorías: {escape_xml(str(e))}</title><link>NA</link></item></items>"

def make_channel_list(api_url, cat_id):
    """Genera XML <items> con los canales de la categoría especificada."""
    try:
        chans = get_channels(api_url, cat_id)
        items = ""
        for c in chans:
            name = c.get("name", "Sin nombre")
            logo = c.get("stream_icon", "")
            stream_url = c.get("stream_url", "")
            items += f"""
<item>
  <title>[COLORlightblue]{escape_xml(name)}[/COLOR]</title>
  <link>{escape_xml(stream_url)}</link>
  <thumbnail>{escape_xml(logo)}</thumbnail>
</item>
"""
        return f"<items>{items}</items>"
    except Exception as e:
        return f"<items><item><title>Error cargando canales: {escape_xml(str(e))}</title><link>NA</link></item></items>"

# ============================================================
# Entrada principal para $pyFunction
# ============================================================

def xcodes(api_url, cat_id=None):
    """Punto de entrada para usar desde $pyFunction en XML."""
    if cat_id:
        return make_channel_list(api_url, cat_id)
    else:
        return make_category_list(api_url)

# ============================================================
# Helpers
# ============================================================

def escape_xml(text):
    """Escapa caracteres especiales para XML básico."""
    if text is None:
        return ""
    return (text.replace("&", "&amp;")
                .replace("<", "&lt;")
                .replace(">", "&gt;")
                .replace('"', "&quot;")
                .replace("'", "&apos;"))
