import xbmc, xbmcgui


def ExternalAddOns():
    funcs = (click_1, click_2, click_3, click_4, click_5, click_6, click_7, click_8, click_9, click_10, click_11)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]ExternalAddOns[/COLOR][/B]',
['[COLOR=orange]RO[/COLOR] (f4mTester) [COLOR=lime]play with-->inputstream.ffmpegdirect[/COLOR]',

 '[COLOR=orange]RO 1[/COLOR] (live.streamspro)',
 '[COLOR=orange]RO 2[/COLOR] (live.streamspro)',

 '[COLOR=blue]Love4vn[/COLOR] [IPTVSport] (playlistloader)',
 '[COLOR=blue]Love4vn[/COLOR] [Sport] (playlistloader)',
 '[COLOR=blue]Love4vn[/COLOR] [hubsport] (playlistloader)',
 '[COLOR=blue]Love4vn[/COLOR] [VTV_sort] (playlistloader)',

 'AlexDang 4K Sport (playlistloader)',

 '[COLOR=aqua]deportes[/COLOR] (live.streamspro)',


 '[COLOR=silver]TVApp[/COLOR] (playlistloader)',
 
 '[B][COLOR red]XC MAC M3U[/COLOR][/B]'])


    if call:
        if call < 1:
            return
        func = funcs[call-11]
        return func()
    else:
        func = funcs[call]
        return func()
    return 






def click_1():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.f4mTester/?mode=playlist&name=IPTV&url=https%3a%2f%2ftinyurl.com%2f59j985yy")')

def click_2():
    xbmc.executebuiltin('ActivateWindow(Videos,"plugin://plugin.video.live.streamspro/?url=https%3A%2F%2Ftinyurl.com%2F2b5v9p8b&mode=1&name=Bee+TV&fanart=C%3A%5CUsers%5Cuser%5CAppData%5CRoaming%5CKodi%5Caddons%5Cplugin.video.live.streamspro%5Cfanart.jpg")')

def click_3():
    xbmc.executebuiltin('ActivateWindow(Videos,"plugin://plugin.video.live.streamspro/?url=https%3A%2F%2Ftinyurl.com%2Fmpa7p2sp&mode=1&name=Bee+TV2&fanart=C%3A%5CUsers%5Cuser%5CAppData%5CRoaming%5CKodi%5Caddons%5Cplugin.video.live.streamspro%5Cfanart.jpg")')

def click_4():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.playlistloader/?cache=0&epg&iconimage=C%3a%5cPortableApps%5ckodi%5ckodi%20World%2021%5cKodi%5cportable_data%5caddons%5cplugin.video.playlistloader%5cresources%5cimages%5cdefault-list-image.png&logos&mode=2&name=%5bIPTVSport%5d&url=https%3a%2f%2fraw.githubusercontent.com%2fLove4vn%2flove4vn%2fmain%2fIPTVSport.m3u&uuid=4d1177c3-9304-421d-92e9-88d6b87d75a7")')

def click_5():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.playlistloader/?cache=0&epg&iconimage=C%3a%5cPortableApps%5ckodi%5ckodi%20World%2021%5cKodi%5cportable_data%5caddons%5cplugin.video.playlistloader%5cresources%5cimages%5cdefault-list-image.png&logos&mode=2&name=%5bSport%5d&url=https%3a%2f%2fraw.githubusercontent.com%2fLove4vn%2flove4vn%2fmain%2fSport.m3u&uuid=ac4c5ee9-b0ac-4db3-8815-5201f43cb295")')

def click_6():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.playlistloader/?cache=0&epg&iconimage=C%3a%5cPortableApps%5ckodi%5ckodi%20World%2021%5cKodi%5cportable_data%5caddons%5cplugin.video.playlistloader%5cresources%5cimages%5cdefault-list-image.png&logos&mode=2&name=%5bhubsport%5d&url=https%3a%2f%2fraw.githubusercontent.com%2fLove4vn%2flove4vn%2fmain%2fhubsport.m3u&uuid=36c47370-f55a-4db8-b633-dfdeff0ca03c")')


def click_7():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.playlistloader/?cache=0&epg&iconimage=C%3a%5cPortableApps%5ckodi%5ckodi%20World%2021%5cKodi%5cportable_data%5caddons%5cplugin.video.playlistloader%5cresources%5cimages%5cdefault-list-image.png&logos&mode=2&name=%5bVTV_sort%5d&url=https%3a%2f%2fraw.githubusercontent.com%2fLove4vn%2flove4vn%2fmain%2fVTV_sort.m3u&uuid=8288589e-fa37-40ed-82f2-08bc2eccbc39")')

def click_8():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.playlistloader/?cache=0&epg&iconimage=C%3a%5cPortableApps%5ckodi%5ckodi%20World%2021%5cKodi%5cportable_data%5caddons%5cplugin.video.playlistloader%5cresources%5cimages%5cdefault-list-image.png&logos&mode=2&name=%5b1%5d&url=https%3a%2f%2fraw.githubusercontent.com%2fkgasaz%2f4kuhd%2fmaster%2fsports-channels-4k.m3u&uuid=885b5b8d-e4d1-4bb1-8713-63d6254a78c2")')

def click_9():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.live.streamspro/?fanart=C%3a%5cPortableApps%5ckodi%5cKODI%20TEST%5cKodi%5cportable_data%5caddons%5cplugin.video.live.streamspro%5cfanart.jpg&mode=1&name=0-deportes&url=https%3a%2f%2fbgaddon.online%2fblack%2f0-deportes.php")')

def click_10():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.playlistloader/?cache=0&epg&iconimage=C%3a%5cPortableApps%5ckodi%5ckodi%20World%2021%5cKodi%5cportable_data%5caddons%5cplugin.video.playlistloader%5cresources%5cimages%5cdefault-list-image.png&logos&mode=2&name=%5bTVApp%5d&url=https%3a%2f%2ftinyurl.com%2fbestonkodi-tv&uuid=47916612-8d37-4215-9e1e-255ffee536d6")')


def click_11():
    xbmc.executebuiltin('Dialog.Close(all,true)')



ExternalAddOns()
