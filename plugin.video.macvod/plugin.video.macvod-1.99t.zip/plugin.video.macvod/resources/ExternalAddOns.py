import xbmc, xbmcgui


def ExternalAddOns():
    funcs = (click_1, click_2, click_3, click_4)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]ExternalAddOns[/COLOR][/B]',
['[COLOR=orange]PT[/COLOR] (f4mTester)',
 '[COLOR=orange]RO 1[/COLOR] (live.streamspro)',
 '[COLOR=orange]RO 2[/COLOR] (live.streamspro)',
 
 '[B]                                                                                             [COLOR grey]Back[/COLOR][/B]'])


    if call:
        if call < 1:
            return
        func = funcs[call-4]
        return func()
    else:
        func = funcs[call]
        return func()
    return 






def click_1():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.f4mTester/?mode=playlist&name=IPTV&url=https%3a%2f%2fraw.githubusercontent.com%2farrownegra%2faddon%2fmain%2faddonk-pt%2fpvr.xml")')
    #xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.myselect/folders/py/sporthdme.py")')

def click_2():
    xbmc.executebuiltin('ActivateWindow(Videos,"plugin://plugin.video.live.streamspro/?url=http%3A%2F%2Ftinyurl.com%2F56fnkcs3&mode=1&name=Bee+TV&fanart=C%3A%5CUsers%5Cuser%5CAppData%5CRoaming%5CKodi%5Caddons%5Cplugin.video.live.streamspro%5Cfanart.jpg",return)')

def click_3():
    xbmc.executebuiltin('ActivateWindow(Videos,"plugin://plugin.video.live.streamspro/?url=http%3A%2F%2Ftinyurl.com%2F2kv2mvhc&mode=1&name=Bee+TV2&fanart=C%3A%5CUsers%5Cuser%5CAppData%5CRoaming%5CKodi%5Caddons%5Cplugin.video.live.streamspro%5Cfanart.jpg",return)')

def click_4():
    xbmc.executebuiltin('Action(Back)')
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.macvod")')


ExternalAddOns()
