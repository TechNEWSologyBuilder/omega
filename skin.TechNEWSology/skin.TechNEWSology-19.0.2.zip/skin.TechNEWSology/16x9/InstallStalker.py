import os, xbmc, xbmcgui

def install_stalker():
        choice = xbmcgui.Dialog().yesno('[COLOR orange]TechNEWSology[/COLOR]', '[COLOR white]Αν δεν λειτουργούν οι διακομιστές μετά την εγκατάσταση του PVR Stalker, τότε θα χρειαστεί να περάσετε δικές σας πύλες μέσα στις Ρυθμίσεις Stalker με την βοήθεια Ιστότοπων του διαδικτύου ή της επιλογής Ιστότοποι Stalker Portal.[/COLOR]',
                                        nolabel='[COLOR orange]Άκυρο[/COLOR]',yeslabel='[COLOR lime]Εγκατάσταση[/COLOR]')

        if choice == 1: xbmc.executebuiltin('InstallAddon(pvr.stalker)')

install_stalker()
