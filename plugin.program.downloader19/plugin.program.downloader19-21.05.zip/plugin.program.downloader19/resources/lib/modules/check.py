""""""""""""""""""""""""""""""""""""""""""
"""  Believe in God - Ηelp as you can  """
""""""""""""""""""""""""""""""""""""""""""
import xbmc
from updatervar import *
from resources.lib.GUIcontrol import notify
from resources.lib.GUIcontrol.notify import get_notifyversion
from resources.lib.GUIcontrol.txt_updater import get_check, get_py, get_addonsrepos, get_updaterversion, get_xmlskin, get_players, get_set_setting
from resources.lib.GUIcontrol.txt_updater import get_var, get_addons_list_installation, get_delete_files, get_zip1, get_zip2, get_zip3, get_zip4
from resources.lib.GUIcontrol.txt_updater import get_zip5, get_zip6, get_zip7, get_zip8, get_zip9, get_zip10, get_zip11, get_zip12
from resources.lib.modules import addonsEnable

check_version        = get_check()
notify_version       = get_notifyversion()
addons_repos_version = get_addonsrepos()
updater_version      = get_updaterversion()
xmlskin_version      = get_xmlskin()
players_version      = get_players()
set_setting_version  = get_set_setting()
delete_files_version = get_delete_files()
var_version          = get_var()
py_version           = get_py()
zip1_version         = get_zip1()
zip2_version         = get_zip2()
zip3_version         = get_zip3()
zip4_version         = get_zip4()
zip5_version         = get_zip5()
zip6_version         = get_zip6()
zip7_version         = get_zip7()
zip8_version         = get_zip8()
zip9_version         = get_zip9()
zip10_version        = get_zip10()
zip11_version        = get_zip11()
zip12_version        = get_zip12()
addons_list_installation_version = get_addons_list_installation()


def Update():
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"general.addonupdates","value":0}}')
    xbmc.sleep(1000)
    xbmc.executebuiltin('UpdateAddonRepos')

def autoenable():
    if setting('autoenable') == 'true':
        addonsEnable.enable_addons_updater()
        setting_set('autoenable','false')
        dialog.notification(Dialog_enable_on, Dialog_enable, icon_Build, sound=False)
        xbmc.sleep(5000)


def addonupdates_Disable():
    BG.create('[B]Έναρξη ενημέρωσης[/B]', 'Ενημέρωση σε εξέλιξη ...')
    BG.update(2, '[B]Έναρξη ενημέρωσης[/B]', 'Έλεγχος για νέες αλλαγές στο Build ...')
    xbmc.sleep(1000)
    BG.update(5, '[B]Έναρξη ενημέρωσης[/B]', 'Έλεγχος για νέες αλλαγές στο Build ...')
    xbmc.sleep(2000)

def var():
    if var_version > int(setting('varversion')):
        BG.update(10, '[B]Έναρξη ενημέρωσης[/B]', 'Περιμένετε χωρίς να πατήσετε κάτι ...')
        xbmc.executebuiltin(Var_startup)
        xbmc.sleep(1000)
        setting_set('varversion', str(var_version))

def players():
    if players_version > int(setting('playersversion')):
        xbmc.executebuiltin(Players_startup)
        BG.update(15, '[B]Έναρξη ενημέρωσης[/B]', 'Διόρθωση/Εισαγωγή [COLOR lime]Players[/COLOR] TheMovieDb Helper ...')
        xbmc.sleep(5000)
        setting_set('playersversion', str(players_version))

def skin_py():
    if py_version > int(setting('pyversion')):
        xbmc.executebuiltin(Py_startup)
        BG.update(20, '[B]Έναρξη ενημέρωσης[/B]', 'Διόρθωση/Εισαγωγή [COLOR lime]στοιχείων [/COLOR]στο Build ...')
        xbmc.sleep(5000)
        setting_set('pyversion', str(py_version))

def delete():
    if delete_files_version > int(setting('deleteversion')):
        xbmc.executebuiltin(Delete_startup)
        BG.update(22, '[B]Αναμονή για ολοκλήρωση ενημέρωσης[/B]', 'Ενημέρωση αρχείου διαγραφής ...')
        xbmc.sleep(15000)
        BG.update(25, '[B]Αναμονή για ολοκλήρωση ενημέρωσης[/B]', 'Αναζήτηση αρχείων προς διαγραφή ...')
        xbmc.sleep(10000)
        xbmc.executebuiltin(del_startup)
        xbmc.sleep(2000)
        setting_set('deleteversion', str(delete_files_version))
        BG.update(28, '[B]Αναμονή για ολοκλήρωση ενημέρωσης[/B]', 'Ενημέρωση σε εξέλιξη ...')
        xbmc.sleep(5000)

##########################ZIP FILES#####################

def zip1():
    if zip1_version > int(setting('zip1version')):
        BG.update(30, Dialog_U3, Dialog_U2)
        xbmc.executebuiltin(Zip1_startup)
        xbmc.sleep(1000)
        setting_set('zip1version', str(zip1_version))

def zip2():
    if zip2_version > int(setting('zip2version')):
        BG.update(32, Dialog_U3, Dialog_U2)
        xbmc.executebuiltin(Zip2_startup)
        xbmc.sleep(1000)
        setting_set('zip2version', str(zip2_version))

def zip3():
    if zip3_version > int(setting('zip3version')):
        BG.update(34, Dialog_U3, Dialog_U2)
        xbmc.executebuiltin(Zip3_startup)
        xbmc.sleep(1000)
        setting_set('zip3version', str(zip3_version))

def zip4():
    if zip4_version > int(setting('zip4version')):
        BG.update(36, Dialog_U3, Dialog_U2)
        xbmc.executebuiltin(Zip4_startup)
        xbmc.sleep(1000)
        setting_set('zip4version', str(zip4_version))

def zip5():
    if zip5_version > int(setting('zip5version')):
        BG.update(39, Dialog_U3, Dialog_U2)
        xbmc.executebuiltin(Zip5_startup)
        xbmc.sleep(1000)
        setting_set('zip5version', str(zip5_version))

def zip6():
    if zip6_version > int(setting('zip6version')):
        BG.update(42, Dialog_U3, Dialog_U2)
        xbmc.executebuiltin(Zip6_startup)
        xbmc.sleep(1000)
        setting_set('zip6version', str(zip6_version))

def zip7():
    if zip7_version > int(setting('zip7version')):
        BG.update(44, Dialog_U3, Dialog_U2)
        xbmc.executebuiltin(Zip7_startup)
        xbmc.sleep(1000)
        setting_set('zip7version', str(zip7_version))

def zip8():
    if zip8_version > int(setting('zip8version')):
        BG.update(47, Dialog_U3, Dialog_U2)
        xbmc.executebuiltin(Zip8_startup)
        xbmc.sleep(1000)
        setting_set('zip8version', str(zip8_version))

def zip9():
    if zip9_version > int(setting('zip9version')):
        BG.update(49, Dialog_U3, Dialog_U2)
        xbmc.executebuiltin(Zip9_startup)
        xbmc.sleep(1000)
        setting_set('zip9version', str(zip9_version))

def zip10():
    if zip10_version > int(setting('zip10version')):
        BG.update(50, Dialog_U3, Dialog_U2)
        xbmc.executebuiltin(Zip10_startup)
        xbmc.sleep(1000)
        setting_set('zip10version', str(zip10_version))

def zip11():
    if zip11_version > int(setting('zip11version')):
        BG.update(52, Dialog_U3, Dialog_U2)
        xbmc.executebuiltin(Zip11_startup)
        xbmc.sleep(1000)
        setting_set('zip11version', str(zip11_version))

def zip12():
    if zip12_version > int(setting('zip12version')):
        BG.update(54, Dialog_U3, Dialog_U2)
        xbmc.executebuiltin(Zip12_startup)
        xbmc.sleep(1000)
        setting_set('zip12version', str(zip12_version))

#######################################################

def installation():
    if addons_list_installation_version > int(setting('installationversion')):
        BG.update(55, '[B]Αναμονή για ολοκλήρωση ενημέρωσης[/B]', 'Έλεγχος εγκατάστασης νέων πρόσθετων ...')
        xbmc.executebuiltin(Installation_startup)
        xbmc.sleep(20000)
        xbmc.executebuiltin(install_startup)
        xbmc.sleep(1000)
        BG.update(57, '[B]Αναμονή για ολοκλήρωση ενημέρωσης[/B]', 'Περιμένετε χωρίς να πατήσετε κάτι ...')
        xbmc.sleep(5000)
        setting_set('installationversion', str(addons_list_installation_version))
        BG.update(60, '[B]Αναμονή για ολοκλήρωση ενημέρωσης[/B]', 'Περιμένετε χωρίς να πατήσετε κάτι ...')
        xbmc.sleep(15000)
        BG.update(62, '[B]Αναμονή για ολοκλήρωση ενημέρωσης[/B]', 'Περιμένετε χωρίς να πατήσετε κάτι ...')
        xbmc.sleep(20000)

def updater():
    if updater_version > int(setting('updaterversion')):
        BG.update(63, '[B]Αναμονή για ολοκλήρωση ενημέρωσης[/B]', 'Περιμένετε χωρίς να πατήσετε κάτι ...')
        xbmc.executebuiltin(Updater_startup)
        xbmc.sleep(25000)
        xbmc.executebuiltin(downloader_startup)
        setting_set('updaterversion', str(updater_version))
    else:
        if os.path.exists (downloader_startup_tk):
            xbmc.sleep(15000)
            xbmc.executebuiltin(downloader_startup)
            setting_set('updaterversion', str(updater_version))

def setsetting():
    if set_setting_version > int(setting('setsettingversion')):
        BG.update(65, '[B]Αναμονή για ολοκλήρωση ενημέρωσης[/B]', 'Περιμένετε χωρίς να πατήσετε κάτι ...')
        xbmc.executebuiltin(SetSetting_startup)
        xbmc.sleep(16000)
        xbmc.executebuiltin(set_setting_startup)
        BG.update(68, '[B]Αναμονή για ολοκλήρωση ενημέρωσης[/B]', 'Καταχώριση έκδοσης στις ρυθμίσεις ...')
        xbmc.sleep(2000)
        setting_set('setsettingversion', str(set_setting_version))

def database():
    if addons_repos_version > int(setting('addonsreposversion')):
        BG.update(72, '[B]Αναμονή για ολοκλήρωση ενημέρωσης[/B]', 'Νέες καταχωρίσεις στην Database ...')
        xbmc.executebuiltin(AddonsRepos_startup)
        xbmc.sleep(20000)
        xbmc.executebuiltin(database_startup)
        BG.update(78, '[B]Αναμονή για ολοκλήρωση ενημέρωσης[/B]', 'Καταχώριση έκδοσης στις ρυθμίσεις ...')
        xbmc.sleep(5000)
        addonsEnable.enable_addons_updater()
        xbmc.sleep(5000)
        setting_set('addonsreposversion', str(addons_repos_version))
        xbmc.sleep(5000)

def xmlskin():
    if xmlskin_version > int(setting('xmlskinversion')):
        BG.update(80, '[B]Αναμονή για ολοκλήρωση ενημέρωσης[/B]', 'Προσθήκες-Διορθώσεις στο κέλυφος του Build ...')
        xbmc.executebuiltin(XmlSkin_startup)
        xbmc.sleep(7000)
        BG.update(82, '[B]Αναμονή για ολοκλήρωση ενημέρωσης[/B]', 'Προσθήκες-Διορθώσεις στο κέλυφος του Build ...')
        xbmc.sleep(7000)
        BG.update(84, '[B]Αναμονή για ολοκλήρωση ενημέρωσης[/B]', 'Αναμονή λίγο ακόμη ...')
        xbmc.sleep(5000)
        BG.update(87, '[B]Αναμονή για ολοκλήρωση ενημέρωσης[/B]', 'Αναμονή λίγο ακόμη ...')
        setting_set('xmlskinversion', str(xmlskin_version))
        xbmc.sleep(5000)
        setting_set('checkversion', str(check_version))
    #    xbmc.executebuiltin("ReloadSkin()")
        BG.update(88, '[B]Αναμονή για ολοκλήρωση ενημέρωσης[/B]', 'Θα πραγματοποιηθεί [COLOR lime]επανεκκίνηση[/COLOR] κελύφους ...')
    #    xbmc.sleep(10000)
        xbmc.sleep(15000)
        xbmc.executebuiltin("ReloadSkin()")
        xbmc.sleep(5000)
        BG.update(89, '[B]Αναμονή για ολοκλήρωση ενημέρωσης[/B]', 'Αναμονή λίγο ακόμη ...')
        xbmc.sleep(5000)
        BG.update(90, '[B]Αναμονή για ολοκλήρωση ενημέρωσης[/B]', 'Αναμονή λίγο ακόμη ...')
        xbmc.sleep(5000)
        BG.close()
        BG.create('[B]Αναμονή για ολοκλήρωση ενημέρωσης[/B]', 'Ενημέρωση σε εξέλιξη ...')
        BG.update(92, '[B]Αναμονή για ολοκλήρωση ενημέρωσης[/B]', 'Ενημέρωση σε εξέλιξη ...')
        xbmc.sleep(5000)
        BG.update(94, '[B]Αναμονή για ολοκλήρωση ενημέρωσης[/B]', 'Αναμονή λίγο ακόμη ...')
        xbmc.sleep(5000)
        BG.update(95, '[B]Αναμονή για ολοκλήρωση ενημέρωσης[/B]', 'Αναμονή λίγο ακόμη ...')
        xbmc.sleep(2000)
        BG.update(96, '[B]Αναμονή για ολοκλήρωση ενημέρωσης[/B]', 'Ενεργοποίηση των πρόσθετων ...')
        xbmc.sleep(5000)
    #    BG.close()

def UpdateAddonRepos():
        xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"general.addonupdates","value":0}}')
    #    BG.create(Dialog_U1, 'Ενημέρωση σε εξέλιξη ...')
        BG.update(98, '[B]Αναμονή για ολοκλήρωση ενημέρωσης[/B]', 'Έλεγχος πρόσθετων για αναβαθμίσεις ...')
        xbmc.sleep(2000)
        BG.update(99, '[B]Αναμονή για ολοκλήρωση ενημέρωσης[/B]', 'Είναι σχεδόν όλα έτοιμα!')
        xbmc.sleep(2000)
        xbmc.executebuiltin('UpdateAddonRepos')
        BG.update(100, '[B]Αναμονή για ολοκλήρωση ενημέρωσης[/B]', '[B][COLOR lime]Επιτυχής ενημέρωση![/COLOR][/B]')
        xbmc.sleep(2000)
        BG.update(100, '[B][COLOR lime]Ολοκληρώθηκε με επιτυχία[/COLOR][/B]', '[B]Όλα είναι έτοιμα![/B]')
        xbmc.sleep(5000)
        BG.close()

def notifyT():
    if not setting('firstrunNotify')=='false':
        if notify_version > int(setting('notifyversion')):
            xbmc.sleep(12000)
            setting_set('notifyversion', str(notify_version))
            d=notify.notify()
            d.doModal()
            del d
