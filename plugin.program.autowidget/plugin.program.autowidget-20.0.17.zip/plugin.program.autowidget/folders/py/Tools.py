﻿import xbmc, xbmcgui


def t_menu():
    funcs = (click1, click2, click3, click4, click5, click6, click7, click8, click9, click10, click11, click12, click13, click14, click15, click16, click17, click18, click19, click20, click21, click22, click23, click24, click25, click26)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]                                            ~ Εργαλεία ~[/COLOR][/B]',
['[B][COLOR=white]                           Ενεργοποίηση όλων των πρόσθετων ...[/COLOR][/B]',
 '[B][COLOR=white]                               Έλεγχος Αναβάθμισης Πρόσθετων ...[/COLOR][/B]',
 '[B][COLOR=white]                   Αν δεν εμφανίζονται τα Widgets ή τα Εικονίδια ...[/COLOR][/B]',
 '[B][COLOR=white]                                 Καλύτερο streaming στο Βίντεο ...[/COLOR][/B]',
 '[B][COLOR=white]                                            Ρυθμίσεις [COLOR lime]ResolveURL[/COLOR][/B]',
 '[B][COLOR=white]                                         Επιλογή Api Key [COLOR red]YouTube[/COLOR][/B]',
 '[B][COLOR=white]                                      Εγκατάσταση Binary Addons[/COLOR][/B]',
 '[B][COLOR=white]                                            Διαγραφή PVR Stalker[/COLOR][/B]',
 '[B][COLOR=white]                                    Επαναφορά Ενημέρωσης Μενού[/COLOR][/B]',
# '[B][COLOR=white]                                   Έληξε η Συνδρομή μας [COLOR lime]AllDebrid ...[/COLOR][/B]',
# '[B][COLOR=white]                             Έληξε η Συνδρομή μας [COLOR lime]PremiumizeMe ...[/COLOR][/B]',
 '[B][COLOR=white]                                            Εξουσιοδότηση [COLOR lime]Trakt ...[/COLOR][/B]',
 '[B][COLOR=white]                          Έγκριση του λογαριασμού μου [COLOR lime]RealDebrid ...[/COLOR][/B]',
 '[B][COLOR=white]                            Έγκριση του λογαριασμού μου [COLOR lime]AllDebrid ...[/COLOR][/B]',
 '[B][COLOR=white]                       Έγκριση του λογαριασμού μου [COLOR lime]PremiumizeMe ...[/COLOR][/B]',
 '[B][COLOR=white]                                         Εργαλεία G.K.N.Wizard[/COLOR][/B]',
 '[B][COLOR=white]                                              Διαγραφή Indigo...[/COLOR][/B]',
 '[B][COLOR=lime]                            Καθαρή Εγκατάσταση Build [B][COLOR orange]*ΧΩΡΙΣ ΚΩΔΙΚΟ*[/COLOR][/B]',
 '[B][COLOR=white]                                                  G.K.N.Wizard[/COLOR][/B]',
 '[B][COLOR=white]                                          Αφαίρεση πρόσθετων[/COLOR][/B]',
 '[B][COLOR=white]                                    Καθαρισμός παρόχων-Cache[/COLOR][/B]',
 '[B][COLOR=white]                                                    Save Data[/COLOR][/B]',
 '[B][COLOR=white]                                                   Reload Skin[/COLOR][/B]',
 '[B][COLOR=white]                                         Enable/Disable Addons[/COLOR][/B]',
 '[B][COLOR=white]                                                    Speed Test[/COLOR][/B]',
 '[B][COLOR=white]                                              Εργαλεία AliveGR[/COLOR][/B]',
 '[B][COLOR=orange]   Απενεργοποίηση [COLOR=white]αυτόματων ενημερώσεων του Downloader Startup[/COLOR][/B]',
 '[B][COLOR=lime]     Ενεργοποίηση [COLOR=white]αυτόματων ενημερώσεων του Downloader Startup[/COLOR][/B]'])

    if call:
        if call < 0:
            return
        func = funcs[call-26]
        return func()
    else:
        func = funcs[call]
        return func()
    return 


def click1():
    xbmc.executebuiltin('RunPlugin(plugin://plugin.program.downloader19/?mode=25,return)')

def click2():
    xbmc.executebuiltin('RunPlugin(plugin://plugin.program.G.K.N.Wizard/?mode=kodi17fix)')

def click3():
    xbmc.executebuiltin('RunScript(special://home/addons/plugin.program.autowidget/folders/py/FixWidget.py)')

def click4():
    xbmc.executebuiltin('RunScript(special://home/addons/plugin.program.autowidget/folders/py/AdvancedSettings.py)')

def click5():
    import resolveurl
    resolveurl.display_settings()

def click6():
    xbmc.executebuiltin('ActivateWindow(10001,plugin://plugin.program.downloader19/?mode=1,return)')

def click7():
    xbmc.executebuiltin('RunScript(special://home/addons/plugin.program.autowidget/folders/py/installer_binary.py)')

def click8():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.autowidget/folders/py/StalkerDelete.py")')

def click9():
    xbmc.executebuiltin('RunPlugin(plugin://plugin.program.downloader19/?url=https%3A%2F%2Fgknwizard.eu%2Frepo%2FBuilds%2FTechNEWsology%2FUpdaterMatrix%2FBackgrounds_With_Widgets.zip&mode=9)')
    xbmcgui.Dialog().notification('[B][COLOR orange]TechNEWSology[/COLOR][/B]', '[B][COLOR white]Αναμονή... προς ολοκλήρωση διαδικασίας![/COLOR][/B]', '', sound=False)
    xbmc.sleep(5000)
    xbmc.executebuiltin('RunPlugin(plugin://plugin.program.downloader19/?url=https%3A%2F%2Fgknwizard.eu%2Frepo%2FBuilds%2FTechNEWsology%2FUpdaterMatrix%2FXmlSkin_startup.zip&mode=9)')
    xbmc.sleep(10000)
    xbmc.executebuiltin("LoadProfile(Master user)")

#def click7():
#    xbmc.executebuiltin('RunScript(special://home/addons/plugin.program.super.favourites/folders/PY/ResolverOffAllDebrid.py)')

#def click8():
#    xbmc.executebuiltin('RunScript(special://home/addons/plugin.program.super.favourites/folders/PY/ResolverOffPremiumizeMe.py)')

def click10():
    xbmc.executebuiltin('RunPlugin(plugin://plugin.video.scrubsv2/?action=auth_trakt)')

def click11():
    xbmc.executebuiltin('RunPlugin(plugin://script.module.resolveurl/?mode=auth_rd)')

def click12():
    xbmc.executebuiltin('RunPlugin(plugin://script.module.resolveurl/?mode=auth_ad)')

def click13():
    xbmc.executebuiltin('RunPlugin(plugin://script.module.resolveurl/?mode=auth_pm)')

def click14():
    xbmc.executebuiltin('ActivateWindow(10001,plugin://plugin.program.G.K.N.Wizard/?mode=maint,return)')

def click15():
    xbmc.executebuiltin('RunScript(special://home/addons/plugin.program.autowidget/folders/py/indigoDel.py)')

def click16():
    xbmc.executebuiltin('RunPlugin(plugin://plugin.program.downloader19/?url=https%3A%2F%2Fgknwizard.eu%2Frepo%2FBuilds%2FTechNEWsology%2FBuilds%2FTechNEWSology_19_20_21.zip&mode=11&name=TechNEWSolgy+Build)')

def click17():
    xbmc.executebuiltin('ActivateWindow(10001,plugin://plugin.program.G.K.N.Wizard)')

def click18():
    xbmc.executebuiltin('RunPlugin(plugin://plugin.program.G.K.N.Wizard/?mode=removeaddons,return)')

def click19():
    xbmc.executebuiltin('RunPlugin(plugin://plugin.program.G.K.N.Wizard/?mode=clearcache)')

def click20():
    xbmc.executebuiltin('ActivateWindow(10001,plugin://plugin.program.G.K.N.Wizard/?mode=savedata,return)')

def click21():
    xbmc.executebuiltin('RunPlugin(plugin://plugin.program.G.K.N.Wizard/?mode=forceskin)')

def click22():
    xbmc.executebuiltin('ActivateWindow(10001,plugin://plugin.program.G.K.N.Wizard/?mode=enableaddons,return)')

def click23():
    xbmc.executebuiltin('ActivateWindow(10001,plugin://plugin.program.downloader19/?url=&mode=31,return)')

def click24():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.AliveGR/?action=settings,return)')

def click25():
    xbmc.executebuiltin('RunPlugin(plugin://plugin.program.downloader19/?mode=29,return)')

def click26():
    xbmc.executebuiltin('RunPlugin(plugin://plugin.program.downloader19/?mode=30,return)')



t_menu()
