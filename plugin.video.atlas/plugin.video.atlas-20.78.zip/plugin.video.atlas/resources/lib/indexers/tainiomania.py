# -*- coding: utf-8 -*-

import xbmcgui
import xbmcaddon
import xbmc
import re
import requests
import six
from six.moves.urllib_parse import quote_plus
from resources.lib.modules import client
from resources.lib.modules import control
from resources.lib.modules import views
from resources.lib.modules import dom_parser as dom
from resources.lib.modules.control import addDir
ADDON       = xbmcaddon.Addon()
ADDON_DATA  = ADDON.getAddonInfo('profile')
ADDON_PATH  = ADDON.getAddonInfo('path')
DESCRIPTION = ADDON.getAddonInfo('description')
FANART      = ADDON.getAddonInfo('fanart')
ICON        = ADDON.getAddonInfo('icon')
ID          = ADDON.getAddonInfo('id')
NAME        = ADDON.getAddonInfo('name')
VERSION     = ADDON.getAddonInfo('version')
Lang        = control.lang
Dialog      = xbmcgui.Dialog()
vers = VERSION
ART = ADDON_PATH + "/resources/icons/"
TAINIOMANIA = 'https://tainio-mania.online/'



def Tainiomania_menu(): #84
    addDir('[B][COLOR coral]2024[/COLOR][/B]', 'https://tainio-mania.online/load/tainies-2024-online/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]2023[/COLOR][/B]', 'https://tainio-mania.online/load/tainies-2023-online/', 89, ART + 'tainiomania.png', FANART, '')
#    addDir('[B][COLOR coral]2022[/COLOR][/B]', 'https://tainio-mania.online/load/tainies-2022/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]Έτος[/COLOR][/B]', '', 86, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]Κατηγορίες[/COLOR][/B]', '', 87, ART + 'tainiomania.png', FANART, '')

def menu_genre(): #87
    addDir('[B][COLOR coral]Ελλ-ταινίες[/COLOR][/B]', TAINIOMANIA + 'load/ellhnik_tain_e/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]Κωμωδίες[/COLOR][/B]', TAINIOMANIA + 'load/komodia/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]Δράμα[/COLOR][/B]', TAINIOMANIA + 'load/drama/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]Αισθηματικές[/COLOR][/B]', TAINIOMANIA + 'load/aisthhmatik/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]Οικογενειακές[/COLOR][/B]', 'load/oikogeneiak/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]Χριστουγιεννιάτικες[/COLOR][/B]', TAINIOMANIA + 'collections/2-hristoygenniatikes-tainies-online', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]Μεταγλωτισμένα Παιδικά[/COLOR][/B]', TAINIOMANIA + 'load/metaglwtismena-paidika-online/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]Κινούμενα Σχέδια[/COLOR][/B]', TAINIOMANIA + 'load/kino_mena_sch_dia/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]Animation[/COLOR][/B]', TAINIOMANIA + 'xfsearch/genre/Animation/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]Δράση[/COLOR][/B]', TAINIOMANIA + 'load/dr_sh/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]Έγκλημα[/COLOR][/B]', TAINIOMANIA + 'load/egkl_mato/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]Περιπέτεια[/COLOR][/B]', TAINIOMANIA + 'load/perip_teia/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]Πολέμου[/COLOR][/B]', TAINIOMANIA + 'load/polemik/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]Ιστορικές[/COLOR][/B]', TAINIOMANIA + 'load/istorik/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]Τρόμου[/COLOR][/B]', TAINIOMANIA + 'load/tr_moy/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]Μυστήριο[/COLOR][/B]', TAINIOMANIA + 'load/mysthr_oy/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]Θρίλερ[/COLOR][/B]', TAINIOMANIA + 'load/thr_ler/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]Φαντασίας[/COLOR][/B]', TAINIOMANIA + 'load/fantas_a/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]Ντοκιμαντέρ[/COLOR][/B]', TAINIOMANIA + 'load/ntokimant_r/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]Βιογραφίες[/COLOR][/B]', TAINIOMANIA + 'load/biograf_e/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]Μιούζικαλ[/COLOR][/B]', TAINIOMANIA + 'load/mio_zikal/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]Αθλητικά[/COLOR][/B]', TAINIOMANIA + 'load/athlhtik/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]Θέατρο[/COLOR][/B]', TAINIOMANIA + 'load/th_atro/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]Μουσική[/COLOR][/B]', TAINIOMANIA + 'load/moysik/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]Σειρές[/COLOR][/B]', TAINIOMANIA + 'load/seir/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]Ολοκληρωμένες Σειρές[/COLOR][/B]', TAINIOMANIA + 'load/oloklhrwmenes_seires/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]Γουέστερν[/COLOR][/B]', TAINIOMANIA + 'load/goy_stern_western/', 89, ART + 'tainiomania.png', FANART, '')


def menu_year(): #86
    addDir('[B][COLOR coral]2024[/COLOR][/B]', 'https://tainio-mania.online/load/tainies-2022/load/tainies-2024-online/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]2023[/COLOR][/B]', 'https://tainio-mania.online/load/tainies-2022/load/tainies-2023-online/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]2022[/COLOR][/B]', 'https://tainio-mania.online/load/tainies-2022/load/tainies-2022/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]2021[/COLOR][/B]', 'https://tainio-mania.online/load/tainies-2022/load/tainies-tou-2021/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]2020[/COLOR][/B]', 'https://tainio-mania.online/load/tainies-2022/load/-2020/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]2019[/COLOR][/B]', 'https://tainio-mania.online/load/tainies-2022/load/tain_e_toy_2019/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]2018[/COLOR][/B]', 'https://tainio-mania.online/load/tainies-2022/load/tainies-online-2018/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]2017[/COLOR][/B]', 'https://tainio-mania.online/load/tainies-2022/load/tainies-2017-online/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]2016[/COLOR][/B]', 'https://tainio-mania.online/load/tainies-2022/load/tainies-2016-online/', 89, ART + 'tainiomania.png', FANART, '')


def tainiomania(url): #89
    p = client.request(url)
#    m = re.compile('<a href="(.+?)" title=.+? >\s+<img data-src="(.+?)"   alt="(.+?)" />').findall(p)
    m = re.compile('<h4><a href="(.+?)" class="entryLink">(.+?)</a></h4>.+?<img data-src="(.+?)".+?<div style="text-align: center;"><b>.+?\s*</b></div>\s+(.+?)"', re.DOTALL).findall(p)
    for url, name, icon, description in m:
        description = description.replace('</div>', '').replace('<div class=', '')
        fanart = TAINIOMANIA + icon
        name = clear_Title(name)
        addDir('[B][COLOR=white]%s[/COLOR][/B]' % name, url, 88, (TAINIOMANIA + icon) , fanart, description)
    try:
        m = re.compile('</span> <a href="(.+?)">').findall(p)[0]
        addDir('[B][COLOR=lime]Επόμενη σελίδα >>[/COLOR][/B]', m, 89, 'http://i.imgur.com/rKSs0yq.png', FANART, '')
    except BaseException:
        pass
    views.selectView('movies', 'movie-view')


def get_links(name, url, iconimage, description): #88
    p = client.request(url)
    m2 = re.compile('<span class="tryout">(.+?)</span> ').findall(p)
    for url in m2:
        url = 'https://youtu.be/' + url
        Trailer = '[B][COLOR=lime]Τρέιλερ[/COLOR][/B]'
        addDir(Trailer, url, 100, ART + 'youtube.png', FANART, str(description))
    try:
        m = re.compile('<span class="idimdb">(.+?)</span>').findall(p)
        for url in m:
            url = 'https://coverapi.store/embed/' + url
        #    url = url.replace('/2015','').replace('.mp4','')
            addDir(name, url, 100, iconimage, FANART, str(description))
        else:
            if not'coverapi' in url :
                name = '[B][COLOR orange] * Το link θα είναι διαθέσιμο ξανά σε 30 λεπτά *[/COLOR][/B]'
                addDir(name, url, 100, iconimage, FANART, str(description))
    except BaseException:
        pass

def search(url): #85
    keyb = xbmc.Keyboard('', 'Αναζήτηση Ταινίας - Τήλ.Σειράς')
    keyb.doModal()
    if (keyb.isConfirmed()):
        search = keyb.getText().replace(' ', '+')
        url = 'https://tainio-mania.online/?story=' + search + '&titleonly=3&do=search&subaction=search'
        tainiomania(url)

def clear_Title(txt):
    import six
    if six.PY2:
        txt = txt.encode('utf-8', 'ignore')
    else:
        txt = six.ensure_text(txt, encoding='utf-8', errors='ignore')
    txt = re.sub(r'<.+?>', '', txt)
    txt = re.sub(r'var\s+cp.+?document.write\(\'\'\);\s*', '', txt)
    txt = txt.replace("&quot;", "\"").replace('()', '').replace("&#038;", "&").replace('&#8211;', ':').replace('\n',
                                                                                                               ' ')
    txt = txt.replace("&amp;", "&").replace('&#8217;', "'").replace('&#039;', ':').replace('&#;', '\'').replace('&#8230;', '...')
    txt = txt.replace("&#38;", "&").replace('&#8221;', '"').replace('&#8216;', '"').replace('&#160;', '')
    txt = txt.replace("&nbsp;", "").replace('&#8220;', '"').replace('&#8216;', '"').replace('\t', ' ')
    txt = txt.replace('οσ ', 'ος ').replace('οσ:', 'ος:').replace('ασ ', 'ας ').replace('εσ ', 'ες ').replace('ησ ', 'ης ').replace('εισ ', 'εις ').replace('Τησ ', 'Της ')
    return txt
