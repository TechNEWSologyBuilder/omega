# -*- coding: utf-8 -*-

import xbmcgui
import xbmcaddon
import xbmc
import re
import requests
import six
from six.moves.urllib_parse import quote_plus
from resources.lib.modules import client
from resources.lib.modules import control
from resources.lib.modules import views
from resources.lib.modules import dom_parser as dom
from resources.lib.modules.control import addDir
ADDON       = xbmcaddon.Addon()
ADDON_DATA  = ADDON.getAddonInfo('profile')
ADDON_PATH  = ADDON.getAddonInfo('path')
DESCRIPTION = ADDON.getAddonInfo('description')
FANART      = ADDON.getAddonInfo('fanart')
ICON        = ADDON.getAddonInfo('icon')
ID          = ADDON.getAddonInfo('id')
NAME        = ADDON.getAddonInfo('name')
VERSION     = ADDON.getAddonInfo('version')
Lang        = control.lang
Dialog      = xbmcgui.Dialog()
vers = VERSION
ART = ADDON_PATH + "/resources/icons/"
icon_BNWMOVIES = ART + 'bnwmovies.png'
BNWMOVIES = 'https://bnwmovies.com/'



def menu_genre(): #104
    addDir('[COLOR white]Action[/COLOR]', BNWMOVIES + 'genre/action', 105, icon_BNWMOVIES, FANART, '')
    addDir('[COLOR white]Adventure[/COLOR]', BNWMOVIES + 'genre/adventure', 105, icon_BNWMOVIES, FANART, '')
    addDir('[COLOR white]Animation[/COLOR]', BNWMOVIES + 'genre/animation', 105, icon_BNWMOVIES, FANART, '')
    addDir('[COLOR white]Classic[/COLOR]', BNWMOVIES + '/classic-movies', 105, icon_BNWMOVIES, FANART, '')
    addDir('[COLOR white]Comedy[/COLOR]', BNWMOVIES + 'genre/comedy', 105, icon_BNWMOVIES, FANART, '')
    addDir('[COLOR white]Drama[/COLOR]', BNWMOVIES + 'genre/drama', 105, icon_BNWMOVIES, FANART, '')
    addDir('[COLOR white]Horror[/COLOR]', BNWMOVIES + 'genre/horror', 105, icon_BNWMOVIES, FANART, '')
    addDir('[COLOR white]Mystery[/COLOR]', BNWMOVIES + 'genre/mystery', 105, icon_BNWMOVIES, FANART, '')
    addDir('[COLOR white]Romance[/COLOR]', BNWMOVIES + 'genre/romance', 105, icon_BNWMOVIES, FANART, '')
    addDir('[COLOR white]Sci-Fi[/COLOR]', BNWMOVIES + 'genre/sci-fi', 105, icon_BNWMOVIES, FANART, '')
    addDir('[COLOR white]Thriller[/COLOR]', BNWMOVIES + 'genre/thriller', 105, icon_BNWMOVIES, FANART, '')
    addDir('[COLOR white]Western[/COLOR]', BNWMOVIES + 'genre/western', 105, icon_BNWMOVIES, FANART, '')
    addDir('[COLOR white]War[/COLOR]', BNWMOVIES + 'genre/war', 105, icon_BNWMOVIES, FANART, '')


def bnwmovies(url): #105
    hdrs = {'Referer': BNWMOVIES,
            'User-Agent': client.agent()}
    p = requests.get(url, headers=hdrs).text
    m = re.compile('<div class="cattombstone"><a href="(.+?)"><.+?src="(.+?)".+?/><br>(.+?)</a>', re.DOTALL).findall(p)
    for url, icon, name in m:
        name = name.replace('&#8217;', "'").replace('&#8211;', "-")
        addDir(name, url, 106, icon, FANART, '')
    try:
        m = re.compile('<a class="nextpostslink" rel="next" aria-label="Next Page" href="(.+?)">').findall(p)[0]
        addDir('[B][COLOR=lime]Επόμενη σελίδα >>[/COLOR][/B]', m, 105, 'http://i.imgur.com/rKSs0yq.png', FANART, '')
    except BaseException:
        pass
    views.selectView('movies', 'movie-view')


def get_links(name, url, iconimage, description): #106
    hdrs = {'Referer': BNWMOVIES,
            'User-Agent': client.agent()}
    p = requests.get(url, headers=hdrs).text
    m = re.compile('<source src="(.+?)"').findall(p)
    t = re.compile('<span></span>(.+?)\s+</h1>').findall(p)
    for url in m:
        for name in t:
            if '.mp4' in url:
                name = name.replace(' - Watch and Download Free!', '').replace('"', '')
                addDir(name, url, 100, iconimage, FANART, str(description))


def search(url): #90
    keyb = xbmc.Keyboard('', 'Αναζήτηση Ταινίας - Τήλ.Σειράς')
    keyb.doModal()
    if (keyb.isConfirmed()):
        search = keyb.getText().replace(' ', '+')
        url = 'https://www.downloads-BNWMOVIES.co/search.php?zoom_query=' + search
        bnwmovies(url)


