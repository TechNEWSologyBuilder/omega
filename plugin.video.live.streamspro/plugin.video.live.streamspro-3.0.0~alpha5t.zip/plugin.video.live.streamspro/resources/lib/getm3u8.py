# -*- coding: utf-8 -*-
"""
Librería getm3u8 para Kodi
- Lee un archivo .txt remoto con URLs m3u8
- Muestra activas e inactivas con color en Kodi
- Todas las listas usan el mismo thumbnail
- Optimizado con ThreadPoolExecutor
"""

import re
import requests
from concurrent.futures import ThreadPoolExecutor

THUMBNAIL = "https://bgaddon.pro/black/img/television.png"

# ============================================================
# Funciones principales
# ============================================================

def fetch_m3u_list(txt_url):
    """
    Lee un txt remoto y devuelve una lista de diccionarios:
    [{'id': '2', 'url': 'http://...', 'country': 'Mexico'}, ...]
    """
    try:
        resp = requests.get(txt_url, timeout=15)
        resp.raise_for_status()
        data = resp.text.splitlines()
        result = []
        pattern = re.compile(r'"?(\d+)=([^,]+)","?(.+?)",?')

        for line in data:
            match = pattern.search(line)
            if match:
                id_, url, country = match.groups()
                result.append({'id': id_.strip(), 'url': url.strip(), 'country': country.strip()})
        return result
    except Exception as e:
        return [{'id': '0', 'url': '', 'country': f'Error leyendo lista: {e}'}]

def is_url_active(url):
    """Verifica si la URL responde con código 200 (HEAD request rápida)"""
    try:
        resp = requests.head(url, timeout=5, allow_redirects=True)
        return resp.status_code == 200
    except:
        return False

def generate_items(txt_url):
    """Genera XML <items> con listas activas primero y color en Kodi"""
    streams = fetch_m3u_list(txt_url)
    
    active_items = []
    inactive_items = []

    def process_stream(s):
        url = s['url']
        country = s['country']
        id_ = s['id']
        active = is_url_active(url)
        if active:
            title = f"Lista {id_} ({country}) [COLOR lightgreen]Activa[/COLOR]"
            link = url
            active_items.append((title, link))
        else:
            title = f"Lista {id_} ({country}) [COLOR red]Inactiva[/COLOR]"
            link = "NA"
            inactive_items.append((title, link))

    # Paralelismo
    with ThreadPoolExecutor(max_workers=10) as executor:
        list(executor.map(process_stream, streams))

    items_xml = ""

    for title, link in active_items + inactive_items:
        items_xml += f"""
<item>
  <title>{title}</title>
  <link>NA</link>
  <externallink>{link}</externallink>
  <thumbnail>{THUMBNAIL}</thumbnail>
</item>
"""

    if not items_xml:
        items_xml = f"""
<item>
  <title>No se encontraron listas</title>
  <link>NA</link>
  <externallink>NA</externallink>
  <thumbnail>{THUMBNAIL}</thumbnail>
</item>
"""

    return f"<items>{items_xml}</items>"

# ============================================================
# Entrada para $pyFunction
# ============================================================

def getm3u8(txt_url):
    """
    Función principal para usar desde XML $pyFunction
    txt_url: URL del archivo .txt en claro
    """
    if not txt_url.startswith("http"):
        return f"<items><item><title>Error: URL inválida</title><link>NA</link><externallink>NA</externallink><thumbnail>{THUMBNAIL}</thumbnail></item></items>"
    return generate_items(txt_url)
