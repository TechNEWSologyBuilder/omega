# -*- coding: utf-8 -*-
import time
from kodi_six import xbmcplugin, xbmcgui, xbmcaddon, xbmcvfs, xbmc

ADDON = xbmcaddon.Addon()
PROFILE_PATH = ADDON.getAddonInfo('profile')
ICON_PATH = ADDON.getAddonInfo('path') + '/icon.png'


def show_every_n_hours(
    title="BlackGhost",
    message="[COLORlightblue]Apoya este proyecto ♥[/COLOR]  [COLORlightgreen]paypal.me/blackghost[/COLOR]",
    icon=ICON_PATH,
    hours=6,
    tag="default",
    duration=6000
):
    """
    Muestra una notificación cada 'hours' horas con ícono personalizado.
    Guarda un archivo con la última vez que se mostró usando xbmcvfs.
    """
    try:
        if not xbmcvfs.exists(PROFILE_PATH):
            xbmcvfs.mkdirs(PROFILE_PATH)

        notify_file = PROFILE_PATH + f'/notify_{tag}.txt'

        last_time = 0
        if xbmcvfs.exists(notify_file):
            f = xbmcvfs.File(notify_file, 'r')
            try:
                last_time = float(f.read())
            except:
                last_time = 0
            f.close()

        now = time.time()
        hours_since_last = (now - last_time) / 3600

        if hours_since_last >= hours:
            xbmcgui.Dialog().notification(title, message, icon, duration)
            f = xbmcvfs.File(notify_file, 'w')
            f.write(str(now))
            f.close()

    except Exception as e:
        xbmc.log(f"[notify.py] Error mostrando notificación: {e}", xbmc.LOGERROR)


def show_now(
    title="BlackGhost",
    message="[COLORlightblue]Apoya este proyecto ♥[/COLOR]  [COLORlightgreen]paypal.me/blackghost[/COLOR]",
    icon=ICON_PATH,
    duration=6000
):
    """
    Muestra una notificación inmediatamente, ignorando la última vez.
    """
    try:
        xbmcgui.Dialog().notification(title, message, icon, duration)
    except Exception as e:
        xbmc.log(f"[notify.py] Error mostrando notificación inmediata: {e}", xbmc.LOGERROR)
