﻿import xbmc, xbmcgui

def DialogPleaseWaitMacvod():

    xbmcgui.Dialog().notification("[B][COLOR orange]Keep calm and just wait[/COLOR][/B]", "[COLOR green]Περιμένετε...[/COLOR]", sound=False, icon='special://home/addons/plugin.video.macvod/DialogPleaseWait/Pleasewait.png')
    xbmc.sleep(4000)
    xbmcgui.Dialog().notification("[B][COLOR orange]Keep calm and just wait[/COLOR][/B]", "[COLOR green]Περιμένετε...[/COLOR]", sound=False, icon='special://home/addons/plugin.video.macvod/DialogPleaseWait/Pleasewait.png')
    xbmc.sleep(4000)
    xbmcgui.Dialog().notification("[B][COLOR orange]Keep calm and just wait[/COLOR][/B]", "[COLOR green]Περιμένετε...[/COLOR]", sound=False, icon='special://home/addons/plugin.video.macvod/DialogPleaseWait/Pleasewait.png')
    xbmc.sleep(4000)
    xbmcgui.Dialog().notification("[B][COLOR orange]Keep calm and just wait[/COLOR][/B]", "[COLOR green]Περιμένετε...[/COLOR]", sound=False, icon='special://home/addons/plugin.video.macvod/DialogPleaseWait/Pleasewait.png')
    xbmc.sleep(4000)
    xbmcgui.Dialog().notification("[B][COLOR orange]Does' t work all time[/COLOR][/B]", "[COLOR green]Δεν λειτουργούν πάντα...[/COLOR]", sound=False, icon='special://home/addons/plugin.video.macvod/DialogPleaseWait/doestworkalltime.png')
    xbmc.sleep(4000)
    xbmcgui.Dialog().notification("[B][COLOR orange]Does' t work all time[/COLOR][/B]", "[COLOR green]Δεν λειτουργούν πάντα...[/COLOR]", sound=False, icon='special://home/addons/plugin.video.macvod/DialogPleaseWait/doestworkalltime.png')
    xbmc.sleep(4000)
    xbmcgui.Dialog().notification("[B][COLOR orange]Does' t work all time[/COLOR][/B]", "[COLOR green]Δεν λειτουργούν πάντα...[/COLOR]", sound=False, icon='special://home/addons/plugin.video.macvod/DialogPleaseWait/doestworkalltime.png')
    xbmc.sleep(4000)
    xbmcgui.Dialog().notification("[B][COLOR orange]Does' t work all time[/COLOR][/B]", "[COLOR green]Δεν λειτουργούν πάντα...[/COLOR]", sound=False, icon='special://home/addons/plugin.video.macvod/DialogPleaseWait/doestworkalltime.png')
    xbmc.sleep(4000)
    xbmcgui.Dialog().notification("[B][COLOR orange]Try...[/COLOR][/B]", "[COLOR green]Ισως σταθήτε τυχαιροί...[/COLOR]", sound=False, icon='special://home/addons/plugin.video.macvod/DialogPleaseWait/dice.gif')
    xbmc.sleep(4000)
    xbmcgui.Dialog().notification("[B][COLOR orange]Try...[/COLOR][/B]", "[COLOR green]Ισως σταθήτε τυχαιροί...[/COLOR]", sound=False, icon='special://home/addons/plugin.video.macvod/DialogPleaseWait/dice.gif')
    xbmc.sleep(4000)
    xbmcgui.Dialog().notification("[B][COLOR orange]Try...[/COLOR][/B]", "[COLOR green]Ισως σταθήτε τυχαιροί...[/COLOR]", sound=False, icon='special://home/addons/plugin.video.macvod/DialogPleaseWait/dice.gif')
    xbmc.sleep(4000)
    xbmcgui.Dialog().notification("[B][COLOR orange]Try...[/COLOR][/B]", "[COLOR green]Ισως σταθήτε τυχαιροί...[/COLOR]", sound=False, icon='special://home/addons/plugin.video.macvod/DialogPleaseWait/dice.gif')
    xbmc.sleep(4000)




DialogPleaseWaitMacvod()
